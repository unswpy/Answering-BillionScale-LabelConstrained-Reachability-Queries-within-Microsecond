#include <iostream>
#include <chrono>
#include <ctime>
#include <random>
#include <string>
#include <fstream>
#include <limits>
#include <unordered_set>
#include "compare_algorithms.h"
#include <set>
#include <queue>
#include "BigInt.hpp"


using namespace std;

static const uint32_t INF = numeric_limits<uint32_t>::max();
typedef mt19937 RandomGenerator;

bool A_is_subsetB(set<LABEL_TYPE>& A, set<LABEL_TYPE>& B)
{
	if (includes(B.begin(), B.end(), A.begin(), A.end()))
	{
		return true;
	}
	return false;
}


int main(int argc, char** argv)
{
	//BigInt big1 = 1234567890, big2, big3, big4;
	//big4 = 10241;
	//big2 = "987654321012345678909876543210123456712333333333333333333333444444444444444444444444444444444444444444444444423423890";
	//big3 = big1*big2* 123456;
	//std::cout << big4*big1 << "\n";
	//cout << big3 << endl;
	//bits_vector a;
	//a.set_by_bigint(big1*big4);
	//a.output();
	//system("pause");
	//return 0;
	//string temp = "./afdsa/fdas/edp";
	//auto found = temp.rfind('/');
	//if (found != std::string::npos)
	//	std::cout << "first 'needle' found at: " << found << '\n';
	//string result(temp.begin()+found+1, temp.end());
	//cout << result << endl;
	//system("pause");



	//vector<LABEL_TYPE> A{ 4 };
	//cout << A.[0] << endl;
	//A.erase
	//set<LABEL_TYPE> B{ 2};
	//if (A_is_subsetB(A, B))
	//{
	//	cout << "is subset" << endl;
	//}
	//system("pause");;
	string input = "Biogrid.edge";
	string input2 = "socSlashdot0902L8exp.edge";

	uint32_t node_num, edge_num;
	load_label_graph_get_node_edge_num(input, node_num, edge_num);
	node_num = node_num+1;
	//test_edp();
	//test_edp_by_queryset("erV25kD3L16exp.edge", 26000, 16, 3, 1000);
	//test_edp_by_queryset_minimal_label_set("Biogrid.edge", 80000, 8, 0, 1000);
	//test_edp_by_queryset_minimal_label_set_weight_label("Biogrid.edge", 80000, 8, 1, 1000);
	//test_edp_by_queryset_minimal_label_set_advanced_node_order("erV25kD3L16exp.edge", 26000, 16, 3, 1000);
	//test_edp_by_queryset_minimal_label_set_significant_path("socSlashdot0902L8exp.edge", 90000, 8, 0, 1000);
	test_edp_by_queryset_minimal_label_set("Biogrid.edge", node_num, 8, 1, 1000);
	//test_edp_by_queryset_minimal_label_set_significant_path("Biogrid.edge", 80000, 8, 3, 1000);
	//test_edp_by_queryset("Biogrid.edge", 8, 3, 1000);
	//test_naive_2hop_labeling("socSlashdot0902L8exp.edge", 100000, 8, 3, 1000);
	//test_edp_by_queryset(input, 8, 3, 1000);
	//test_dfs_with_label(982, 1933);
	system("pause");
	return 0;
}



