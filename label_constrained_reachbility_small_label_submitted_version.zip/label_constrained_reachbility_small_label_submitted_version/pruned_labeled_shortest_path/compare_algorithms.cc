#include <iostream>
#include <chrono>
#include <ctime>
#include <random>
#include <string>
#include <fstream>
#include <limits>
#include <unordered_set>
#include "compare_algorithms.h"
#include <queue>
#include <set>
#include <map>
#include <unordered_map>
#include <chrono>

using namespace std;

typedef	vector<NodeID> tree;
vector<NODE_TYPE> node_ranks;
vector<LABEL_TYPE> label_ranks;
class Timer
{
public:
	Timer()
		: t1(res::zero())
		, t2(res::zero())
	{
		tic();
	}

	~Timer()
	{}

	void tic()
	{
		t1 = clock::now();
	}

	void toc(const char* str)
	{
		t2 = clock::now();
		std::cout << str << " time: "
			<< std::chrono::duration_cast<res>(t2 - t1).count() / 1e3 << "ms." << std::endl;
	}

private:
	typedef std::chrono::high_resolution_clock clock;
	typedef std::chrono::microseconds res;

	clock::time_point t1;
	clock::time_point t2;
};



static const uint32_t INF = numeric_limits<uint32_t>::max();
typedef mt19937 RandomGenerator;

set<LABEL_TYPE> convert_to_label_set(LABEL_TYPE temp)
{
	set<LABEL_TYPE> result;
	LABEL_TYPE i = 0;
	while (temp != 0)
	{
		if ((temp & 1) == 1)
		{
			result.insert(i);
		}
		i++;
		temp = temp >> 1;
	}
	return result;
}


LABEL_TYPE label_set_convert_to_binary_label(set<LABEL_TYPE> temp)
{
	LABEL_TYPE result = 0;
	for (auto iter = temp.begin(); iter != temp.end(); iter++)
	{
		result |= convert_to_binary_label(*iter);
	}
	return result;
}

LABEL_TYPE convert_to_binary_label(LABEL_TYPE temp)
{
	if (temp == 0 || temp == 1)
	{
		return temp+1;
	}
	LABEL_TYPE result = 1;
	result = result << (temp);
	return result;
}

bool A_is_subset_of_B(set<LABEL_TYPE>& A, set<LABEL_TYPE>& B)
{
	if (includes(B.begin(), B.end(), A.begin(), A.end()))
	{
		return true;
	}
	return false;
}

bool A_is_subset_of_B(LABEL_TYPE A, LABEL_TYPE B)
{
	//int temp = A&B;
	if ((A & B) == A)
	{
		return true;
	}
	return false;
}

struct ppl_pair_propagate {
	NODE_TYPE node;
	DIS_TYPE dis;
	set<LABEL_TYPE> labels;//cur
	ppl_pair_propagate() { ; }
	ppl_pair_propagate(NODE_TYPE node1, DIS_TYPE dis1)
	{
		node = node1;
		dis = dis1;
	}
	ppl_pair_propagate(NODE_TYPE node1, DIS_TYPE dis1, set<LABEL_TYPE> labels1)
	{
		node = node1;
		dis = dis1;
		for (auto label : labels1)
		{
			labels.insert(label);
		}
	}

	void set_values(NODE_TYPE node1, DIS_TYPE dis1)
	{
		node = node1;
		dis = dis1;
	}

	void set_values(NODE_TYPE node1, DIS_TYPE dis1, set<LABEL_TYPE> labels1)
	{
		node = node1;
		dis = dis1;
		labels.clear();
		for (auto label : labels1)
		{
			labels.insert(label);
		}
	}


	//need to refine the compare operator
	bool operator < (const ppl_pair_propagate&a) const
	{
		if (node < a.node)
		{
			return true;
		}
		else if (node > a.node)
		{
			return false;
		}
		if (dis < a.dis)
		{
			return true;
		}
		else if (dis == a.dis)
		{
			if (labels.size() == a.labels.size())
			{
				return labels < a.labels;
			}
			if (labels.size() < a.labels.size())
			{
				return true;
			}
			return false;
		}
		return false;
	}
	void add_labels(set<LABEL_TYPE> labels1)
	{
		for (auto label : labels1)
		{
			labels.insert(label);
		}
	}
};



struct ppl_pair {
	NODE_TYPE node;
	DIS_TYPE dis;
	set<LABEL_TYPE> labels;//cur
	ppl_pair() { ; }
	ppl_pair(NODE_TYPE node1, DIS_TYPE dis1)
	{
		node = node1;
		dis = dis1;
	}
	ppl_pair(NODE_TYPE node1, DIS_TYPE dis1, set<LABEL_TYPE> labels1)
	{
		node = node1;
		dis = dis1;
		for (auto label : labels1)
		{
			labels.insert(label);
		}
	}

	void set_values(NODE_TYPE node1, DIS_TYPE dis1)
	{
		node = node1;
		dis = dis1;
	}

	void set_values(NODE_TYPE node1, DIS_TYPE dis1, set<LABEL_TYPE> labels1)
	{
		node = node1;
		dis = dis1;
		labels.clear();
		for (auto label : labels1)
		{
			labels.insert(label);
		}
	}


	bool dominated_by_one_in_set(set<ppl_pair>& cmp_labels)
	{
		//if (cmp_labels.size() >= 3)
		//{
		//	cout << endl;
		//}
		if (cmp_labels.empty())
		{
			return false;
		}
		for (auto pair : cmp_labels)
		{
			if (pair.node != node)
			{
				continue;
			}
			if (pair.dis > dis)// cannot dominate
			{
				break;
			}
			if (A_is_subset_of_B(pair.labels, labels))
			{
				return true;
			}
		}
		return false;
	}
	bool dominated_by_single(ppl_pair& cmp)
	{
		if (dis < cmp.dis)
		{
			return false;
		}
		else if (A_is_subset_of_B(labels, cmp.labels) && labels != cmp.labels)
		{
			return false;
		}
		return true;
	}
	bool operator < (const ppl_pair&a) const
	{
		if (node < a.node)
		{
			return true;
		}
		else if (node > a.node)
		{
			return false;
		}
		if (dis < a.dis)
		{
			return true;
		}
		else if (dis == a.dis)
		{

			if (labels.size() < a.labels.size())
			{
				return true;
			}
			else if (labels.size() == a.labels.size())
			{
				return labels < a.labels;
			}
			return false;
		}
		return false;
	}
	void add_labels(set<LABEL_TYPE> labels1)
	{
		for (auto label : labels1)
		{
			labels.insert(label);
		}
	}
};


class ppl_label_index {
public:
	map<NODE_TYPE, set<ppl_pair>> in_labels;
	map<NODE_TYPE, set<ppl_pair>> out_labels;
	void insert_in_label(ppl_pair& in_label)
	{
		auto in_exist = in_labels.find(in_label.node);
		set<ppl_pair> temp;
		temp.insert(in_label);
		if (in_exist == in_labels.end())//first time to insert
		{
			in_labels.insert(std::make_pair(in_label.node, temp));
		}
		else
		{
			in_exist->second.insert(in_label);
		}
	}
	void insert_out_label(ppl_pair& out_label)
	{
		auto out_exist = out_labels.find(out_label.node);
		set<ppl_pair> temp;
		temp.insert(out_label);
		if (out_exist == out_labels.end())//first time to insert
		{
			out_labels.insert(std::make_pair(out_label.node, temp));
		}
		else
		{
			out_exist->second.insert(out_label);
		}
	}

};

class hot_degree {
public:
	NODE_TYPE node;
	double degree;
	hot_degree(NODE_TYPE a, double b) :node(a), degree(b) {}
	bool operator < (const hot_degree &m)const {
		return degree > m.degree;
	}
	bool operator == (const hot_degree &m) const {
		return (node == m.node && degree == m.degree);
	}
};

int BitCount5(unsigned int n)
{
	unsigned int tmp = n - ((n >> 1) & 033333333333) - ((n >> 2) & 011111111111);
	return ((tmp + (tmp >> 3)) & 030707070707) % 63;
}

struct ppl_LCR_pair_no_order {
	NODE_TYPE node;
	LABEL_TYPE labels;
	//set<LABEL_TYPE> labels;//cur
	ppl_LCR_pair_no_order() { ; }
	ppl_LCR_pair_no_order(NODE_TYPE node1)
	{
		node = node1;
	}
	/*ppl_LCR_pair(NODE_TYPE node1, set<LABEL_TYPE> labels1)
	{
	node = node1;
	for (auto label : labels1)
	{
	labels.insert(label);
	}
	}*/
	ppl_LCR_pair_no_order(NODE_TYPE node1, LABEL_TYPE labels1)
	{
		node = node1;
		labels = labels1;
	}


	void set_values(NODE_TYPE node1)
	{
		node = node1;
	}

	/*void set_values(NODE_TYPE node1, set<LABEL_TYPE> labels1)
	{
	node = node1;
	labels.clear();
	for (auto label : labels1)
	{
	labels.insert(label);
	}
	}*/
	void set_values(NODE_TYPE node1, LABEL_TYPE labels1)
	{
		node = node1;
		labels = labels1;
	}



	/*bool operator < (const ppl_LCR_pair&a) const
	{
	if (node < a.node)
	{
	return true;
	}
	else if (node > a.node)
	{
	return false;
	}
	if (labels.size() < a.labels.size())
	{
	return true;
	}
	else if (labels.size() == a.labels.size())
	{
	return labels < a.labels;
	}
	return false;
	}*/



	bool operator < (const ppl_LCR_pair_no_order&a) const
	{
		bool reorder = false;
		if (reorder)
		{
			if (BitCount5(labels) < BitCount5(a.labels))
			{
				return true;
			}
			else if (BitCount5(labels) == BitCount5(a.labels))
			{
				if (node_ranks[node] < node_ranks[a.node])
				{
					return true;
				}
				else if (node_ranks[node] > node_ranks[a.node])
				{
					return false;
				}
				return labels < a.labels;
				/*if (labels < a.labels)
				{
				return true;
				}
				else if (labels > a.labels)
				{
				return false;
				}
				return node_ranks[node] < node_ranks[a.node];*/
				/*if (node_ranks[node] < node_ranks[a.node])
				{
				return true;
				}
				else if (node_ranks[node] > node_ranks[a.node])
				{
				return false;
				}*/
			}
			return false;
		}
		else {
			//return node_ranks[node] < node_ranks[a.node];
			//if (node_ranks[node] < node_ranks[a.node])
			if (node < a.node)//node_ranks[node] < node_ranks[a.node])
			{
				return true;
			}
			//return labels < a.labels;
			//else if (node_ranks[node] > node_ranks[a.node])
			//{
			//	return false;
			//}
			/*if (BitCount5(labels) < BitCount5(a.labels))
			{
				return true;
			}
			else if (BitCount5(labels) > BitCount5(a.labels))
			{
				return false;
			}*/
			else
			{
				return labels < a.labels;
			}
		}
		return false;
	}



	bool dominated_by_one_in_set(set<ppl_LCR_pair_no_order>& cmp_labels)
	{
		//if (cmp_labels.size() >= 3)
		//{
		//	cout << endl;
		//}
		if (cmp_labels.empty())
		{
			return false;
		}
		for (auto pair = cmp_labels.begin(); pair != cmp_labels.end(); pair++)
		{
			if (pair->node != node)
			{
				continue;
			}
			if (BitCount5(pair->labels) > BitCount5(labels))//early terminate need a bloom filter?
			{
				return false;
			}
			if (A_is_subset_of_B(pair->labels, labels))
			{
				return true;
			}
		}
		return false;
	}
	bool dominated_by_single(ppl_LCR_pair_no_order& cmp)
	{
		if (A_is_subset_of_B(labels, cmp.labels) && labels != cmp.labels)
		{
			return false;
		}
		return true;
	}


	/*void add_labels(set<LABEL_TYPE> labels1)
	{
	for (auto label : labels1)
	{
	labels.insert(label);
	}
	}*/
	void add_labels(LABEL_TYPE labels1)
	{
		labels = labels | labels1;
	}
};


struct ppl_LCR_pair {
	NODE_TYPE node;
	LABEL_TYPE labels;
	//set<LABEL_TYPE> labels;//cur
	ppl_LCR_pair() { ; }
	ppl_LCR_pair(NODE_TYPE node1)
	{
		node = node1;
	}
	/*ppl_LCR_pair(NODE_TYPE node1, set<LABEL_TYPE> labels1)
	{
		node = node1;
		for (auto label : labels1)
		{
			labels.insert(label);
		}
	}*/
	ppl_LCR_pair(NODE_TYPE node1, LABEL_TYPE labels1)
	{
		node = node1;
		labels = labels1;
	}


	void set_values(NODE_TYPE node1)
	{
		node = node1;
	}

	/*void set_values(NODE_TYPE node1, set<LABEL_TYPE> labels1)
	{
		node = node1;
		labels.clear();
		for (auto label : labels1)
		{
			labels.insert(label);
		}
	}*/
	void set_values(NODE_TYPE node1, LABEL_TYPE labels1)
	{
		node = node1;
		labels = labels1;
	}



	/*bool operator < (const ppl_LCR_pair&a) const
	{
	if (node < a.node)
	{
	return true;
	}
	else if (node > a.node)
	{
	return false;
	}
	if (labels.size() < a.labels.size())
	{
	return true;
	}
	else if (labels.size() == a.labels.size())
	{
	return labels < a.labels;
	}
	return false;
	}*/



	bool operator < (const ppl_LCR_pair&a) const
	{
		bool reorder = true;
		if (reorder)
		{
			if (BitCount5(labels) < BitCount5(a.labels))
			{
				return true;
			}
			else if (BitCount5(labels) == BitCount5(a.labels))
			{
				if (node_ranks[node] < node_ranks[a.node])
				{
					return true;
				}
				else if (node_ranks[node] > node_ranks[a.node])
				{
					return false;
				}
				return labels < a.labels;
				/*if (labels < a.labels)
				{
					return true;
				}
				else if (labels > a.labels)
				{
					return false;
				}
				return node_ranks[node] < node_ranks[a.node];*/
				/*if (node_ranks[node] < node_ranks[a.node])
				{
					return true;
				}
				else if (node_ranks[node] > node_ranks[a.node])
				{
					return false;
				}*/
			}
			return false;
		}
		else {
			//return node_ranks[node] < node_ranks[a.node];
			//if (node_ranks[node] < node_ranks[a.node])
			if (node < a.node)
			{
				return true;
			}
			//return labels < a.labels;
			//else if (node_ranks[node] > node_ranks[a.node])
			//{
			//	return false;
			//}
			if (BitCount5(labels) < BitCount5(a.labels))
			{
				return true;
			}
			else if (BitCount5(labels) > BitCount5(a.labels))
			{
				return false;
			}
			else
			{
				return labels < a.labels;
			}
		}
		return false;
	}



	bool dominated_by_one_in_set(set<ppl_LCR_pair>& cmp_labels)
	{
		//if (cmp_labels.size() >= 3)
		//{
		//	cout << endl;
		//}
		if (cmp_labels.empty())
		{
			return false;
		}
		for (auto pair = cmp_labels.begin(); pair != cmp_labels.end(); pair++)
		{
			if (pair->node != node)
			{
				continue;
			}
			if (BitCount5(pair->labels) > BitCount5(labels))//early terminate need a bloom filter?
			{
				return false;
			}
			if (A_is_subset_of_B(pair->labels, labels))
			{
				return true;
			}
		}
		return false;
	}
	bool dominated_by_single(ppl_LCR_pair& cmp)
	{
		if (A_is_subset_of_B(labels, cmp.labels) && labels != cmp.labels)
		{
			return false;
		}
		return true;
	}

	
	/*void add_labels(set<LABEL_TYPE> labels1)
	{
		for (auto label : labels1)
		{
			labels.insert(label);
		}
	}*/
	void add_labels(LABEL_TYPE labels1)
	{
		labels = labels | labels1;
	}
};

bool dominated_by_one_in_set(LABEL_TYPE labels, set<ppl_LCR_pair>& cmp_labels)
{
	//if (cmp_labels.size() >= 3)
	//{
	//	cout << endl;
	//}
	if (cmp_labels.empty())
	{
		return false;
	}
	for (auto pair = cmp_labels.begin(); pair != cmp_labels.end(); pair++)
	{
		if (BitCount5(pair->labels) > BitCount5(labels))//early terminate need a bloom filter?
		{
			return false;
		}
		if (A_is_subset_of_B(pair->labels, labels))
		{
			return true;
		}
	}
	return false;
}


class ppl_LCR_index {
public:
	map<NODE_TYPE, set<ppl_LCR_pair>> in_labels;
	map<NODE_TYPE, set<ppl_LCR_pair>> out_labels;
	unsigned long getSizeInBytes()
	{
		unsigned long size = 0;
		int emptyMapSize = sizeof(map<NODE_TYPE, set<ppl_LCR_pair>>); // 
		int emptySetSize = sizeof(set<ppl_LCR_pair>);
		int L = sizeof(ppl_LCR_pair)+sizeof(NODE_TYPE);
		size += 2* emptyMapSize;
		for (auto iter = in_labels.begin(); iter != in_labels.end(); iter++)
		{
			size += emptySetSize + iter->second.size()*L;
		}
		for (auto iter = out_labels.begin(); iter != out_labels.end(); iter++)
		{
			size += emptySetSize + iter->second.size()*L;
		}
		return size;
	}
	void insert_in_label(ppl_LCR_pair& in_label)
	{
		auto in_exist = in_labels.find(in_label.node);
		set<ppl_LCR_pair> temp;
		temp.insert(in_label);
		if (in_exist == in_labels.end())//first time to insert
		{
			in_labels.insert(std::make_pair(in_label.node, temp));
		}
		else
		{
			in_exist->second.insert(in_label);
		}
	}
	void insert_out_label(ppl_LCR_pair& out_label)
	{
		auto out_exist = out_labels.find(out_label.node);
		set<ppl_LCR_pair> temp;
		temp.insert(out_label);
		if (out_exist == out_labels.end())//first time to insert
		{
			out_labels.insert(std::make_pair(out_label.node, temp));
		}
		else
		{
			out_exist->second.insert(out_label);
		}
	}

};

unsigned long getGraphSizeInBytes(int node_num, vector<label_edge>* adjacency_list)
{
	unsigned long size = 0;
	int N = node_num;
	int emptyVectorSize = sizeof(vector<label_edge>); // estimated 3 times 32-bits
										   // for the pointer and the capacity and the size

	for (NODE_TYPE i = 0; i < N; i++)
	{
		size += getGraphSizeInBytes_node(node_num, adjacency_list, i);
	}
	return size;
}

unsigned long getGraphSizeInBytes_node(int node_num, vector<label_edge>* adjacency_list, NODE_TYPE v)
{
	unsigned long size = 0;
	int N = node_num;
	int emptyVectorSize = sizeof(vector<label_edge>); // estimated 3 times 32-bits
	int L = sizeof(label_edge);
	size += emptyVectorSize + adjacency_list[v].size()*L;
	return size;
}


struct PropagateCompare
{
	bool operator()(const ppl_LCR_pair& obj1, const ppl_LCR_pair& obj2)
	{
		return BitCount5(obj1.labels) > BitCount5(obj2.labels);
	}
};



class LCR_index
{
public:
	map<NODE_TYPE, ppl_LCR_index> index;// the value of vertex may be not continuous
	map<NODE_TYPE, set<ppl_LCR_pair>> I_in;
	map<NODE_TYPE, set<ppl_LCR_pair>> I_out;
	LCR_index() {};
	void init_node_ranks(NODE_TYPE node_num)
	{
		for (NODE_TYPE i = 0; i < node_num; i++)
		{
			node_ranks.push_back(i);
		}
	}

	struct ppl_LCR_pair_by_node_rank {
		NODE_TYPE node;
		LABEL_TYPE labels;
		//set<LABEL_TYPE> labels;//cur
		ppl_LCR_pair_by_node_rank() { ; }
		ppl_LCR_pair_by_node_rank(NODE_TYPE node1)
		{
			node = node1;
		}
		ppl_LCR_pair_by_node_rank(NODE_TYPE node1, LABEL_TYPE labels1)
		{
			node = node1;
			labels = labels1;
		}


		void set_values(NODE_TYPE node1)
		{
			node = node1;
		}

		void set_values(NODE_TYPE node1, LABEL_TYPE labels1)
		{
			node = node1;
			labels = labels1;
		}

		bool operator < (const ppl_LCR_pair_by_node_rank&a) const
		{
			if (node_ranks[node] < node_ranks[a.node])
			{
				return true;
			}
			else if (node_ranks[node] > node_ranks[a.node])
			{
				return false;
			}
			if (BitCount5(labels) < BitCount5(a.labels))
			{
				return true;
			}
			else if (BitCount5(labels) == BitCount5(a.labels))
			{
				return labels < a.labels;
			}
			return false;
		}



		bool dominated_by_one_in_set(set<ppl_LCR_pair_by_node_rank>& cmp_labels)
		{
			//if (cmp_labels.size() >= 3)
			//{
			//	cout << endl;
			//}
			if (cmp_labels.empty())
			{
				return false;
			}
			for (auto pair = cmp_labels.begin(); pair != cmp_labels.end(); pair++)
			{
				if (pair->node != node)
				{
					continue;
				}
				if (BitCount5(pair->labels) > BitCount5(labels))//early terminate need a bloom filter?
				{
					return false;
				}
				if (A_is_subset_of_B(pair->labels, labels))
				{
					return true;
				}
			}
			return false;
		}
		bool dominated_by_single(ppl_LCR_pair_by_node_rank& cmp)
		{
			if (A_is_subset_of_B(labels, cmp.labels) && labels != cmp.labels)
			{
				return false;
			}
			return true;
		}

		void add_labels(LABEL_TYPE labels1)
		{
			labels = labels | labels1;
		}
	};

	void insert_I_out(NODE_TYPE index_node, NODE_TYPE node, LABEL_TYPE label)
	{
		auto exist_I_out = I_out.find(index_node);
		if (exist_I_out == I_out.end())
		{
			ppl_LCR_pair temp;
			set<ppl_LCR_pair> temp_set;
			temp.node = node;
			temp.labels = label;
			temp_set.insert(temp);
			I_out.insert(std::make_pair(index_node, temp_set));
		}
		else {
			ppl_LCR_pair temp;
			temp.node = node;
			temp.labels = label;
			exist_I_out->second.insert(temp);
		}
	}

	void insert_I_in(NODE_TYPE index_node, NODE_TYPE node, LABEL_TYPE label)
	{
		auto exist_I_in = I_in.find(index_node);
		if (exist_I_in == I_in.end())
		{
			ppl_LCR_pair temp;
			set<ppl_LCR_pair> temp_set;
			temp.node = node;
			temp.labels = label;
			temp_set.insert(temp);
			I_in.insert(std::make_pair(index_node, temp_set));
		}
		else {
			ppl_LCR_pair temp;
			temp.node = node;
			temp.labels = label;
			exist_I_in->second.insert(temp);
		}
	}


	bool insert_index_out_tuple(NODE_TYPE index_node, NODE_TYPE tuple_node, LABEL_TYPE labels)
	{
		if (find_distance_ppl(index_node, tuple_node, labels) != 1)
		{
			ppl_LCR_pair out_label(tuple_node, labels);
			auto index_exist = index.find(index_node);
			if (index_exist == index.end())
			{
				ppl_LCR_index new_in_out;

				new_in_out.insert_out_label(out_label);
				index.insert(std::make_pair(index_node, new_in_out));
			}
			else
			{
				index_exist->second.insert_out_label(out_label);
			}
			return true;
		}
		return false;
	}


	bool insert_index_in_tuple(NODE_TYPE index_node, NODE_TYPE tuple_node, LABEL_TYPE labels)
	{
		if (find_distance_ppl(tuple_node, index_node, labels) != 1)
		{
			ppl_LCR_pair in_label(tuple_node, labels);
			auto index_exist = index.find(index_node);
			if (index_exist == index.end())
			{
				ppl_LCR_index new_in_out;

				new_in_out.insert_in_label(in_label);
				index.insert(std::make_pair(index_node, new_in_out));
			}
			else
			{
				index_exist->second.insert_in_label(in_label);
			}
			return true;
		}
		return false;
	}
	// judge_reachability_partial_index(set<NODE_TYPE>& indexed, NODE_TYPE src, NODE_TYPE dst, set<LABEL_TYPE>& labels)
	//{
	//	if (src == dst)
	//	{
	//		return true;
	//	}

	//}
	unsigned long getIndexSizeInBytesM(int node_num, vector<label_edge>* adjacency_list)
	{
		unsigned long size = 0;
		int N = node_num;
		int emptyMapSize = sizeof(map<NODE_TYPE, set<ppl_LCR_pair>>); // 
		size += emptyMapSize;
		int L = sizeof(NODE_TYPE) + sizeof(set<ppl_LCR_pair>);

		for (auto iter = index.begin(); iter != index.end(); iter++)
		{
			size += L + getIndexSizeInBytesM_node(node_num, iter->first);
		}

		size += 2 * getGraphSizeInBytes(node_num, adjacency_list);
		return size;
	};


	unsigned long getIndexSizeInBytesM_node(int node_num, NODE_TYPE v)
	{
		auto res = index.find(v);
		unsigned long size = 0;
		int L = sizeof(NODE_TYPE);
		size += L + res->second.getSizeInBytes();
		return size;
	}

	bool construct_label_index_by_betweeness(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num)
	{
		int sampleSize = 10000;
		auto index_start = chrono::high_resolution_clock::now();
		//sort by node degree
		vector<hot_degree> hot_points;
		for (NODE_TYPE i = 0; i < node_num; i++)
		{
			hot_degree hd1(i, 0);
			hot_points.push_back(hd1);
		}

		srand((unsigned)time(NULL));
		set<NODE_TYPE> cur_propagate_sample;
		set<NODE_TYPE> cur_propagate_reverse_sample;
		set<NODE_TYPE> temp_propagate_sample;
		set<NODE_TYPE> visited_node;
		std::random_device rd;
		std::uniform_int_distribution<int> dist(0, node_num);
		//std::cout << dist(rd) << std::endl;
		for (int sample = 0; sample < sampleSize; sample++)
		{
			if (sample % 100 == 0)
			{
				cout << sample << endl;
			}
			//random choose src node
			int src_rand = dist(rd);
			if (adjacency_list[src_rand].size() == 0 || adjacency_list_reverse[src_rand].size() == 0)
			{
				continue;
			}
			visited_node.clear();
			cur_propagate_sample.clear();
			cur_propagate_reverse_sample.clear();


			//forward bfs
			cur_propagate_sample.insert(src_rand);
			//set<NODE_TYPE> visited_index_nodes;
			while (!cur_propagate_sample.empty())
			{
				temp_propagate_sample.clear();
				for (auto iter1 = cur_propagate_sample.begin(); iter1 != cur_propagate_sample.end(); iter1++)
				{
					for (auto edge = adjacency_list[*iter1].begin(); edge != adjacency_list[*iter1].end(); edge++)
					{
						NODE_TYPE cur_node = edge->node;
						if (cur_node > node_num)
						{
							cout << " node index too large" << endl;
						}
						if (visited_node.find(cur_node) != visited_node.end())
						{
							continue;
						}
						hot_points[cur_node].degree++;
						visited_node.insert(cur_node);
						temp_propagate_sample.insert(cur_node);

					}
				}
				cur_propagate_sample = temp_propagate_sample;
			}
			visited_node.clear();
			cur_propagate_sample.clear();
			cur_propagate_reverse_sample.clear();
			cur_propagate_reverse_sample.insert(src_rand);
			while (!cur_propagate_reverse_sample.empty())
			{
				temp_propagate_sample.clear();
				for (auto iter1 = cur_propagate_reverse_sample.begin(); iter1 != cur_propagate_reverse_sample.end(); iter1++)
				{
					for (auto edge = adjacency_list_reverse[*iter1].begin(); edge != adjacency_list_reverse[*iter1].end(); edge++)
					{
						NODE_TYPE cur_node = edge->node;
						if (visited_node.find(cur_node) != visited_node.end())
						{
							continue;
						}
						hot_points[cur_node].degree++;

						visited_node.insert(cur_node);
						temp_propagate_sample.insert(cur_node);
						}
				}
				cur_propagate_reverse_sample = temp_propagate_sample;

			}
		}

		stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
		cout << "end of sample" << endl;
		ppl_LCR_pair src(0);
		set<ppl_LCR_pair> cur_propagate;
		set<ppl_LCR_pair> cur_propagate_reverse;
		set<ppl_LCR_pair> temp_propagate;
		ppl_LCR_pair new_pair;
		ppl_LCR_pair new_pair_propagate;
		ppl_LCR_pair in_label;
		//ppl_label_index new_in_out;
		ppl_LCR_pair out_label;
		set<NODE_TYPE> already_indexed;
		bool ppl_start = false;
		uint32_t timeout = 6*3600 * 6;//6hours
									//for (NODE_TYPE i = 1; i <= node_num; i++)
									//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
		for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
		{
			auto index_process = chrono::high_resolution_clock::now();
			auto diff = chrono::duration_cast<chrono::milliseconds>(index_process - index_start);
			if (diff.count() / 1e3 >= timeout)
			{
				cout << "time out to construct index" << endl;
				exit(1);
			}
			NODE_TYPE i = node_explore->node;
			src.node = i;
			src.labels = 0;
			if (i % 100000 == 0)
			{
				cout << i << endl;
			}
			//BFS to construct the index
			cur_propagate.clear();
			cur_propagate_reverse.clear();


			//forward bfs
			cur_propagate.insert(src);
			set<NODE_TYPE> visited_index_nodes;
			while (!cur_propagate.empty())
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate.begin(); iter1 != cur_propagate.end(); iter1++)
				{
					for (auto edge = adjacency_list[iter1->node].begin(); edge != adjacency_list[iter1->node].end(); edge++)
					{
						if (edge->node == 73)
						{
							//cout << 73 << endl;
						}
						if (already_indexed.find(edge->node) != already_indexed.end())
						{
							continue;
						}
						//LABEL_TYPE tempL = 1;
						//tempL << (iter1->labels-1);
						new_pair.set_values(edge->node, (iter1->labels));
						new_pair_propagate.set_values(edge->node, (iter1->labels));

						new_pair.add_labels(convert_to_binary_label(edge->label));
						if (ppl_start)
						{
							if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
							{
								continue;
							}
						}
						new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

						NODE_TYPE cur_node = edge->node;
						in_label.set_values(i, new_pair.labels);// store the start node
						auto exist_index = index.find(cur_node);
						if (cur_node == 38)
						{
							//cout << 38 << endl;
						}
						if (exist_index == index.end())//first time to insert index for node cur_node
						{
							ppl_LCR_index new_in_out;
							new_in_out.insert_in_label(in_label);
							index.insert(std::make_pair(cur_node, new_in_out));
							temp_propagate.insert(new_pair_propagate);
						}
						else
						{
							auto exist_in = exist_index->second.in_labels.find(in_label.node);
							if (exist_in == exist_index->second.in_labels.end())
							{
								exist_index->second.insert_in_label(in_label);
								temp_propagate.insert(new_pair_propagate);
								continue;
							}
							if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
							{
								exist_index->second.insert_in_label(in_label);
								temp_propagate.insert(new_pair_propagate);
							}
						}
					}
				}
				cur_propagate = temp_propagate;
			}
			//when to stop 
			//reverse bfs
			cur_propagate_reverse.insert(src);
			while (!cur_propagate_reverse.empty())
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate_reverse.begin(); iter1 != cur_propagate_reverse.end(); iter1++)
				{
					for (auto edge = adjacency_list_reverse[iter1->node].begin(); edge != adjacency_list_reverse[iter1->node].end(); edge++)
					{

						if (already_indexed.find(edge->node) != already_indexed.end())
						{
							continue;
						}
						new_pair.set_values(edge->node, (iter1->labels));
						new_pair_propagate.set_values(edge->node, (iter1->labels));

						new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

						new_pair.add_labels(convert_to_binary_label(edge->label));
						if (ppl_start)
						{
							if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
							{
								continue;
							}
						}



						NODE_TYPE cur_node = edge->node;
						out_label.set_values(i, new_pair.labels);// store the start node
						auto exist_index = index.find(cur_node);
						if (exist_index == index.end())//first time to insert index for node cur_node
						{
							ppl_LCR_index new_in_out;
							new_in_out.insert_out_label(out_label);
							index.insert(std::make_pair(cur_node, new_in_out));
							temp_propagate.insert(new_pair_propagate);
						}
						else
						{
							auto exist_out = exist_index->second.out_labels.find(out_label.node);
							if (exist_out == exist_index->second.out_labels.end())
							{
								exist_index->second.insert_out_label(out_label);
								temp_propagate.insert(new_pair_propagate);
								continue;
							}
							if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
							{
								exist_index->second.insert_out_label(out_label);
								temp_propagate.insert(new_pair_propagate);
							}
						}
					}
				}
				cur_propagate_reverse = temp_propagate;
			}
			already_indexed.insert(i);
			ppl_start = true;
		}
		return true;
	}


	bool construct_label_index_priority_queue(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num)
	{//some bugs
		auto index_start = chrono::high_resolution_clock::now();
		//sort by node degree
		vector<hot_degree> hot_points;
		for (NODE_TYPE i = 0; i < node_num; i++)
		{
			NODE_TYPE temp_degree = adjacency_list[i].size() + adjacency_list_reverse[i].size();
			//if (temp_degree != 0)
			//{
				hot_degree hd1(i, temp_degree);
				hot_points.push_back(hd1);
			//}
		}
		stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());

		ppl_LCR_pair src(0);
		//set<ppl_LCR_pair> cur_propagate;
		//set<ppl_LCR_pair> cur_propagate_reverse;
		priority_queue<ppl_LCR_pair, vector<ppl_LCR_pair>, PropagateCompare> q;

		//set<ppl_LCR_pair> temp_propagate;
		ppl_LCR_pair new_pair;
		ppl_LCR_pair new_pair_propagate;
		ppl_LCR_pair in_label;
		//ppl_label_index new_in_out;
		ppl_LCR_pair out_label;
		set<NODE_TYPE> already_indexed;
		bool ppl_start = false;
		uint32_t timeout = 6*3600 * 6;//6hours
									//for (NODE_TYPE i = 1; i <= node_num; i++)
									//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
		for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
		{
			auto index_process = chrono::high_resolution_clock::now();
			auto diff = chrono::duration_cast<chrono::milliseconds>(index_process - index_start);
			if (diff.count() / 1e3 >= timeout)
			{
				cout << "time out to construct index" << endl;
				exit(1);
			}
			NODE_TYPE i = node_explore->node;
			src.node = i;
			src.labels = 0;
			if (i % 100000 == 0)
			{
				cout << i << endl;
			}
			//BFS to construct the index
			//cur_propagate.clear();
			//cur_propagate_reverse.clear();


			//forward bfs
			//cur_propagate.insert(src);
			
			set<NODE_TYPE> visited_index_nodes;
			q.push(src);
			while (!q.empty())
			{
				auto iter1 = q.top();
				//cout << iter1.node << "\t" << q.size() << "\t" << BitCount5(iter1.labels) << endl;
				q.pop();
				NODE_TYPE cur_node = iter1.node;



				//temp_propagate.clear();
				for (auto edge = adjacency_list[iter1.node].begin(); edge != adjacency_list[iter1.node].end(); edge++)
				{
					if (already_indexed.find(edge->node) != already_indexed.end())
					{
						continue;
					}
						//LABEL_TYPE tempL = 1;
						//tempL << (iter1->labels-1);
					new_pair.set_values(edge->node, (iter1.labels));
					new_pair_propagate.set_values(edge->node, (iter1.labels));

					new_pair.add_labels(convert_to_binary_label(edge->label));
					//if (ppl_start)
					//{
						if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
						{
							continue;
						}
					//}					
					new_pair_propagate.add_labels(convert_to_binary_label(edge->label));
					in_label.set_values(i, new_pair_propagate.labels);// store the start node
					auto exist_index = index.find(cur_node);

					if (exist_index == index.end())//first time to insert index for node cur_node
					{
						ppl_LCR_index new_in_out;
						new_in_out.insert_in_label(in_label);
						index.insert(std::make_pair(cur_node, new_in_out));
						q.push(new_pair_propagate);

						//cur_propagate.insert(new_pair_propagate);
					}
					else
					{
						auto exist_in = exist_index->second.in_labels.find(in_label.node);
						if (exist_in == exist_index->second.in_labels.end())
						{
							exist_index->second.insert_in_label(in_label);
							q.push(new_pair_propagate);

							//cur_propagate.insert(new_pair_propagate);
						}
						else if (in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
						{
							continue;
						}
						else {
							exist_index->second.insert_in_label(in_label);
							q.push(new_pair_propagate);

						}
					}
					
				}
			}
			//when to stop 
			//reverse bfs
			//cur_propagate.insert(src);
			//set<NODE_TYPE> visited_index_nodes;
			q.push(src);
			while (!q.empty())
			{
				auto iter1 = q.top();
				q.pop();
				//cout << iter1.node << "\t" << q.size() << "\t" << BitCount5(iter1.labels) << endl;
				NODE_TYPE cur_node = iter1.node;
				

				//temp_propagate.clear();
				for (auto edge = adjacency_list_reverse[iter1.node].begin(); edge != adjacency_list_reverse[iter1.node].end(); edge++)
				{
					if (already_indexed.find(edge->node) != already_indexed.end())
					{
						continue;
					}
					//LABEL_TYPE tempL = 1;
					//tempL << (iter1->labels-1);
					new_pair.set_values(edge->node, (iter1.labels));
					new_pair_propagate.set_values(edge->node, (iter1.labels));

					new_pair.add_labels(convert_to_binary_label(edge->label));
					//if (ppl_start)
					//{
						if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
						{
							continue;
						}
					//}
					new_pair_propagate.add_labels(convert_to_binary_label(edge->label));
					out_label.set_values(i, new_pair_propagate.labels);// store the start node
					auto exist_index = index.find(cur_node);

					if (exist_index == index.end())//first time to insert index for node cur_node
					{
						ppl_LCR_index new_in_out;
						new_in_out.insert_out_label(out_label);
						index.insert(std::make_pair(cur_node, new_in_out));
						//cur_propagate.insert(new_pair_propagate);
						q.push(new_pair_propagate);

					}
					else
					{
						auto exist_out = exist_index->second.out_labels.find(out_label.node);
						if (exist_out == exist_index->second.out_labels.end())
						{
							exist_index->second.insert_in_label(out_label);
							q.push(new_pair_propagate);

							//cur_propagate.insert(new_pair_propagate);
						}
						else if (out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
						{
							continue;
						}
						else {
							exist_index->second.insert_out_label(out_label);
							q.push(new_pair_propagate);

						}
					}



				}
			}
			already_indexed.insert(i);
			ppl_start = true;
		}
		return true;
	}



	bool construct_label_index(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num)
	{
		auto index_start = chrono::high_resolution_clock::now();
		//sort by node degree
		vector<hot_degree> hot_points;
		for (NODE_TYPE i = 0; i < node_num; i++)
		{
			NODE_TYPE temp_degree = adjacency_list[i].size() + adjacency_list_reverse[i].size();
			//if (temp_degree != 0)
			//{
				hot_degree hd1(i, temp_degree);
				hot_points.push_back(hd1);
			//}
		}
		stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
		node_ranks.resize(node_num);
		NODE_TYPE temp_rank = 0;
		for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++) 
		{
			node_ranks[node_explore->node] = temp_rank++;
		}
		ppl_LCR_pair_no_order src(0);
		set<ppl_LCR_pair_no_order> cur_propagate;
		set<ppl_LCR_pair_no_order> cur_propagate_reverse;
		set<ppl_LCR_pair_no_order> temp_propagate;
		ppl_LCR_pair_no_order new_pair;
		ppl_LCR_pair_no_order new_pair_propagate;
		ppl_LCR_pair in_label;
		//ppl_label_index new_in_out;
		ppl_LCR_pair out_label;
		set<NODE_TYPE> already_indexed;
		bool ppl_start = true;
		uint32_t timeout = 6*3600 * 6;//6hours
		int part = 0;
		
		//for (NODE_TYPE i = 1; i <= node_num; i++)
		//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
		for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
		{
			part++;
			if (part > 10)
			{
				//break;
			}

			auto index_process = chrono::high_resolution_clock::now();
			auto diff = chrono::duration_cast<chrono::milliseconds>(index_process - index_start);
			if (diff.count() / 1e3 >= timeout)
			{
				cout << "time out to construct index" << endl;
				exit(1);
			}
			NODE_TYPE i = node_explore->node;
			
			src.node = i;
			src.labels = 0;
			//if (true)//i % 1000 == 0)
			//{
				//cout << i << endl;
			//}
			//BFS to construct the index
			cur_propagate.clear();
			cur_propagate_reverse.clear();


			//forward bfs
			cur_propagate.insert(src);
			set<NODE_TYPE> visited_index_nodes;
			while (!cur_propagate.empty())
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate.begin(); iter1 != cur_propagate.end(); iter1++)
				{
					//cout << iter1->node << "\t" << cur_propagate.size() << "\t" << BitCount5(iter1->labels) << endl;
					for (auto edge = adjacency_list[iter1->node].begin(); edge != adjacency_list[iter1->node].end(); edge++)
					{
						if (edge->node == 73)
						{
							//cout << 73 << endl;
						}
						if (already_indexed.find(edge->node) != already_indexed.end())
						{
							continue;
						}
						//LABEL_TYPE tempL = 1;
						//tempL << (iter1->labels-1);
						new_pair.set_values(edge->node, (iter1->labels));
						new_pair_propagate.set_values(edge->node, (iter1->labels));

						new_pair.add_labels(convert_to_binary_label(edge->label));
						if (ppl_start)
						{
							if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
							{
								continue;
							}
						}
						new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

						NODE_TYPE cur_node = edge->node;
						in_label.set_values(i, new_pair.labels);// store the start node
						auto exist_index = index.find(cur_node);
						if (cur_node == 38)
						{
							//cout << 38 << endl;
						}
						if (exist_index == index.end())//first time to insert index for node cur_node
						{
							ppl_LCR_index new_in_out;
							new_in_out.insert_in_label(in_label);
							index.insert(std::make_pair(cur_node, new_in_out));
							temp_propagate.insert(new_pair_propagate);
						}
						else
						{
							auto exist_in = exist_index->second.in_labels.find(in_label.node);
							if (exist_in == exist_index->second.in_labels.end())
							{
								exist_index->second.insert_in_label(in_label);
								temp_propagate.insert(new_pair_propagate);
								continue;
							}
							if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
							{
								exist_index->second.insert_in_label(in_label);
								temp_propagate.insert(new_pair_propagate);
							}
						}
					}
				}
				cur_propagate = temp_propagate;
			}
			//when to stop 
			//reverse bfs
			cur_propagate_reverse.insert(src);
			while (!cur_propagate_reverse.empty())
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate_reverse.begin(); iter1 != cur_propagate_reverse.end(); iter1++)
				{
					for (auto edge = adjacency_list_reverse[iter1->node].begin(); edge != adjacency_list_reverse[iter1->node].end(); edge++)
					{

						if (already_indexed.find(edge->node) != already_indexed.end())
						{
							continue;
						}
						new_pair.set_values(edge->node, (iter1->labels));
						new_pair_propagate.set_values(edge->node, (iter1->labels));

						new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

						new_pair.add_labels(convert_to_binary_label(edge->label));
						if (ppl_start)
						{
							if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
							{
								continue;
							}
						}



						NODE_TYPE cur_node = edge->node;
						out_label.set_values(i, new_pair.labels);// store the start node
						auto exist_index = index.find(cur_node);
						if (exist_index == index.end())//first time to insert index for node cur_node
						{
							ppl_LCR_index new_in_out;
							new_in_out.insert_out_label(out_label);
							index.insert(std::make_pair(cur_node, new_in_out));
							temp_propagate.insert(new_pair_propagate);
						}
						else
						{
							auto exist_out = exist_index->second.out_labels.find(out_label.node);
							if (exist_out == exist_index->second.out_labels.end())
							{
								exist_index->second.insert_out_label(out_label);
								temp_propagate.insert(new_pair_propagate);
								continue;
							}
							if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
							{
								exist_index->second.insert_out_label(out_label);
								temp_propagate.insert(new_pair_propagate);
							}
						}
					}
				}
				cur_propagate_reverse = temp_propagate;
			}
			already_indexed.insert(i);
			ppl_start = true;
		}
		return true;
	}

	bool construct_label_index_definedorder(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num, vector<NODE_TYPE>& node_in_label, vector<NODE_TYPE>& node_out_label)
	{
		vector<NODE_TYPE> two_out_degrees;
		vector<NODE_TYPE> two_in_degrees;
		vector<NODE_TYPE> one_out_degrees;
		vector<NODE_TYPE> one_in_degrees;
		two_out_degrees.resize(node_num + 1);
		two_in_degrees.resize(node_num + 1);
		one_out_degrees.resize(node_num + 1);
		one_in_degrees.resize(node_num + 1);

		for (int i = 0; i < node_num; i++)
		{
			one_in_degrees[i] = adjacency_list_reverse[i].size();
			one_out_degrees[i] = adjacency_list[i].size();

			two_out_degrees[i] = 0;
			two_in_degrees[i] = 0;
			NODE_TYPE pre_node = INF;
			for (auto iter = adjacency_list[i].begin(); iter != adjacency_list[i].end(); iter++)
			{
				if (iter->node == pre_node)
				{
					continue;
				}
				pre_node = iter->node;
				two_out_degrees[i] += adjacency_list[iter->node].size();
			}
			pre_node = INF;

			for (auto iter = adjacency_list_reverse[i].begin(); iter != adjacency_list_reverse[i].end(); iter++)
			{
				if (iter->node == pre_node)
				{
					continue;
				}
				pre_node = iter->node;
				two_in_degrees[i] += adjacency_list_reverse[iter->node].size();
			}
		}
		cout << "end of 2-hop degree" << endl;
		auto index_start = chrono::high_resolution_clock::now();
		//sort by node degree
		vector<hot_degree> hot_points;
		for (NODE_TYPE i = 0; i < node_num; i++)
		{
			NODE_TYPE temp_in_size = node_in_label[i] +1;
			NODE_TYPE temp_out_size = node_out_label[i] +1;
			double temp_degree = adjacency_list[i].size() + adjacency_list_reverse[i].size();
			//double temp_degree;
			//if (temp_in_size == 0 || temp_out_size == 0)
			//{
			//	temp_degree = 0;
			//}
			//else {
				//temp_degree = two_out_degrees[i] + two_in_degrees[i];
				//temp_degree = (adjacency_list[i].size() * adjacency_list_reverse[i].size())/(adjacency_list[i].size() + adjacency_list_reverse[i].size()+1) *double(pow(2,temp_in_size) *pow(2, temp_out_size));
			//}
			hot_degree hd1(i, temp_degree);
			hot_points.push_back(hd1);
		}
		stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
		node_ranks.resize(node_num);
		NODE_TYPE temp_rank = 0;
		for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
		{
			node_ranks[node_explore->node] = temp_rank++;
		}
		ppl_LCR_pair src(0);
		set<ppl_LCR_pair> cur_propagate;
		set<ppl_LCR_pair> cur_propagate_reverse;
		set<ppl_LCR_pair> temp_propagate;
		ppl_LCR_pair new_pair;
		ppl_LCR_pair new_pair_propagate;
		ppl_LCR_pair in_label;
		//ppl_label_index new_in_out;
		ppl_LCR_pair out_label;
		set<NODE_TYPE> already_indexed;
		bool ppl_start = false;
		uint32_t timeout = 6*3600 * 6;//6hours
		int part = 0;

		//for (NODE_TYPE w = 0; w < node_num; w++)
		//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
		for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
		{
			/*for (NODE_TYPE k = 0; k < node_num; k++)
			{
				NODE_TYPE temp_in_size = node_in_label[k] + 1;
				NODE_TYPE temp_out_size = node_out_label[k] + 1;
				double temp_degree = one_in_degrees[k] + one_out_degrees[k];
				//double temp_degree;
				//if (temp_in_size == 0 || temp_out_size == 0)
				//{
				//	temp_degree = 0;
				//}
				//else {
				//temp_degree = two_out_degrees[i] + two_in_degrees[i];
				//temp_degree = (adjacency_list[i].size() * adjacency_list_reverse[i].size())/(adjacency_list[i].size() + adjacency_list_reverse[i].size()+1) *double(pow(2,temp_in_size) *pow(2, temp_out_size));
				//}
				hot_degree hd1(k, temp_degree);
				hot_points[k] = hd1;
			}
			stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
			*/
			part++;
			if (part > 10)
			{
				//break;
			}

			auto index_process = chrono::high_resolution_clock::now();
			auto diff = chrono::duration_cast<chrono::milliseconds>(index_process - index_start);
			if (diff.count() / 1e3 >= timeout)
			{
				cout << "time out to construct index" << endl;
				exit(1);
			}
			//NODE_TYPE i = hot_points[w].node;//node_explore->node;
			//const int N = sizeof(hot_points) / sizeof(hot_degree);
			//auto index_max = distance(hot_points.begin(), min_element(hot_points.begin(), hot_points.begin() + node_num));
			//hot_points[index_max].degree = 0;
			//cout << index_max << endl;
			NODE_TYPE i = node_explore->node;//hot_points[index_max].node;//node_explore->node;
			//cout << i << endl;
			/*for (auto iter = adjacency_list[i].begin(); iter != adjacency_list[i].end(); iter++)
			{
				hot_points[iter->node].degree--;
			}
			for (auto iter = adjacency_list_reverse[i].begin(); iter != adjacency_list_reverse[i].end(); iter++)
			{
				hot_points[iter->node].degree--;
			}*/

			src.node = i;
			src.labels = 0;
			if (i % 100000 == 0)
			{
				cout << i << endl;
			}
			//BFS to construct the index
			cur_propagate.clear();
			cur_propagate_reverse.clear();


			//forward bfs
			cur_propagate.insert(src);
			set<NODE_TYPE> visited_index_nodes;
			while (!cur_propagate.empty())
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate.begin(); iter1 != cur_propagate.end(); iter1++)
				{
					//cout << iter1->node << "\t" << cur_propagate.size() << "\t" << BitCount5(iter1->labels) << endl;
					for (auto edge = adjacency_list[iter1->node].begin(); edge != adjacency_list[iter1->node].end(); edge++)
					{
						if (edge->node == 73)
						{
							//cout << 73 << endl;
						}
						if (already_indexed.find(edge->node) != already_indexed.end())
						{
							continue;
						}
						//LABEL_TYPE tempL = 1;
						//tempL << (iter1->labels-1);
						new_pair.set_values(edge->node, (iter1->labels));
						new_pair_propagate.set_values(edge->node, (iter1->labels));

						new_pair.add_labels(convert_to_binary_label(edge->label));
						if (ppl_start)
						{
							if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
							{
								continue;
							}
						}
						new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

						NODE_TYPE cur_node = edge->node;
						in_label.set_values(i, new_pair.labels);// store the start node
						auto exist_index = index.find(cur_node);
						if (cur_node == 38)
						{
							//cout << 38 << endl;
						}
						if (exist_index == index.end())//first time to insert index for node cur_node
						{
							ppl_LCR_index new_in_out;
							new_in_out.insert_in_label(in_label);
							index.insert(std::make_pair(cur_node, new_in_out));
							temp_propagate.insert(new_pair_propagate);
						}
						else
						{
							auto exist_in = exist_index->second.in_labels.find(in_label.node);
							if (exist_in == exist_index->second.in_labels.end())
							{
								exist_index->second.insert_in_label(in_label);
								temp_propagate.insert(new_pair_propagate);
								continue;
							}
							if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
							{
								exist_index->second.insert_in_label(in_label);
								temp_propagate.insert(new_pair_propagate);
							}
						}
					}
				}
				cur_propagate = temp_propagate;
			}
			//when to stop 
			//reverse bfs
			cur_propagate_reverse.insert(src);
			while (!cur_propagate_reverse.empty())
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate_reverse.begin(); iter1 != cur_propagate_reverse.end(); iter1++)
				{
					for (auto edge = adjacency_list_reverse[iter1->node].begin(); edge != adjacency_list_reverse[iter1->node].end(); edge++)
					{

						if (already_indexed.find(edge->node) != already_indexed.end())
						{
							continue;
						}
						new_pair.set_values(edge->node, (iter1->labels));
						new_pair_propagate.set_values(edge->node, (iter1->labels));

						new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

						new_pair.add_labels(convert_to_binary_label(edge->label));
						if (ppl_start)
						{
							if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
							{
								continue;
							}
						}



						NODE_TYPE cur_node = edge->node;
						out_label.set_values(i, new_pair.labels);// store the start node
						auto exist_index = index.find(cur_node);
						if (exist_index == index.end())//first time to insert index for node cur_node
						{
							ppl_LCR_index new_in_out;
							new_in_out.insert_out_label(out_label);
							index.insert(std::make_pair(cur_node, new_in_out));
							temp_propagate.insert(new_pair_propagate);
						}
						else
						{
							auto exist_out = exist_index->second.out_labels.find(out_label.node);
							if (exist_out == exist_index->second.out_labels.end())
							{
								exist_index->second.insert_out_label(out_label);
								temp_propagate.insert(new_pair_propagate);
								continue;
							}
							if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
							{
								exist_index->second.insert_out_label(out_label);
								temp_propagate.insert(new_pair_propagate);
							}
						}
					}
				}
				cur_propagate_reverse = temp_propagate;
			}
			already_indexed.insert(i);
			ppl_start = true;
		}
		return true;
	}


bool construct_label_index_minimal_index(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num, vector<double>& node_in_label, vector<double>& node_out_label, vector<vector<label_edge>>* vec_adjacency_list, vector<vector<label_edge>>* vec_adjacency_list_reverse, int label_num)
{
	//vector<NODE_TYPE> two_out_degrees;
	//vector<NODE_TYPE> two_in_degrees;
	//vector<NODE_TYPE> one_out_degrees;
	//vector<NODE_TYPE> one_in_degrees;
	//two_out_degrees.resize(node_num + 1);
	//two_in_degrees.resize(node_num + 1);
	//one_out_degrees.resize(node_num + 1);
	//one_in_degrees.resize(node_num + 1);

	/*for (int i = 0; i < node_num; i++)
	{
	one_in_degrees[i] = adjacency_list_reverse[i].size();
	one_out_degrees[i] = adjacency_list[i].size();

	two_out_degrees[i] = 0;
	two_in_degrees[i] = 0;
	NODE_TYPE pre_node = INF;
	for (auto iter = adjacency_list[i].begin(); iter != adjacency_list[i].end(); iter++)
	{
	if (iter->node == pre_node)
	{
	continue;
	}
	pre_node = iter->node;
	two_out_degrees[i] += adjacency_list[iter->node].size();
	}
	pre_node = INF;

	for (auto iter = adjacency_list_reverse[i].begin(); iter != adjacency_list_reverse[i].end(); iter++)
	{
	if (iter->node == pre_node)
	{
	continue;
	}
	pre_node = iter->node;
	two_in_degrees[i] += adjacency_list_reverse[iter->node].size();
	}
	}*/
	cout << "end of 2-hop degree" << endl;
	auto index_start = chrono::high_resolution_clock::now();
	//sort by node degree
	vector<hot_degree> hot_points;
	for (NODE_TYPE i = 0; i < node_num; i++)
	{
		NODE_TYPE temp_in_size = node_in_label[i] + 1;
		NODE_TYPE temp_out_size = node_out_label[i] + 1;
		double temp_degree = 0;
		//for (int j = 0; j < label_num; j++)
		//{
			temp_degree += adjacency_list[i].size() + adjacency_list_reverse[i].size();
		//
		//double temp_degree;
		//if (temp_in_size == 0 || temp_out_size == 0)
		//{
		//	temp_degree = 0;
		//}
		//else {
		//temp_degree = two_out_degrees[i] + two_in_degrees[i];
		//temp_degree = (adjacency_list[i].size() * adjacency_list_reverse[i].size())/(adjacency_list[i].size() + adjacency_list_reverse[i].size()+1) *double(pow(2,temp_in_size) *pow(2, temp_out_size));
		//}
		hot_degree hd1(i,  temp_degree);

		//hot_degree hd1(i, temp_in_size*temp_out_size * 10000 + temp_degree);
		hot_points.push_back(hd1);
	}
	stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
	node_ranks.resize(node_num);
	NODE_TYPE temp_rank = 0;
	for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
	{
		node_ranks[node_explore->node] = temp_rank++;
	}
	ppl_LCR_pair src(0);
	set<ppl_LCR_pair> cur_propagate;
	set<ppl_LCR_pair> cur_propagate_reverse;
	set<ppl_LCR_pair> cur_propagate_plusone;
	set<ppl_LCR_pair> cur_propagate_reverse_plusone;

	set<ppl_LCR_pair> temp_propagate;
	ppl_LCR_pair new_pair;
	ppl_LCR_pair new_pair_propagate;
	ppl_LCR_pair in_label;
	//ppl_label_index new_in_out;
	ppl_LCR_pair out_label;
	set<NODE_TYPE> already_indexed;
	bool ppl_start = true;
	uint32_t timeout = 6*3600 * 6;//6hours
	int part = 0;

	//for (NODE_TYPE w = 0; w < node_num; w++)
	//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
	for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
	{

		auto index_process = chrono::high_resolution_clock::now();
		auto diff = chrono::duration_cast<chrono::milliseconds>(index_process - index_start);
		if (diff.count() / 1e3 >= timeout)
		{
			cout << "time out to construct index" << endl;
			exit(1);
		}
		//NODE_TYPE i = hot_points[w].node;//node_explore->node;
		//const int N = sizeof(hot_points) / sizeof(hot_degree);
		//auto index_max = distance(hot_points.begin(), min_element(hot_points.begin(), hot_points.begin() + node_num));
		//hot_points[index_max].degree = 0;
		//cout << index_max << endl;
		NODE_TYPE i = node_explore->node;//hot_points[index_max].node;//node_explore->node;


		src.node = i;
		src.labels = 0;
		//if (true)//i % 100000 == 0)
		//{
		//cout << i << endl;
		//}
		//BFS to construct the index
		cur_propagate.clear();
		cur_propagate_reverse.clear();
		cur_propagate_plusone.clear();
		cur_propagate_reverse_plusone.clear();

		//forward bfs
		cur_propagate.insert(src);
		set<NODE_TYPE> visited_index_nodes;
		while ((!cur_propagate.empty()) || (!cur_propagate_plusone.empty()))
		{
			while ((!cur_propagate.empty()))
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate.begin(); iter1 != cur_propagate.end(); iter1++)
				{

					//cout << "forward "<<iter1->node << "\t" << iter1->labels << endl;
					set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
					new_pair.set_values(iter1->node, (iter1->labels));
					cur_propagate_plusone.insert(new_pair);
					for (auto temp_label = temp_labels.begin(); temp_label != temp_labels.end(); temp_label++)
					{
						for (auto edge = vec_adjacency_list[iter1->node][*temp_label].begin(); edge != vec_adjacency_list[iter1->node][*temp_label].end(); edge++)
						{
							if (already_indexed.find(edge->node) != already_indexed.end())
							{
								continue;
							}
							//LABEL_TYPE tempL = 1;
							//tempL << (iter1->labels-1);
							new_pair.set_values(edge->node, (iter1->labels));
							new_pair_propagate.set_values(edge->node, (iter1->labels));

							new_pair.add_labels(convert_to_binary_label(edge->label));
							if (ppl_start)
							{
								if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
								{
									continue;
								}
							}
							new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

							NODE_TYPE cur_node = edge->node;
							in_label.set_values(i, new_pair.labels);// store the start node
							auto exist_index = index.find(cur_node);
							if (exist_index == index.end())//first time to insert index for node cur_node
							{
								ppl_LCR_index new_in_out;
								new_in_out.insert_in_label(in_label);
								index.insert(std::make_pair(cur_node, new_in_out));
								temp_propagate.insert(new_pair_propagate);
							}
							else
							{
								auto exist_in = exist_index->second.in_labels.find(in_label.node);
								if (exist_in == exist_index->second.in_labels.end())
								{
									exist_index->second.insert_in_label(in_label);
									temp_propagate.insert(new_pair_propagate);
									continue;
								}
								if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
								{
									exist_index->second.insert_in_label(in_label);
									temp_propagate.insert(new_pair_propagate);
								}
							}
						}
					}
				}
				cur_propagate = temp_propagate;
			}
			//while ((!cur_propagate_plusone.empty()))
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate_plusone.begin(); iter1 != cur_propagate_plusone.end(); iter1++)
				{
					set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
					new_pair.set_values(iter1->node, (iter1->labels));
					//cur_propagate_plusone.insert(new_pair);
					for (LABEL_TYPE temp_label = 0; temp_label < label_num; temp_label++)
					{
						if (temp_labels.find(temp_label) != temp_labels.end())
						{
							continue;
						}
						//cout << temp_label << endl;

						for (auto edge = vec_adjacency_list[iter1->node][temp_label].begin(); edge != vec_adjacency_list[iter1->node][temp_label].end(); edge++)
						{
							if (already_indexed.find(edge->node) != already_indexed.end())
							{
								continue;
							}
							//LABEL_TYPE tempL = 1;
							//tempL << (iter1->labels-1);
							new_pair.set_values(edge->node, (iter1->labels));
							new_pair_propagate.set_values(edge->node, (iter1->labels));

							new_pair.add_labels(convert_to_binary_label(edge->label));
							if (ppl_start)
							{
								if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
								{
									continue;
								}
							}
							new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

							NODE_TYPE cur_node = edge->node;
							in_label.set_values(i, new_pair.labels);// store the start node
							auto exist_index = index.find(cur_node);
							if (exist_index == index.end())//first time to insert index for node cur_node
							{
								ppl_LCR_index new_in_out;
								new_in_out.insert_in_label(in_label);
								index.insert(std::make_pair(cur_node, new_in_out));
								temp_propagate.insert(new_pair_propagate);
							}
							else
							{
								auto exist_in = exist_index->second.in_labels.find(in_label.node);
								if (exist_in == exist_index->second.in_labels.end())
								{
									exist_index->second.insert_in_label(in_label);
									temp_propagate.insert(new_pair_propagate);
									continue;
								}
								if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
								{
									exist_index->second.insert_in_label(in_label);
									temp_propagate.insert(new_pair_propagate);
								}
							}
						}
					}
				}
				cur_propagate = temp_propagate;
				cur_propagate_plusone.clear();
			}
		}
		//when to stop 
		//reverse bfs
		cur_propagate_reverse.insert(src);
		cur_propagate_reverse_plusone.clear();
		while ((!cur_propagate_reverse.empty()) || (!cur_propagate_reverse_plusone.empty()))
		{
			while ((!cur_propagate_reverse.empty()))
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate_reverse.begin(); iter1 != cur_propagate_reverse.end(); iter1++)
				{
					//cout << "backward " << iter1->node << "\t" << iter1->labels << endl;

					set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
					new_pair.set_values(iter1->node, (iter1->labels));
					cur_propagate_reverse_plusone.insert(new_pair);
					for (auto temp_label = temp_labels.begin(); temp_label != temp_labels.end(); temp_label++)
					{
						for (auto edge = vec_adjacency_list_reverse[iter1->node][*temp_label].begin(); edge != vec_adjacency_list_reverse[iter1->node][*temp_label].end(); edge++)
						{

							if (already_indexed.find(edge->node) != already_indexed.end())
							{
								continue;
							}
							new_pair.set_values(edge->node, (iter1->labels));
							new_pair_propagate.set_values(edge->node, (iter1->labels));

							new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

							new_pair.add_labels(convert_to_binary_label(edge->label));
							if (ppl_start)
							{
								if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
								{
									continue;
								}
							}



							NODE_TYPE cur_node = edge->node;
							out_label.set_values(i, new_pair.labels);// store the start node
							auto exist_index = index.find(cur_node);
							if (exist_index == index.end())//first time to insert index for node cur_node
							{
								ppl_LCR_index new_in_out;
								new_in_out.insert_out_label(out_label);
								index.insert(std::make_pair(cur_node, new_in_out));
								temp_propagate.insert(new_pair_propagate);
							}
							else
							{
								auto exist_out = exist_index->second.out_labels.find(out_label.node);
								if (exist_out == exist_index->second.out_labels.end())
								{
									exist_index->second.insert_out_label(out_label);
									temp_propagate.insert(new_pair_propagate);
									continue;
								}
								if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
								{
									exist_index->second.insert_out_label(out_label);
									temp_propagate.insert(new_pair_propagate);
								}
							}
						}
					}
				}
				cur_propagate_reverse = temp_propagate;
			}

			//while ((!cur_propagate_reverse_plusone.empty()))
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate_reverse_plusone.begin(); iter1 != cur_propagate_reverse_plusone.end(); iter1++)
				{
					set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
					new_pair.set_values(iter1->node, (iter1->labels));
					//cur_propagate_reverse_plusone.insert(new_pair);
					for (auto temp_label = 0; temp_label < label_num; temp_label++)
					{
						if (temp_labels.find(temp_label) != temp_labels.end())
						{
							continue;
						}
						for (auto edge = vec_adjacency_list_reverse[iter1->node][temp_label].begin(); edge != vec_adjacency_list_reverse[iter1->node][temp_label].end(); edge++)
						{

							if (already_indexed.find(edge->node) != already_indexed.end())
							{
								continue;
							}
							new_pair.set_values(edge->node, (iter1->labels));
							new_pair_propagate.set_values(edge->node, (iter1->labels));

							new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

							new_pair.add_labels(convert_to_binary_label(edge->label));
							if (ppl_start)
							{
								if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
								{
									continue;
								}
							}



							NODE_TYPE cur_node = edge->node;
							out_label.set_values(i, new_pair.labels);// store the start node
							auto exist_index = index.find(cur_node);
							if (exist_index == index.end())//first time to insert index for node cur_node
							{
								ppl_LCR_index new_in_out;
								new_in_out.insert_out_label(out_label);
								index.insert(std::make_pair(cur_node, new_in_out));
								temp_propagate.insert(new_pair_propagate);
							}
							else
							{
								auto exist_out = exist_index->second.out_labels.find(out_label.node);
								if (exist_out == exist_index->second.out_labels.end())
								{
									exist_index->second.insert_out_label(out_label);
									temp_propagate.insert(new_pair_propagate);
									continue;
								}
								if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
								{
									exist_index->second.insert_out_label(out_label);
									temp_propagate.insert(new_pair_propagate);
								}
							}
						}
					}
				}
				cur_propagate_reverse = temp_propagate;
				cur_propagate_reverse_plusone.clear();
			}

		}
		already_indexed.insert(i);
		ppl_start = true;
	}
	return true;
}
	bool construct_label_index_minimal_index_weighted_label(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num, vector<double>& node_in_label, vector<double>& node_out_label,vector<vector<label_edge>>* vec_adjacency_list, vector<vector<label_edge>>* vec_adjacency_list_reverse, int label_num, vector<double>& label_weight)
	{
		//vector<NODE_TYPE> two_out_degrees;
		//vector<NODE_TYPE> two_in_degrees;
		//vector<NODE_TYPE> one_out_degrees;
		//vector<NODE_TYPE> one_in_degrees;
		//two_out_degrees.resize(node_num + 1);
		//two_in_degrees.resize(node_num + 1);
		//one_out_degrees.resize(node_num + 1);
		//one_in_degrees.resize(node_num + 1);

		/*for (int i = 0; i < node_num; i++)
		{
			one_in_degrees[i] = adjacency_list_reverse[i].size();
			one_out_degrees[i] = adjacency_list[i].size();

			two_out_degrees[i] = 0;
			two_in_degrees[i] = 0;
			NODE_TYPE pre_node = INF;
			for (auto iter = adjacency_list[i].begin(); iter != adjacency_list[i].end(); iter++)
			{
				if (iter->node == pre_node)
				{
					continue;
				}
				pre_node = iter->node;
				two_out_degrees[i] += adjacency_list[iter->node].size();
			}
			pre_node = INF;

			for (auto iter = adjacency_list_reverse[i].begin(); iter != adjacency_list_reverse[i].end(); iter++)
			{
				if (iter->node == pre_node)
				{
					continue;
				}
				pre_node = iter->node;
				two_in_degrees[i] += adjacency_list_reverse[iter->node].size();
			}
		}*/
		cout << "end of 2-hop degree" << endl;
		auto index_start = chrono::high_resolution_clock::now();
		//sort by node degree
		vector<hot_degree> hot_points;
		for (NODE_TYPE i = 0; i < node_num; i++)
		{
			NODE_TYPE temp_in_size = node_in_label[i] + 1;
			NODE_TYPE temp_out_size = node_out_label[i] + 1;
			double temp_degree = 0;
			for (int j = 0; j < label_num; j++)
			{
				temp_degree += (vec_adjacency_list[i][j].size() + vec_adjacency_list_reverse[i][j].size()*1.0) / (label_weight[j]);//* label_weight[j]);
			}

			//double temp_degree;
			//if (temp_in_size == 0 || temp_out_size == 0)
			//{
			//	temp_degree = 0;
			//}
			//else {
			//temp_degree = two_out_degrees[i] + two_in_degrees[i];
			//temp_degree = (adjacency_list[i].size() * adjacency_list_reverse[i].size())/(adjacency_list[i].size() + adjacency_list_reverse[i].size()+1) *double(pow(2,temp_in_size) *pow(2, temp_out_size));
			//}

			hot_degree hd1(i,  temp_degree);
			hot_points.push_back(hd1);
		}
		stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
		node_ranks.resize(node_num);
		NODE_TYPE temp_rank = 0;
		for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
		{
			node_ranks[node_explore->node] = temp_rank++;
			//cout << node_explore->node << "\t" << node_explore->degree << endl;
		}
		ppl_LCR_pair src(0);
		set<ppl_LCR_pair> cur_propagate;
		set<ppl_LCR_pair> cur_propagate_reverse;
		set<ppl_LCR_pair> cur_propagate_plusone;
		set<ppl_LCR_pair> cur_propagate_reverse_plusone;

		set<ppl_LCR_pair> temp_propagate;
		ppl_LCR_pair new_pair;
		ppl_LCR_pair new_pair_propagate;
		ppl_LCR_pair in_label;
		//ppl_label_index new_in_out;
		ppl_LCR_pair out_label;
		set<NODE_TYPE> already_indexed;
		bool ppl_start = true;
		uint32_t timeout = 6*3600 * 6;//6hours
		int part = 0;

		//for (NODE_TYPE w = 0; w < node_num; w++)
		//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
		for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
		{
		
			auto index_process = chrono::high_resolution_clock::now();
			auto diff = chrono::duration_cast<chrono::milliseconds>(index_process - index_start);
			if (diff.count() / 1e3 >= timeout)
			{
				cout << "time out to construct index" << endl;
				exit(1);
			}
			//NODE_TYPE i = hot_points[w].node;//node_explore->node;
			//const int N = sizeof(hot_points) / sizeof(hot_degree);
			//auto index_max = distance(hot_points.begin(), min_element(hot_points.begin(), hot_points.begin() + node_num));
			//hot_points[index_max].degree = 0;
			//cout << index_max << endl;
			NODE_TYPE i = node_explore->node;//hot_points[index_max].node;//node_explore->node;


			src.node = i;
			src.labels = 0;
			//if (true)//i % 100000 == 0)
			//{
			//	cout << i << endl;
			//}
			//BFS to construct the index
			cur_propagate.clear();
			cur_propagate_reverse.clear();
			cur_propagate_plusone.clear();
			cur_propagate_reverse_plusone.clear();

			//forward bfs
			cur_propagate.insert(src);
			set<NODE_TYPE> visited_index_nodes;
			while ((!cur_propagate.empty()) || (!cur_propagate_plusone.empty()))
			{
				while ((!cur_propagate.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate.begin(); iter1 != cur_propagate.end(); iter1++)
					{
						
						//cout << "forward "<<iter1->node << "\t" << iter1->labels << endl;
						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						cur_propagate_plusone.insert(new_pair);
						for (auto temp_label = temp_labels.begin(); temp_label != temp_labels.end(); temp_label++)
						{
							for (auto edge = vec_adjacency_list[iter1->node][*temp_label].begin(); edge != vec_adjacency_list[iter1->node][*temp_label].end(); edge++)
							{
								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									continue;
								}
								//LABEL_TYPE tempL = 1;
								//tempL << (iter1->labels-1);
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
									{
										continue;
									}
								}
								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								NODE_TYPE cur_node = edge->node;
								in_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_in_label(in_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_in = exist_index->second.in_labels.find(in_label.node);
									if (exist_in == exist_index->second.in_labels.end())
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate = temp_propagate;
				}
				//while ((!cur_propagate_plusone.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate_plusone.begin(); iter1 != cur_propagate_plusone.end(); iter1++)
					{
						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						//cur_propagate_plusone.insert(new_pair);
						for (LABEL_TYPE temp_label = 0; temp_label < label_num; temp_label++)
						{
							if (temp_labels.find(temp_label) != temp_labels.end())
							{
								continue;
							}
							//cout << temp_label << endl;
						
							for (auto edge = vec_adjacency_list[iter1->node][temp_label].begin(); edge != vec_adjacency_list[iter1->node][temp_label].end(); edge++)
							{
								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									continue;
								}
								//LABEL_TYPE tempL = 1;
								//tempL << (iter1->labels-1);
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
									{
										continue;
									}
								}
								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								NODE_TYPE cur_node = edge->node;
								in_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_in_label(in_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_in = exist_index->second.in_labels.find(in_label.node);
									if (exist_in == exist_index->second.in_labels.end())
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate = temp_propagate;
					cur_propagate_plusone.clear();
				}
			}
			//when to stop 
			//reverse bfs
			cur_propagate_reverse.insert(src);
			cur_propagate_reverse_plusone.clear();
			while ((!cur_propagate_reverse.empty()) || (!cur_propagate_reverse_plusone.empty()))
			{
				while ((!cur_propagate_reverse.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate_reverse.begin(); iter1 != cur_propagate_reverse.end(); iter1++)
					{
						//cout << "backward " << iter1->node << "\t" << iter1->labels << endl;

						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						cur_propagate_reverse_plusone.insert(new_pair);
						for (auto temp_label = temp_labels.begin(); temp_label != temp_labels.end(); temp_label++)
						{
							for (auto edge = vec_adjacency_list_reverse[iter1->node][*temp_label].begin(); edge != vec_adjacency_list_reverse[iter1->node][*temp_label].end(); edge++)
							{

								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									continue;
								}
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
									{
										continue;
									}
								}



								NODE_TYPE cur_node = edge->node;
								out_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_out_label(out_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_out = exist_index->second.out_labels.find(out_label.node);
									if (exist_out == exist_index->second.out_labels.end())
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate_reverse = temp_propagate;
				}

				//while ((!cur_propagate_reverse_plusone.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate_reverse_plusone.begin(); iter1 != cur_propagate_reverse_plusone.end(); iter1++)
					{
						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						//cur_propagate_reverse_plusone.insert(new_pair);
						for (auto temp_label = 0; temp_label < label_num; temp_label++)
						{
							if (temp_labels.find(temp_label) != temp_labels.end())
							{
								continue;
							}
							for (auto edge = vec_adjacency_list_reverse[iter1->node][temp_label].begin(); edge != vec_adjacency_list_reverse[iter1->node][temp_label].end(); edge++)
							{

								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									continue;
								}
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
									{
										continue;
									}
								}



								NODE_TYPE cur_node = edge->node;
								out_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_out_label(out_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_out = exist_index->second.out_labels.find(out_label.node);
									if (exist_out == exist_index->second.out_labels.end())
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate_reverse = temp_propagate;
					cur_propagate_reverse_plusone.clear();
				}
			
			}
			already_indexed.insert(i);
			ppl_start = true;
		}
		return true;
	}

	NodeID labeling_source_bfs_directed(NodeID source, tree& parent_tree, tree& r_parent_tree, vector<NodeID>& coverage, vector<NodeID>& r_coverage, vector<NodeID>& descendants, vector<NodeID>& r_descendants, vector<NodeID>& root_hop, vector<NodeID>& r_root_hop, vector<NodeID>& que, vector<bool>& vis, vector<EdgeWeight>& dst_r, vector<EdgeWeight>& r_dst_r, vector<bool>& usd, NodeID ranking, vector<pair<vector<NodeID>, vector<EdgeWeight> > >& tmp_idx, vector<pair<vector<NodeID>, vector<EdgeWeight> > >& r_tmp_idx, Graph_order& graph) {
		descendants.clear();
		r_descendants.clear();
		NodeID visited_arcs = 0;

		// Forward search.
		// Initialize forward labels of r.
		const pair<vector<NodeID>, vector<EdgeWeight> > &tmp_idx_r = tmp_idx[source];

		for (size_t i = 0; i < tmp_idx_r.first.size(); ++i) {
			dst_r[tmp_idx_r.first[i]] = tmp_idx_r.second[i];
		}

		NodeID que_t0 = 0, que_t1 = 0, que_h = 0;
		que[que_h++] = source;
		vis[source] = true;
		que_t1 = que_h;
		parent_tree[source] = graph.numOfVertices;
		root_hop[source] = 0;

		for (EdgeWeight d = 0; que_t0 < que_h; d = d + 1) {
			for (NodeID que_i = que_t0; que_i < que_t1; ++que_i) {
				NodeID v = que[que_i];
				pair<vector<NodeID>, vector<EdgeWeight> > &r_tmp_idx_v = r_tmp_idx[v];
				//index_t &idx_v = index_[inv[v]];

				if (usd[v]) continue;

				// Pruned by the forward labels of r and backward labels of v in the forward search from r when reaching v.
				for (size_t i = 0; i < r_tmp_idx_v.first.size(); ++i) {
					NodeID w = r_tmp_idx_v.first[i];
					EdgeWeight td = r_tmp_idx_v.second[i] + dst_r[w];
					if (td <= d) {
						goto pruned_forward;
					}
				}

				// Traverse
				r_tmp_idx_v.first.back() = ranking;
				r_tmp_idx_v.second.back() = d;
				r_tmp_idx_v.first.push_back(graph.numOfVertices);
				r_tmp_idx_v.second.push_back(INF_WEIGHT);
				descendants.push_back(v);

				for (EdgeID eid = graph.vertices[v]; eid < graph.vertices[v + 1]; ++eid) {
					NodeID w = graph.edges[eid];
					if (!vis[w]) {
						que[que_h++] = w;
						vis[w] = true;
						parent_tree[w] = v;
						root_hop[w] = root_hop[v] + 1;
					}
				}
			pruned_forward:
				{}
			}
			que_t0 = que_t1;
			que_t1 = que_h;
		}
		for (size_t i = 0; i < que_h; ++i) vis[que[i]] = false;
		for (size_t i = 0; i < tmp_idx_r.first.size(); ++i)
			dst_r[tmp_idx_r.first[i]] = INF_WEIGHT;


		// Backward search.
		// Initialize backward labels of r.
		const pair<vector<NodeID>, vector<EdgeWeight> > &r_tmp_idx_r = r_tmp_idx[source];

		for (size_t i = 0; i < r_tmp_idx_r.first.size(); ++i) {
			r_dst_r[r_tmp_idx_r.first[i]] = r_tmp_idx_r.second[i];
		}


		que_t0 = 0, que_t1 = 0, que_h = 0;
		que[que_h++] = source;
		vis[source] = true;
		que_t1 = que_h;
		r_parent_tree[source] = graph.numOfVertices;
		r_root_hop[source] = 0;

		for (EdgeWeight d = 0; que_t0 < que_h; d = d + 1) {
			for (NodeID que_i = que_t0; que_i < que_t1; ++que_i) {
				NodeID v = que[que_i];
				pair<vector<NodeID>, vector<EdgeWeight> > &tmp_idx_v = tmp_idx[v];
				//index_t &idx_v = index_[inv[v]];

				if (usd[v]) continue;

				// Pruned by the backward labels of r and forward labels of v in the backward search from r when reaching v (v->r path).
				for (size_t i = 0; i < tmp_idx_v.first.size(); ++i) {
					NodeID w = tmp_idx_v.first[i];
					EdgeWeight td = tmp_idx_v.second[i] + r_dst_r[w];
					if (td <= d) {
						goto pruned_backward;
					}
				}

				// Traverse
				tmp_idx_v.first.back() = ranking;
				tmp_idx_v.second.back() = d;
				tmp_idx_v.first.push_back(graph.numOfVertices);
				tmp_idx_v.second.push_back(INF_WEIGHT);
				r_descendants.push_back(v);

				// Array Representation
				for (EdgeID eid = graph.r_vertices[v]; eid < graph.r_vertices[v + 1]; ++eid) {
					NodeID w = graph.r_edges[eid];

					if (!vis[w]) {
						que[que_h++] = w;
						vis[w] = true;
						r_parent_tree[w] = v;
						r_root_hop[w] = r_root_hop[v] + 1;
					}
				}
			pruned_backward:
				{}
			}
			que_t0 = que_t1;
			que_t1 = que_h;
		}
		for (size_t i = 0; i < que_h; ++i) vis[que[i]] = false;
		for (size_t i = 0; i < r_tmp_idx_r.first.size(); ++i)
			r_dst_r[r_tmp_idx_r.first[i]] = INF_WEIGHT;

		usd[source] = true;
		return visited_arcs;
	}

	void calcover(vector<NodeID>& descendants, tree& parent_tree, vector<NodeID>& coverage, vector<NodeID>& root_hop, vector<NodeID>& last_alive, vector<NodeID>& depth, NodeID numOfVertices) {
		for (NodeID di = descendants.size() - 1; di > -1; --di) {
			NodeID dv = descendants[di];
			// source - pv - dv: set cover of dv to 0(because they have been covered by pv).
			coverage[dv]++;
			//acc[dv]++;
			if (parent_tree[dv] != numOfVertices) {
				coverage[parent_tree[dv]] += coverage[dv];
				//acc[parent_tree[dv]]++;	
				if (depth[dv] < root_hop[dv])
					depth[dv] = root_hop[dv];
				if (depth[dv] > root_hop[parent_tree[dv]]) {
					depth[parent_tree[dv]] = depth[dv];
				}
				last_alive[dv] = coverage[dv];
			}
		}
		return;
	}

	void calcover(vector<NodeID>& descendants, tree& parent_tree, vector<NodeID>& coverage, vector<NodeID>& root_hop, NodeID numOfVertices) {
		for (NodeID di = descendants.size() - 1; di > -1; --di) {
			NodeID dv = descendants[di];
			coverage[dv]++;
			if (parent_tree[dv] != numOfVertices) {
				coverage[parent_tree[dv]] += coverage[dv];
			}
		}
		return;
	}

	void clear_tmp(vector<NodeID>& descendants, vector<NodeID>& coverage, tree& parent_tree, vector<NodeID>& root_hop, vector<NodeID>& depth, NodeID numOfVertices) {
		for (NodeID di = descendants.size() - 1; di > -1; --di) {
			NodeID dv = descendants[di];
			// source - pv - dv: set cover of dv to 0(because they have been covered by pv).
			coverage[dv] = 0;
			if (parent_tree[dv] != numOfVertices)
				coverage[parent_tree[dv]] = 0;
			parent_tree[dv] = numOfVertices;
			root_hop[dv] = 0;
			depth[dv] = 0;
		}
		descendants.clear();
		return;
	}


	vector<NodeID> findRevSigPath(NodeID source, vector<NodeID>& coverage, vector<NodeID>& r_coverage, tree& parent_tree, tree& r_parent_tree, vector<bool>& usd, Graph_order& graph) {
		vector<NodeID> sigpath;
		NodeID v = source;
		NodeID max_degree = -1;
		while (true) {
			NodeID max_v = v;
			NodeID max_cover = -1;
			bool non_leaf_flag = false;
			if (max_degree < (graph.vertices[v + 1] - graph.vertices[v]) * (graph.r_vertices[v + 1] - graph.r_vertices[v]))
				max_degree = (graph.vertices[v + 1] - graph.vertices[v]) * (graph.r_vertices[v + 1] - graph.r_vertices[v]);
			for (EdgeID eid = graph.vertices[v]; eid < graph.vertices[v + 1]; ++eid) {
				NodeID w = graph.edges[eid];
				if (parent_tree[w] == v && usd[w] == false) {
					non_leaf_flag = true;
					if (max_cover < coverage[w] + r_coverage[w]) {
						max_cover = coverage[w] + r_coverage[w];
						max_v = w;
					}
				}
			}
			if (non_leaf_flag == false) break;
			v = max_v;
			sigpath.push_back(v);
		}

		vector<NodeID> rev_sigpath;
		v = source;
		NodeID max_degree_rev = -1;
		while (true) {
			NodeID max_v = v;
			NodeID max_cover = -1;
			bool non_leaf_flag = false;
			if (max_degree_rev < (graph.r_vertices[v + 1] - graph.r_vertices[v]) * (graph.vertices[v + 1] - graph.vertices[v]))
				max_degree_rev = (graph.r_vertices[v + 1] - graph.r_vertices[v]) * (graph.vertices[v + 1] - graph.vertices[v]);
			for (EdgeID eid = graph.r_vertices[v]; eid < graph.r_vertices[v + 1]; ++eid) {
				NodeID w = graph.r_edges[eid];
				if (r_parent_tree[w] == v && usd[w] == false) {
					non_leaf_flag = true;
					if (max_cover < r_coverage[w] + coverage[w]) {
						max_cover = r_coverage[w] + coverage[w];
						max_v = w;
					}
				}
			}
			if (non_leaf_flag == false) break;
			v = max_v;
			rev_sigpath.push_back(v);
		}
		/*
		cout << "sig path len:" << sigpath.size() << endl;
		NodeID maxd = -1;
		NodeID maxcd = -1;
		NodeID maxd_choice = -1;
		NodeID maxcd_choice = -1;
		if(sigpath.size()!=0){
		for(NodeID i = 0; i < sigpath.size(); ++i){
		//	cout << i << ":" << (graph.vertices[sigpath[i]+1] - graph.vertices[sigpath[i]]) *(graph.r_vertices[sigpath[i]+1] - graph.r_vertices[sigpath[i]]) << " ";
		if(maxd<(graph.vertices[sigpath[i]+1] - graph.vertices[sigpath[i]]) *(graph.r_vertices[sigpath[i]+1] - graph.r_vertices[sigpath[i]])){
		maxd_choice = i;
		maxd = (graph.vertices[sigpath[i]+1] - graph.vertices[sigpath[i]]) *(graph.r_vertices[sigpath[i]+1] - graph.r_vertices[sigpath[i]]);
		}
		}
		cout << endl;
		for(NodeID i = 0; i < sigpath.size() - 1; ++i){
		//cout << i << ":" << (graph.vertices[sigpath[i]+1] - graph.vertices[sigpath[i]]) *(graph.r_vertices[sigpath[i]+1] - graph.r_vertices[sigpath[i]]) * abs(coverage[sigpath[i+1]] - coverage[sigpath[i]]) << " ";
		if(maxcd < (graph.vertices[sigpath[i]+1] - graph.vertices[sigpath[i]]) *(graph.r_vertices[sigpath[i]+1] - graph.r_vertices[sigpath[i]]) * abs(coverage[sigpath[i+1]] - coverage[sigpath[i]])){
		maxcd = (graph.vertices[sigpath[i]+1] - graph.vertices[sigpath[i]]) *(graph.r_vertices[sigpath[i]+1] - graph.r_vertices[sigpath[i]]) * abs(coverage[sigpath[i+1]] - coverage[sigpath[i]]);
		maxcd_choice = i;
		}
		}
		//	cout << endl;
		//cout << maxd_choice << " vs. " << maxcd_choice << endl;

		//for(NodeID i = 0; i < sigpath.size() - 1; ++i)
		//	cout << i << ":" << (graph.vertices[sigpath[i+1]+1] - graph.vertices[sigpath[i+1]]) *(graph.r_vertices[sigpath[i+1]+1] - graph.r_vertices[sigpath[i+1]]) * abs(coverage[sigpath[i+1]] - coverage[sigpath[i]]) << " ";
		//cout << endl;
		}

		cout << "rev sig path len:" << rev_sigpath.size() << endl;
		maxd_choice = -1;
		maxcd_choice = -1;
		NodeID rev_maxd = -1;
		NodeID rev_maxcd = -1;
		if(rev_sigpath.size()!=0){
		for(NodeID i = 0; i < rev_sigpath.size(); ++i){
		//cout << i << ":" << (graph.vertices[rev_sigpath[i]+1] - graph.vertices[rev_sigpath[i]]) * (graph.r_vertices[rev_sigpath[i]+1] - graph.r_vertices[rev_sigpath[i]]) << " ";
		if(rev_maxd <  (graph.vertices[rev_sigpath[i]+1] - graph.vertices[rev_sigpath[i]]) * (graph.r_vertices[rev_sigpath[i]+1] - graph.r_vertices[rev_sigpath[i]])){
		rev_maxd =  (graph.vertices[rev_sigpath[i]+1] - graph.vertices[rev_sigpath[i]]) * (graph.r_vertices[rev_sigpath[i]+1] - graph.r_vertices[rev_sigpath[i]]);
		maxd_choice = i;
		}
		}
		cout << endl;
		//for(NodeID i = 0; i < rev_sigpath.size() - 1; ++i)
		//	cout << i << ":" << abs(r_coverage[rev_sigpath[i+1]] - r_coverage[rev_sigpath[i]]) << " ";
		//cout << endl;
		for(NodeID i = 0; i < rev_sigpath.size() - 1; ++i){
		//cout << i << ":" << (graph.vertices[rev_sigpath[i]+1] - graph.vertices[rev_sigpath[i]]) * (graph.r_vertices[rev_sigpath[i]+1] - graph.r_vertices[rev_sigpath[i]]) * abs(r_coverage[rev_sigpath[i+1]] - r_coverage[rev_sigpath[i]]) << " ";
		if(rev_maxcd <(graph.vertices[rev_sigpath[i]+1] - graph.vertices[rev_sigpath[i]]) * (graph.r_vertices[rev_sigpath[i]+1] - graph.r_vertices[rev_sigpath[i]]) * abs(r_coverage[rev_sigpath[i+1]] - r_coverage[rev_sigpath[i]]) ){
		rev_maxcd = (graph.vertices[rev_sigpath[i]+1] - graph.vertices[rev_sigpath[i]]) * (graph.r_vertices[rev_sigpath[i]+1] - graph.r_vertices[rev_sigpath[i]]) * abs(r_coverage[rev_sigpath[i+1]] - r_coverage[rev_sigpath[i]]);
		maxcd_choice = i;
		}
		}
		//	cout << endl;
		//	cout << maxd_choice << " vs. " << maxcd_choice << endl;
		}
		*/


		if (max_degree < max_degree_rev) {
			reverse(rev_sigpath.begin(), rev_sigpath.end());
			sigpath = rev_sigpath;
		}

		return sigpath;
	}

	vector<NodeID> findRevSigPath(NodeID source, vector<NodeID>& coverage, vector<NodeID>& r_coverage, tree& parent_tree, tree& r_parent_tree, vector<bool>& usd, WGraph_order& wgraph, NodeID& maxdegree, bool& reverse_flag) {
		vector<NodeID> sigpath;
		NodeID v = source;
		NodeID max_degree = -1;
		while (true) {
			NodeID max_v = v;
			NodeID max_cover = -1;
			bool non_leaf_flag = false;
			if (max_degree < (wgraph.vertices[v + 1] - wgraph.vertices[v]) * (wgraph.r_vertices[v + 1] - wgraph.r_vertices[v]))
				max_degree = (wgraph.vertices[v + 1] - wgraph.vertices[v]) * (wgraph.r_vertices[v + 1] - wgraph.r_vertices[v]);
			for (EdgeID eid = wgraph.vertices[v]; eid < wgraph.vertices[v + 1]; ++eid) {
				NodeID w = wgraph.edges[eid].first;
				if (parent_tree[w] == v && usd[w] == false) {
					non_leaf_flag = true;
					NodeID c_coverage = coverage[w] * (wgraph.r_vertices[v + 1] - wgraph.r_vertices[v]);// + r_coverage[w];//(wgraph.r_vertices[v + 1] - wgraph.r_vertices[v]); //coverage[w] + r_coverage[w]						
					if (max_cover < c_coverage) {
						max_cover = c_coverage;
						max_v = w;
					}
				}
			}
			if (non_leaf_flag == false) break;
			v = max_v;
			sigpath.push_back(v);
		}

		vector<NodeID> rev_sigpath;
		v = source;
		NodeID max_degree_rev = -1;
		while (true) {
			NodeID max_v = v;
			NodeID max_cover = -1;
			bool non_leaf_flag = false;
			if (max_degree_rev < (wgraph.r_vertices[v + 1] - wgraph.r_vertices[v]) * (wgraph.vertices[v + 1] - wgraph.vertices[v]))
				max_degree_rev = (wgraph.r_vertices[v + 1] - wgraph.r_vertices[v]) * (wgraph.vertices[v + 1] - wgraph.vertices[v]);
			for (EdgeID eid = wgraph.r_vertices[v]; eid < wgraph.r_vertices[v + 1]; ++eid) {
				NodeID w = wgraph.r_edges[eid].first;
				if (r_parent_tree[w] == v && usd[w] == false) {
					non_leaf_flag = true;
					NodeID c_coverage = r_coverage[w] * (wgraph.vertices[v + 1] - wgraph.vertices[v]);// + coverage[w];// (wgraph.vertices[v + 1] - wgraph.vertices[v]); //r_coverage[w] + coverage[w];
					if (max_cover < c_coverage) {
						max_cover = c_coverage;
						max_v = w;
					}
				}
			}
			if (non_leaf_flag == false) break;
			v = max_v;
			rev_sigpath.push_back(v);
		}

		maxdegree = max_degree;
		reverse_flag = false;

		if (max_degree < max_degree_rev) {
			reverse(rev_sigpath.begin(), rev_sigpath.end());
			sigpath = rev_sigpath;
			maxdegree = max_degree_rev;
			reverse_flag = true;
		} /*
		  if(coverage[0] < r_coverage[0]){
		  reverse_flag = true;
		  }*/

		return sigpath;
	}
	NodeID topcan(vector<NodeID>& inv, vector<bool>& usd, NodeID& last_available) {
		while (true) {
			NodeID v = inv[last_available];
			if (usd[v] == false)
				return v;
			else
				last_available++;
		}
	}


	void directed_unweighted_sigpath(Graph_order& graph, vector<NodeID>& rank) {
		cout << "Building Coverage Ordering Based Labels" << endl;
		NodeID last_available;
		vector<NodeID> inv;
		NodeID numOfVertices = graph.numOfVertices;
		inv.resize(numOfVertices);
		rank.resize(numOfVertices);

		vector<NodeID> deg_inv;
		vector<NodeID> deg_rank;
		deg_inv.resize(numOfVertices);
		deg_rank.resize(numOfVertices);

		vector<pair<float, NodeID> > deg(numOfVertices);
		for (size_t v = 0; v < numOfVertices; ++v) {
			deg[v] = make_pair((graph.vertices[v + 1] - graph.vertices[v]) * (graph.r_vertices[v + 1] - graph.r_vertices[v]) + float(rand()) / RAND_MAX, v);
		}
		sort(deg.rbegin(), deg.rend());
		for (size_t v = 0; v < numOfVertices; ++v) deg_inv[v] = deg[v].second;

		last_available = 0;

		vector<NodeID> parent_tree(numOfVertices, numOfVertices);
		vector<NodeID> r_parent_tree(numOfVertices, numOfVertices);
		vector<NodeID> root_hop(numOfVertices, 0);
		vector<NodeID> r_root_hop(numOfVertices, 0);
		vector<NodeID> coverage(numOfVertices, 0);
		vector<NodeID> r_coverage(numOfVertices, 0);
		vector<NodeID> depth(numOfVertices, 0);
		vector<NodeID> last_alive(numOfVertices, 0);
		vector<NodeID> last_hop(numOfVertices, 0);
		vector<NodeID> descendants;
		descendants.reserve(numOfVertices);
		vector<NodeID> r_descendants;
		r_descendants.reserve(numOfVertices);

		vector<NodeID> candidate;
		candidate.reserve(numOfVertices);

		vector<NodeID> acc_count;
		acc_count.resize(numOfVertices);

		vector<bool> vis(numOfVertices);
		vector<bool> usd(numOfVertices, false);
		vector<NodeID> que(numOfVertices);
		// Preparing basic structure for pl algorithm.
		vector<EdgeWeight> dst_r(numOfVertices + 1, INF_WEIGHT);
		vector<EdgeWeight> r_dst_r(numOfVertices + 1, INF_WEIGHT);
		vector<pair<vector<NodeID>, vector<EdgeWeight> > >
			tmp_idx(numOfVertices, make_pair(vector<NodeID>(1, numOfVertices),
				vector<EdgeWeight>(1, INF_WEIGHT)));
		vector<pair<vector<NodeID>, vector<EdgeWeight> > >
			r_tmp_idx(numOfVertices, make_pair(vector<NodeID>(1, numOfVertices),
				vector<EdgeWeight>(1, INF_WEIGHT)));

		NodeID chosen = deg_inv[0];

		NodeID taken = numOfVertices;// / 10;
		NodeID last_iter_cover = 0;
		NodeID last_iter_hop = 0;
		unordered_map<int, double> actual_stats;
		unordered_map<int, double> over_stats;

		vector<NodeID> upwardcoverage(numOfVertices, 0);

		long long currentsum = 0;

		for (NodeID i = 0; i < taken; ++i) {
			inv[i] = chosen;
			rank[chosen] = i;
			if (usd[chosen] == true) cout << "shit" << endl;
			NodeID actual_cover = labeling_source_bfs_directed(chosen, parent_tree, r_parent_tree, coverage, r_coverage, descendants, r_descendants, root_hop, r_root_hop, que, vis, dst_r, r_dst_r, usd, i, tmp_idx, r_tmp_idx, graph);
			currentsum += actual_cover;

			if (i == numOfVertices - 1) break;

			calcover(descendants, parent_tree, coverage, root_hop, numOfVertices);
			calcover(r_descendants, r_parent_tree, r_coverage, r_root_hop,numOfVertices);


			vector<NodeID> sigpath = findRevSigPath(chosen, coverage, r_coverage, parent_tree, r_parent_tree, usd, graph);
			//vector<NodeID> sigrevpath = findSigRevPath(chosen, r_coverage, r_parent_tree, usd, graph);


			if (sigpath.size() <= 2) {
				chosen = topcan(deg_inv, usd, last_available);
			}

			NodeID maxDegree = -1;
			NodeID minDegree = 9999999999;
			NodeID chosenhop = -1;

			for (NodeID j = 0; j < sigpath.size(); ++j) {
				NodeID fcd = graph.vertices[sigpath[j] + 1] - graph.vertices[sigpath[j]];
				NodeID bcd = graph.r_vertices[sigpath[j] + 1] - graph.r_vertices[sigpath[j]];
				NodeID curDegree = (graph.vertices[sigpath[j] + 1] - graph.vertices[sigpath[j]]) * (graph.r_vertices[sigpath[j] + 1] - graph.r_vertices[sigpath[j]]);
				//NodeID curDegree = coverage[sigpath[j]] * r_coverage[sigpath[j]];
				//cout << j << ":" << curDegree << " ";
				if (curDegree > maxDegree) {
					maxDegree = curDegree;
					chosen = sigpath[j];
					chosenhop = j;
				}
				if (curDegree < minDegree)
					minDegree = curDegree;
			}
			//	if(maxDegree != -1)
			//		cout << maxDegree / minDegree << "," << sigpath.size() << endl;

			//cout << endl;	

			/*if(sigpath.size()>2){
			NodeID maxtrend = -1;
			NodeID chosentrend = 0;
			//cout << "Coverage Trends:";
			for(NodeID j = 1; j < sigpath.size() - 1; ++j){
			//NodeID curDegree = wgraph.vertices[sigpath[j] +1] - wgraph.vertices[sigpath[j]];
			//cout << " " << curDegree;
			//NodeID curDegree = wgraph.vertices[sigpath[j] +1] - wgraph.vertices[sigpath[j]];
			//cout << " " <<  j << ":" << abs(coverage[sigpath[j+1]] - coverage[sigpath[j]]);
			if(maxtrend <  abs(coverage[sigpath[j+1]]   - coverage[sigpath[j]] )){
			maxtrend = abs(coverage[sigpath[j+1]]   - coverage[sigpath[j]]);
			chosentrend = j;
			chosen = sigpath[j];
			chosenhop = j;
			}
			}
			} */

			if (usd[chosen] == true) {
				for (NodeID j = 0; j < sigpath.size(); ++j)
					cout << usd[sigpath[j]] << ",";
				cout << endl;
			}

			/*	for(NodeID j = 0; j < sigpath.size(); ++j){
			cout << j << ":" << coverage[sigpath[j]] << " ";
			}
			cout << endl;

			for(NodeID j = 0; j < sigpath.size(); ++j){
			cout << j << ":" << r_coverage[sigpath[j]] << " ";
			}
			cout << endl;

			for(NodeID j = 0; j < sigpath.size() - 1; ++j){
			cout << j << ":" << abs(coverage[sigpath[j]] - coverage[sigpath[j+1]]) << " ";
			}
			cout << endl;

			for(NodeID j = 0; j < sigpath.size() - 1; ++j){
			cout << j << ":" << abs(r_coverage[sigpath[j]] - r_coverage[sigpath[j+1]]) << " ";
			}

			cout << endl;
			//cout << chosentrend << endl;
			*/
			//cout << "iteration:" << i << " - " << currentsum << " - " << usd[chosen] << "-" << chosenhop << " - " << sigpath.size() << endl;

			clear_tmp(descendants, coverage, parent_tree, root_hop, depth, numOfVertices);
			clear_tmp(r_descendants, r_coverage, r_parent_tree, r_root_hop, depth,numOfVertices);
		}

		vector<NodeID> remaining;
		remaining.reserve(numOfVertices - taken);


		for (NodeID i = 0; i < numOfVertices; ++i) {
			if (usd[deg_inv[i]] == false)
				remaining.push_back(deg_inv[i]);
		}

		for (NodeID i = taken; i < numOfVertices; ++i) {
			chosen = remaining[i - taken];
			if (usd[chosen] == true) cout << "shit" << endl;
			inv[i] = chosen;
			rank[chosen] = i;
			labeling_source_bfs_directed(chosen, parent_tree, r_parent_tree, coverage, r_coverage, descendants, r_descendants, root_hop, r_root_hop, que, vis, dst_r, r_dst_r, usd, i, tmp_idx, r_tmp_idx, graph);
			clear_tmp(descendants, coverage, parent_tree, root_hop, depth, numOfVertices);
			clear_tmp(r_descendants, r_coverage, r_parent_tree, r_root_hop, depth,numOfVertices);
		}

		/*
		dlabels.index_.resize(numOfVertices);
		dlabels.bindex_.resize(numOfVertices);

		double amount = 0;
		for (NodeID v = 0; v < numOfVertices; ++v) {
			NodeID k = tmp_idx[v].first.size();

			amount += k;

			dlabels.index_[v].spt_v.resize(k);
			dlabels.index_[v].spt_d.resize(k);
			for (NodeID i = 0; i < k; ++i) dlabels.index_[v].spt_v[i] = tmp_idx[v].first[i];
			for (NodeID i = 0; i < k; ++i) dlabels.index_[v].spt_d[i] = tmp_idx[v].second[i];
			tmp_idx[v].first.clear();
			tmp_idx[v].second.clear();

			tmp_idx[v].first.shrink_to_fit();
			tmp_idx[v].second.shrink_to_fit();

			k = r_tmp_idx[v].first.size();

			amount += k;

			dlabels.bindex_[v].spt_v.resize(k);
			dlabels.bindex_[v].spt_d.resize(k);
			for (NodeID i = 0; i < k; ++i) dlabels.bindex_[v].spt_v[i] = r_tmp_idx[v].first[i];
			for (NodeID i = 0; i < k; ++i) dlabels.bindex_[v].spt_d[i] = r_tmp_idx[v].second[i];
			r_tmp_idx[v].first.clear();
			r_tmp_idx[v].second.clear();

			r_tmp_idx[v].first.shrink_to_fit();
			r_tmp_idx[v].second.shrink_to_fit();
		}
		amount = (double)(amount) / 2;
		cout << "avg_label_size: " << (double)(amount) / (double)numOfVertices - 1 << endl;*/
	}

	bool construct_label_index_minimal_index_advanced_node_order(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num, vector<double>& node_in_label, vector<double>& node_out_label, vector<vector<label_edge>>* vec_adjacency_list, vector<vector<label_edge>>* vec_adjacency_list_reverse, int label_num, Graph_order& graph)
	{
		//DIRECTED_FLAG = true;
		//WEIGHTED_FLAG = false;
		//for (NODE_TYPE i = 0; i < node_num; i++)
		//{
		//	NODE_TYPE temp_in_size = node_in_label[i] + 1;
		//	NODE_TYPE temp_out_size = node_out_label[i] + 1;
		//	double temp_degree = adjacency_list[i].size() + adjacency_list_reverse[i].size();
		//	//double temp_degree;
		//	//if (temp_in_size == 0 || temp_out_size == 0)
		//	//{
		//	//	temp_degree = 0;
		//	//}
		//	//else {
		//	//temp_degree = two_out_degrees[i] + two_in_degrees[i];
		//	//temp_degree = (adjacency_list[i].size() * adjacency_list_reverse[i].size())/(adjacency_list[i].size() + adjacency_list_reverse[i].size()+1) *double(pow(2,temp_in_size) *pow(2, temp_out_size));
		//	//}

		//	hot_degree hd1(i, temp_in_size*temp_out_size * 10000 + temp_degree);
		//	hot_points.push_back(hd1);
		//}
		vector<NodeID> ranks;
		//Coverage_Ordering coverage_ordering(wgraph, DIRECTED_FLAG, true);
		directed_unweighted_sigpath(graph, ranks);
		cout << "end of 2-hop degree" << endl;
		auto index_start = chrono::high_resolution_clock::now();
		//ofstream temp("ranks.txt");
		//for (int i = 0; i < graph.numOfVertices; i++)
		//{
		//	temp << ranks[i] << "\t" << adjacency_list[ranks[i]].size() + adjacency_list_reverse[ranks[i]].size() << endl;
		//}
		//temp.close();
		//sort by node degree
		vector<hot_degree> hot_points;
		
		//stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
		node_ranks.resize(node_num);
		
		NODE_TYPE temp_rank = 0;
		for (auto node_explore = ranks.begin(); node_explore != ranks.end(); node_explore++)
		{
			node_ranks[*node_explore] = temp_rank++;
		}
		ppl_LCR_pair src(0);
		set<ppl_LCR_pair> cur_propagate;
		set<ppl_LCR_pair> cur_propagate_reverse;
		set<ppl_LCR_pair> cur_propagate_plusone;
		set<ppl_LCR_pair> cur_propagate_reverse_plusone;

		set<ppl_LCR_pair> temp_propagate;
		ppl_LCR_pair new_pair;
		ppl_LCR_pair new_pair_propagate;
		ppl_LCR_pair in_label;
		//ppl_label_index new_in_out;
		ppl_LCR_pair out_label;
		set<NODE_TYPE> already_indexed;
		bool ppl_start = true;
		uint32_t timeout = 6*3600 * 6;//6hours
		int part = 0;

		//for (NODE_TYPE w = 0; w < node_num; w++)
		//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
		for (auto node_explore = ranks.begin(); node_explore != ranks.end(); node_explore++)
		{

			auto index_process = chrono::high_resolution_clock::now();
			auto diff = chrono::duration_cast<chrono::milliseconds>(index_process - index_start);
			if (diff.count() / 1e3 >= timeout)
			{
				cout << "time out to construct index" << endl;
				exit(1);
			}
			//NODE_TYPE i = hot_points[w].node;//node_explore->node;
			//const int N = sizeof(hot_points) / sizeof(hot_degree);
			//auto index_max = distance(hot_points.begin(), min_element(hot_points.begin(), hot_points.begin() + node_num));
			//hot_points[index_max].degree = 0;
			//cout << index_max << endl;
			NODE_TYPE i = *node_explore;//->node;//hot_points[index_max].node;//node_explore->node;
			//cout << i << "\t" << adjacency_list[i].size() + adjacency_list_reverse[i].size() << " : ";

			src.node = i;
			src.labels = 0;
			//if (true)//i % 100000 == 0)
			//{
			//cout << i << endl;
			//}
			//BFS to construct the index
			cur_propagate.clear();
			cur_propagate_reverse.clear();
			cur_propagate_plusone.clear();
			cur_propagate_reverse_plusone.clear();

			//forward bfs
			cur_propagate.insert(src);
			set<NODE_TYPE> visited_index_nodes;
			while ((!cur_propagate.empty()) || (!cur_propagate_plusone.empty()))
			{
				while ((!cur_propagate.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate.begin(); iter1 != cur_propagate.end(); iter1++)
					{

						//cout << "forward "<<iter1->node << "\t" << iter1->labels << endl;
						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						cur_propagate_plusone.insert(new_pair);
						for (auto temp_label = temp_labels.begin(); temp_label != temp_labels.end(); temp_label++)
						{
							for (auto edge = vec_adjacency_list[iter1->node][*temp_label].begin(); edge != vec_adjacency_list[iter1->node][*temp_label].end(); edge++)
							{
								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									continue;
								}
								//LABEL_TYPE tempL = 1;
								//tempL << (iter1->labels-1);
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
									{
										continue;
									}
								}
								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								NODE_TYPE cur_node = edge->node;
								in_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_in_label(in_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_in = exist_index->second.in_labels.find(in_label.node);
									if (exist_in == exist_index->second.in_labels.end())
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate = temp_propagate;
				}
				//while ((!cur_propagate_plusone.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate_plusone.begin(); iter1 != cur_propagate_plusone.end(); iter1++)
					{
						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						//cur_propagate_plusone.insert(new_pair);
						for (LABEL_TYPE temp_label = 0; temp_label < label_num; temp_label++)
						{
							if (temp_labels.find(temp_label) != temp_labels.end())
							{
								continue;
							}
							//cout << temp_label << endl;

							for (auto edge = vec_adjacency_list[iter1->node][temp_label].begin(); edge != vec_adjacency_list[iter1->node][temp_label].end(); edge++)
							{
								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									continue;
								}
								//LABEL_TYPE tempL = 1;
								//tempL << (iter1->labels-1);
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
									{
										continue;
									}
								}
								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								NODE_TYPE cur_node = edge->node;
								in_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_in_label(in_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_in = exist_index->second.in_labels.find(in_label.node);
									if (exist_in == exist_index->second.in_labels.end())
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate = temp_propagate;
					cur_propagate_plusone.clear();
				}
			}
			//when to stop 
			//reverse bfs
			cur_propagate_reverse.insert(src);
			cur_propagate_reverse_plusone.clear();
			while ((!cur_propagate_reverse.empty()) || (!cur_propagate_reverse_plusone.empty()))
			{
				while ((!cur_propagate_reverse.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate_reverse.begin(); iter1 != cur_propagate_reverse.end(); iter1++)
					{
						//cout << "backward " << iter1->node << "\t" << iter1->labels << endl;

						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						cur_propagate_reverse_plusone.insert(new_pair);
						for (auto temp_label = temp_labels.begin(); temp_label != temp_labels.end(); temp_label++)
						{
							for (auto edge = vec_adjacency_list_reverse[iter1->node][*temp_label].begin(); edge != vec_adjacency_list_reverse[iter1->node][*temp_label].end(); edge++)
							{

								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									continue;
								}
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
									{
										continue;
									}
								}



								NODE_TYPE cur_node = edge->node;
								out_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_out_label(out_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_out = exist_index->second.out_labels.find(out_label.node);
									if (exist_out == exist_index->second.out_labels.end())
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate_reverse = temp_propagate;
				}

				//while ((!cur_propagate_reverse_plusone.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate_reverse_plusone.begin(); iter1 != cur_propagate_reverse_plusone.end(); iter1++)
					{
						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						//cur_propagate_reverse_plusone.insert(new_pair);
						for (auto temp_label = 0; temp_label < label_num; temp_label++)
						{
							if (temp_labels.find(temp_label) != temp_labels.end())
							{
								continue;
							}
							for (auto edge = vec_adjacency_list_reverse[iter1->node][temp_label].begin(); edge != vec_adjacency_list_reverse[iter1->node][temp_label].end(); edge++)
							{

								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									continue;
								}
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
									{
										continue;
									}
								}



								NODE_TYPE cur_node = edge->node;
								out_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_out_label(out_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_out = exist_index->second.out_labels.find(out_label.node);
									if (exist_out == exist_index->second.out_labels.end())
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate_reverse = temp_propagate;
					cur_propagate_reverse_plusone.clear();
				}

			}
			already_indexed.insert(i);
			ppl_start = true;
		}
		return true;
	}

	void update_descendants_count(vector<NODE_TYPE> &descendants_to_root,vector<NODE_TYPE> &descendants_count, vector<NodeID> &descendants)
	{
		if (descendants.size() > 1)
		{
			for (auto iter_temp_node = descendants.rend() - 1; iter_temp_node != descendants.rbegin(); iter_temp_node--)
			{
				//cout << *iter_temp_node << endl;
				if (descendants_to_root[*iter_temp_node] != *iter_temp_node)
				{
					descendants_count[descendants_to_root[*iter_temp_node]] += descendants_count[*iter_temp_node];
				}
				//if (descendants_count[*iter_temp_node] > depth_max[depth[*iter_temp_node]])
				//{
				//	depth_max[*iter_temp_node] = descendants_count[*iter_temp_node];
				//	depth_max_node[depth[*iter_temp_node]] = *iter_temp_node;
				//}
			}
		}
	}

	bool construct_label_index_minimal_index_significant_path_order(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num, vector<double>& node_in_label, vector<double>& node_out_label, vector<vector<label_edge>>* vec_adjacency_list, vector<vector<label_edge>>* vec_adjacency_list_reverse, int label_num, Graph_order& graph)
	{
		bool with_leaf = false;
		bool regard_same_label_same_level = true;
		//DIRECTED_FLAG = true;
		//WEIGHTED_FLAG = false;
		
		//ofstream temp("ranks.txt");
		//for (int i = 0; i < graph.numOfVertices; i++)
		//{
		//	temp << ranks[i] << "\t" << adjacency_list[ranks[i]].size() + adjacency_list_reverse[ranks[i]].size() << endl;
		//}
		//temp.close();
		//sort by node degree

		//stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
		cout << "end of 2-hop degree" << endl;
		auto index_start = chrono::high_resolution_clock::now();
		//sort by node degree
		vector<hot_degree> hot_points;
		for (NODE_TYPE i = 0; i < node_num; i++)
		{
			NODE_TYPE temp_in_size = node_in_label[i] + 1;
			NODE_TYPE temp_out_size = node_out_label[i] + 1;
			double temp_degree = 0;
			//for (int j = 0; j < label_num; j++)
			//{
			temp_degree += adjacency_list[i].size() * adjacency_list_reverse[i].size();
			//
			//double temp_degree;
			//if (temp_in_size == 0 || temp_out_size == 0)
			//{
			//	temp_degree = 0;
			//}
			//else {
			//temp_degree = two_out_degrees[i] + two_in_degrees[i];
			//temp_degree = (adjacency_list[i].size() * adjacency_list_reverse[i].size())/(adjacency_list[i].size() + adjacency_list_reverse[i].size()+1) *double(pow(2,temp_in_size) *pow(2, temp_out_size));
			//}
			hot_degree hd1(i, temp_degree);

			//hot_degree hd1(i, temp_in_size*temp_out_size * 10000 + temp_degree);
			hot_points.push_back(hd1);
		}
		stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
		NODE_TYPE temp_rank = 0;
		for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
		{
			node_ranks[node_explore->node] = temp_rank++;
		}
		
		ppl_LCR_pair src(0);
		set<ppl_LCR_pair> cur_propagate;
		set<ppl_LCR_pair> cur_propagate_reverse;
		set<ppl_LCR_pair> cur_propagate_plusone;
		set<ppl_LCR_pair> cur_propagate_reverse_plusone;

		set<ppl_LCR_pair> temp_propagate;
		ppl_LCR_pair new_pair;
		ppl_LCR_pair new_pair_propagate;
		ppl_LCR_pair in_label;
		//ppl_label_index new_in_out;
		ppl_LCR_pair out_label;
		set<NODE_TYPE> already_indexed;
		bool ppl_start = true;
		uint32_t timeout = 6*3600 * 6;//6hours
		int part = 0;

		//for (NODE_TYPE w = 0; w < node_num; w++)
		//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
		//vector<NODE_TYPE> descendants_to_root;
		vector<NODE_TYPE> descendants_count;
		//descendants_to_root.resize(node_num+1);
		descendants_count.resize(node_num + 1);

		//vector<NODE_TYPE> r_descendants_to_root;
		vector<NODE_TYPE> r_descendants_count;
		//r_descendants_to_root.resize(node_num + 1);
		r_descendants_count.resize(node_num + 1);

		bool first_expolre = true;
		int temp_max_size = 0;
		int temp_max_node = -1;
		//set<NODE_TYPE> adj_candidate;
		NODE_TYPE last_node = 0;
		//vector<NodeID> descendants;
		//vector<NodeID> r_descendants;
		//descendants.resize(node_num + 1);
		//r_descendants.resize(node_num + 1);
		//for (auto node_explore = ranks.begin(); node_explore != ranks.end(); node_explore++)
		vector<bool> leaf_flag(node_num + 1, false);
		vector<bool> r_leaf_flag(node_num + 1, false);

		//vector<NodeID> depth(node_num + 1, 0);
		//vector<NodeID> r_depth(node_num + 1, 0);

		//vector<NodeID> coverage(node_num + 1, 0);
		//vector<NodeID> r_coverage(node_num + 1, 0);
		//vector<bool> already_in_tree;
		//vector<bool> r_already_in_tree;
		unordered_set<NODE_TYPE> visited_index_nodes;
		//already_in_tree.resize(node_num + 1);
		//r_already_in_tree.resize(node_num + 1);
		unordered_set<NodeID> r_visited_nodes;
		auto hot_node_iter = hot_points.begin();
		//vector<NODE_TYPE> depth_max(node_num + 1, 0);
		//vector<NODE_TYPE> r_depth_max(node_num + 1, 0);
		//vector<NODE_TYPE> depth_max_node(node_num + 1, 0);
		//vector<NODE_TYPE> r_depth_max_node(node_num + 1, 0);
		for( NODE_TYPE count = 0; count < node_num; count++)
		{
			/*for (int i = 0; i <= node_num; i++)
			{
				leaf_flag[i] = false;
				r_leaf_flag[i] = false;
			}*/
			


			
			
			//leaf_flag.resize(node_num + 1);

			temp_max_size = 0;
			temp_max_node = -1;
			auto node_explore = hot_points.begin();
			//if(count % 1000 == 0)cout << "count : " << count << endl;
			if (count == 0)
			{
				temp_max_node = node_explore->node;
				hot_node_iter++;
				//hot_points.erase(hot_points.begin());
				for (NODE_TYPE m = 0; m < node_num; m++)
				{
					descendants_count[m] = 0;
					//descendants_to_root[m] = -1;
					r_descendants_count[m] = 0;
					//r_descendants_to_root[m] = -1;
				}
			}
			else if(count <= min(1250+ int(sqrt(node_num)),node_num)){
				//find the unindexed maximum node to be next one
				NODE_TYPE total_dec = 0;
				//update_descendants_count(descendants_to_root, descendants_count, descendants);
				//update_descendants_count(r_descendants_to_root, r_descendants_count, r_descendants);
				/*if (descendants.size() > 1)
				{
					for (auto iter_temp_node = descendants.rend() - 1; iter_temp_node != descendants.rbegin(); iter_temp_node--)
					{
						//cout << *iter_temp_node << endl;
						if (descendants_to_root[*iter_temp_node] != *iter_temp_node)
						{
							descendants_count[descendants_to_root[*iter_temp_node]] += descendants_count[*iter_temp_node];
						}
						//if (descendants_count[*iter_temp_node] > depth_max[depth[*iter_temp_node]])
						//{
						//	depth_max[*iter_temp_node] = descendants_count[*iter_temp_node];
						//	depth_max_node[depth[*iter_temp_node]] = *iter_temp_node;
						//}
					}
				}
				if (r_descendants.size() > 1)
				{
					for (auto iter_temp_node = r_descendants.rend() - 1; iter_temp_node != r_descendants.rbegin(); iter_temp_node--)
					{
						if (descendants_to_root[*iter_temp_node] != *iter_temp_node)
						{
							r_descendants_count[r_descendants_to_root[*iter_temp_node]] += r_descendants_count[*iter_temp_node];
						}
						//if (r_descendants_count[*iter_temp_node] > r_depth_max[depth[*iter_temp_node]])
						//{
						//	r_depth_max[*iter_temp_node] = r_descendants_count[*iter_temp_node];
						//	r_depth_max_node[depth[*iter_temp_node]] = *iter_temp_node;
						//}
					}
				}*/
				vector<NodeID> temp_sig_path;

				NODE_TYPE temp_node = last_node;
				temp_sig_path.push_back(temp_node);
				NodeID temp_max_forward;
				NodeID temp_max_forward_descent = 2;
				bool no_sig_path = true;
				int step = 0;
				int explore_node = 0;
				while ( (temp_max_forward_descent > 1) && (step <= MAX_STEP))//while current node is not leaf
				{
					step++;
					//NodeID temp_max_forward;
					temp_max_forward_descent = -1;
					for (auto iter_temp = adjacency_list[temp_node].begin(); iter_temp != adjacency_list[temp_node].end(); iter_temp++)
					{
						/*explore_node++;
						if (explore_node > 10)
						{
							break;
						}*/
						if (descendants_count[iter_temp->node] > temp_max_forward_descent)
						{
							temp_max_forward_descent = descendants_count[iter_temp->node];
							temp_max_forward = iter_temp->node;
						}
						//temp_sig_path.push_back();
					}
					if (temp_max_forward_descent != -1)
					{
						temp_node = temp_max_forward;
						temp_sig_path.push_back(temp_max_forward);
					}
					else {
						break;
					}
				}
				//if (temp_max_forward != -1)
				//{

				//}
				//find the node with max score in sig path
				NodeID temp_max_forward_node = -1;
				NodeID temp_max_forward_score = -1;
				//unordered_set<NodeID> temp_set(r_descendants);
				if (temp_sig_path.size() >= 1)
				{
					for (NodeID i = 0; i < temp_sig_path.size(); i++)
					{
						//if (r_visited_nodes.find(temp_sig_path[i]) == r_visited_nodes.end())
						//{
						//	continue;
						//}
						//NodeID temp_score = abs((hot_points[temp_sig_path[i]].degree- hot_points[temp_sig_path[i-1]].degree)* (descendants_count[temp_sig_path[i]] - descendants_count[temp_sig_path[i - 1]]));
						NodeID temp_score = abs((descendants_count[temp_sig_path[i]]));
						if (temp_score > temp_max_forward_score)
						{
							temp_max_forward_score = temp_score;
							temp_max_forward_node = temp_sig_path[i];
						}
					}

					//temp_max_node = temp_max_forward_node;

				}
				temp_node = last_node;
				temp_sig_path.clear();
				NodeID temp_max_backward;
				NodeID temp_max_backward_descent = 2;
				step = 0;
				explore_node = 0;
				while ((temp_max_backward_descent > 1) && (step <= MAX_STEP))//while current node is not leaf
				{
					step++;
					temp_max_backward_descent = -1;
					for (auto iter_temp = adjacency_list_reverse[temp_node].begin(); iter_temp != adjacency_list_reverse[temp_node].end(); iter_temp++)
					{
						/*explore_node++;
						if (explore_node > 10)
						{
							break;
						}*/
						if (r_descendants_count[iter_temp->node] > temp_max_backward_descent)
						{
							temp_max_backward_descent = descendants_count[iter_temp->node];
							temp_max_backward = iter_temp->node;
						}
						//temp_sig_path.push_back();
					}
					if (temp_max_backward_descent != -1)
					{
						temp_node = temp_max_backward;
						temp_sig_path.push_back(temp_max_backward);
					}
					else {
						break;
					}
				}
				//if (temp_max_backward_descent != 2)
				//{

				//}
				//find the node with max score in sig path
				NodeID temp_max_backward_node = -1;
				NodeID temp_max_backward_score = -1;
				if (temp_sig_path.size() >= 1)
				{
					for (NodeID i = 0; i < temp_sig_path.size(); i++)
					{
						//NodeID temp_score = abs((hot_points[temp_sig_path[i]].degree - hot_points[temp_sig_path[i-1]].degree)* (r_descendants_count[temp_sig_path[i]] - r_descendants_count[temp_sig_path[i - 1]]));
						NodeID temp_score = abs((r_descendants_count[temp_sig_path[i]]));
						if (temp_score > temp_max_backward_score)
						{
							temp_max_backward_score = temp_score;
							temp_max_backward_node = temp_sig_path[i];
						}
					}
				}
				temp_max_node = temp_max_forward_node;
				//cout << temp_max_node << endl;
				if (temp_max_forward_score > temp_max_backward_score)
				{
					temp_max_node = temp_max_forward_node;
					//descendants_count[temp_max_forward_node] = 0;
				}
				else 
				{
					temp_max_node = temp_max_backward_node;
					//r_descendants_count[temp_max_backward_node] = 0;
				}
				//temp_max_node = -1;
				//cout << temp_max_node << endl;



				//caclulate the node with max score
				//for()


				/*for (auto iter_node = adj_candidate.begin(); iter_node != adj_candidate.end(); iter_node++)
				{
					total_dec += descendants_count[*iter_node];
				}
				for (auto iter_node = adj_candidate.begin(); iter_node != adj_candidate.end(); iter_node++)
				{
					if (descendants_count[*iter_node] == 0)
					{
						continue;
					}
					if (already_indexed.find(*iter_node) != already_indexed.end())//already indexed, then continue
					{
						continue;
					}
					NODE_TYPE temp_score = (total_dec - descendants_count[*iter_node])*hot_points[*iter_node].degree;
					if (temp_score > temp_max_size)
					{
						temp_max_size = temp_score;
						temp_max_node = *iter_node;
					}*/
					//descendants_count[*iter_node] = 0;

				if (temp_max_node == -1)//not find any unindexed maximum node
				{
					//cout << count << endl;
					while (hot_node_iter != hot_points.end())
					{
						if (already_indexed.find(hot_node_iter->node) != already_indexed.end())//already indexed, then continue
						{
							hot_node_iter++;
						}
						temp_max_node = hot_node_iter->node;
						hot_node_iter++;
						break;
					}
					/*for (auto temp_iter = hot_points.begin(); temp_iter != hot_points.end();)
					{
						if (already_indexed.find(temp_iter->node) != already_indexed.end())//already indexed, then continue
						{
							temp_iter = hot_points.erase(hot_points.begin());
							continue;
						}
						//temp_iter++;
						temp_max_node = temp_iter->node;
						break;//current no indexed node as next
					}*/
				}
			}
			else {
				//cout << count << endl;
				while (hot_node_iter != hot_points.end())
				{
					if (already_indexed.find(hot_node_iter->node) != already_indexed.end())//already indexed, then continue
					{
						hot_node_iter++;
					}
					temp_max_node = hot_node_iter->node;
					hot_node_iter++;
					break;
				}
			}
			auto index_process = chrono::high_resolution_clock::now();
			auto diff = chrono::duration_cast<chrono::milliseconds>(index_process - index_start);
			if (diff.count() / 1e3 >= timeout)
			{
				cout << "time out to construct index" << endl;
				exit(1);
			}
			//initialize the counting arrary
			//descendants.clear();
			//r_descendants.clear();
			//adj_candidate.clear();
			//descendants_to_root[temp_max_node] = temp_max_node;
			//r_descendants_to_root[temp_max_node] = temp_max_node;

			/*for (auto iter_next = adjacency_list[temp_max_node].begin(); iter_next != adjacency_list[temp_max_node].end(); iter_next++)
			{
				//adj_candidate.insert(iter_next->node);
				descendants_to_root[iter_next->node] = iter_next->node;
			}
			for (auto iter_next = adjacency_list_reverse[temp_max_node].begin(); iter_next != adjacency_list_reverse[temp_max_node].end(); iter_next++)
			{
				//adj_candidate.insert(iter_next->node);
				r_descendants_to_root[iter_next->node] = iter_next->node;
			}*/

			/*for (NODE_TYPE m = 0; m < node_num; m++)
			{
				descendants_count[m] = 0;
				r_descendants_count[m] = 0;
				descendants_to_root[m] = -1;
				r_descendants_to_root[m] = -1;

			}*/
			
			//end of initialize the counting and root array

			//NODE_TYPE i = hot_points[w].node;//node_explore->node;
			//const int N = sizeof(hot_points) / sizeof(hot_degree);
			//auto index_max = distance(hot_points.begin(), min_element(hot_points.begin(), hot_points.begin() + node_num));
			//hot_points[index_max].degree = 0;
			//cout << index_max << endl;
			NODE_TYPE i = temp_max_node;//->node;//hot_points[index_max].node;//node_explore->node;
										//cout << i << "\t" << adjacency_list[i].size() + adjacency_list_reverse[i].size() << " : ";
			//descendants_to_root[i] = i;
			//r_descendants_to_root[i] = i;
			//depth_max[0] = i;
			last_node = i;
			//if (temp_max_node != -1)
			//{
			//	i = temp_max_node;
			//}
			src.node = i;
			src.labels = 0;
			if (true)//i % 100000 == 0)
			{
			//cout << i << endl;
			}
			//BFS to construct the index
			cur_propagate.clear();
			cur_propagate_reverse.clear();
			cur_propagate_plusone.clear();
			cur_propagate_reverse_plusone.clear();

			//forward bfs
			cur_propagate.insert(src);
			visited_index_nodes.clear();
			int temp_step = 0;
			while ((!cur_propagate.empty()) || (!cur_propagate_plusone.empty()))
			{
				temp_step++;
				while ((!cur_propagate.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate.begin(); iter1 != cur_propagate.end(); iter1++)
					{
						//cout << "forward "<<iter1->node << "\t" << iter1->labels << endl;
						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						cur_propagate_plusone.insert(new_pair);
						for (auto temp_label = temp_labels.begin(); temp_label != temp_labels.end(); temp_label++)
						{
							for (auto edge = vec_adjacency_list[iter1->node][*temp_label].begin(); edge != vec_adjacency_list[iter1->node][*temp_label].end(); edge++)
							{
								if (temp_step <= MAX_STEP)
								{
									if (with_leaf &&regard_same_label_same_level)
									{
										// if (descendants_to_root[edge->node] == -1)
										{
											//descendants_to_root[edge->node] = descendants_to_root[iter1->node];
										}

										//depth[edge->node] = depth[iter1->node] + 1;
										if (visited_index_nodes.find(edge->node) == visited_index_nodes.end())
										{
											descendants_count[edge->node] += 1;
										//	descendants.push_back(edge->node);
											visited_index_nodes.insert(edge->node);
										}
										else {
											descendants_count[edge->node] += 1;
										}
									}
									else if (with_leaf && (!regard_same_label_same_level))
									{
										// if (descendants_to_root[edge->node] == -1)
										{
											//descendants_to_root[edge->node] = iter1->node;//descendants_to_root[iter1->node];
										}
										//depth[edge->node] = depth[iter1->node] + 1;
										if (visited_index_nodes.find(edge->node) == visited_index_nodes.end())
										{
											descendants_count[edge->node] += 1;
											//descendants.push_back(edge->node);
											visited_index_nodes.insert(edge->node);
										}
										else {
											descendants_count[edge->node] += 1;
										}
									}
								}
								//descendants_count[descendants_to_root[edge->node]] += 1;
								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									leaf_flag[edge->node] = true;
									continue;
								}
								//LABEL_TYPE tempL = 1;
								//tempL << (iter1->labels-1);
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
									{
										//leaf_flag[edge->node] = true;
										continue;
									}
								}
								if (temp_step <= MAX_STEP)
								{
									if ((!with_leaf) && (regard_same_label_same_level))
									{
										// if (descendants_to_root[edge->node] == -1)
										{
											//descendants_to_root[edge->node] = descendants_to_root[iter1->node];
										}
										//depth[edge->node] = depth[iter1->node] + 1;
										if (visited_index_nodes.find(edge->node) == visited_index_nodes.end())
										{
											descendants_count[edge->node] += 1;
											//descendants.push_back(edge->node);
											visited_index_nodes.insert(edge->node);
										}
										else {
											descendants_count[edge->node] += 1;
										}
									}
									else if ((!with_leaf) && (!regard_same_label_same_level))
									{
										// if (descendants_to_root[edge->node] == -1)
										{
											//descendants_to_root[edge->node] = iter1->node;//descendants_to_root[iter1->node];
										}
										//descendants_count[edge->node] += 1;
										//depth[edge->node] = depth[iter1->node] + 1;
										if (visited_index_nodes.find(edge->node) == visited_index_nodes.end())
										{
											descendants_count[edge->node] += 1;

											//descendants.push_back(edge->node);
											visited_index_nodes.insert(edge->node);
										}
										else {
											descendants_count[edge->node] += 1;
										}

									}
								}
								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								NODE_TYPE cur_node = edge->node;
								in_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_in_label(in_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_in = exist_index->second.in_labels.find(in_label.node);
									if (exist_in == exist_index->second.in_labels.end())
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate = temp_propagate;
				}
				//while ((!cur_propagate_plusone.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate_plusone.begin(); iter1 != cur_propagate_plusone.end(); iter1++)
					{
						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						//cur_propagate_plusone.insert(new_pair);
						for (LABEL_TYPE temp_label = 0; temp_label < label_num; temp_label++)
						{
							if (temp_labels.find(temp_label) != temp_labels.end())
							{
								continue;
							}
							//cout << temp_label << endl;

							for (auto edge = vec_adjacency_list[iter1->node][temp_label].begin(); edge != vec_adjacency_list[iter1->node][temp_label].end(); edge++)
							{
								if (temp_step <= MAX_STEP)
								{
									if (with_leaf)
									{
										// if (descendants_to_root[edge->node] == -1)
										{
											//descendants_to_root[edge->node] = iter1->node;//descendants_to_root[iter1->node];
										}

										//depth[edge->node] = depth[iter1->node] + 1;
										if (visited_index_nodes.find(edge->node) == visited_index_nodes.end())
										{
											descendants_count[edge->node] += 1;
											//descendants.push_back(edge->node);
											visited_index_nodes.insert(edge->node);
										}
										else {
											descendants_count[edge->node] += 1;
										}
									}
								}
								//descendants_count[descendants_to_root[edge->node]] += 1;
								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									//leaf_flag[edge->node] = true;
									continue;
								}
								//LABEL_TYPE tempL = 1;
								//tempL << (iter1->labels-1);
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
									{
										//leaf_flag[edge->node] = true;

										continue;
									}
								}
								if (temp_step <= MAX_STEP)
								{
									if (!with_leaf)
									{
										// if (descendants_to_root[edge->node] == -1)
										{
											//descendants_to_root[edge->node] = iter1->node;//descendants_to_root[iter1->node];
										}
										//depth[edge->node] = depth[iter1->node] + 1;
										if (visited_index_nodes.find(edge->node) == visited_index_nodes.end())
										{
											descendants_count[edge->node] += 1;
											//descendants.push_back(edge->node);
											visited_index_nodes.insert(edge->node);
										}
										else {
											descendants_count[edge->node] += 1;
										}
									}
								}
								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								NODE_TYPE cur_node = edge->node;
								in_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_in_label(in_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_in = exist_index->second.in_labels.find(in_label.node);
									if (exist_in == exist_index->second.in_labels.end())
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_in_label(in_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate = temp_propagate;
					cur_propagate_plusone.clear();
				}
			}
			//when to stop 
			//reverse bfs
			//visited_index_nodes.clear();
			r_visited_nodes.clear();
			cur_propagate_reverse.insert(src);
			cur_propagate_reverse_plusone.clear();
			temp_step = 0;
			while ((!cur_propagate_reverse.empty()) || (!cur_propagate_reverse_plusone.empty()))
			{
				temp_step++;
				while ((!cur_propagate_reverse.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate_reverse.begin(); iter1 != cur_propagate_reverse.end(); iter1++)
					{
						//cout << "backward " << iter1->node << "\t" << iter1->labels << endl;

						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						cur_propagate_reverse_plusone.insert(new_pair);
						for (auto temp_label = temp_labels.begin(); temp_label != temp_labels.end(); temp_label++)
						{
							for (auto edge = vec_adjacency_list_reverse[iter1->node][*temp_label].begin(); edge != vec_adjacency_list_reverse[iter1->node][*temp_label].end(); edge++)
							{
								if (temp_step <= MAX_STEP)
								{
									if (with_leaf &&regard_same_label_same_level)
									{
										//if (r_descendants_to_root[edge->node] == -1)
										{
											//r_descendants_to_root[edge->node] = r_descendants_to_root[iter1->node];
										}
										//r_depth[edge->node] = r_depth[iter1->node] + 1;
										if (r_visited_nodes.find(edge->node) == r_visited_nodes.end())
										{
											r_descendants_count[edge->node] += 1;
											//r_descendants.push_back(edge->node);
											r_visited_nodes.insert(edge->node);
										}
										else {
											r_descendants_count[edge->node] += 1;
										}
									}
									else if (with_leaf && (!regard_same_label_same_level))
									{
										//if (r_descendants_to_root[edge->node] == -1)
										{
										//	r_descendants_to_root[edge->node] = iter1->node;//r_descendants_to_root[iter1->node];
										}

										//r_depth[edge->node] = r_depth[iter1->node] + 1;
										if (r_visited_nodes.find(edge->node) == r_visited_nodes.end())
										{
											r_descendants_count[edge->node] += 1;
											//r_descendants.push_back(edge->node);
											r_visited_nodes.insert(edge->node);
										}
										else {
											r_descendants_count[edge->node] += 1;

										}
									}
								}
								//r_descendants_count[r_descendants_to_root[edge->node]] += 1;

								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									//r_leaf_flag[edge->node] = true;

									continue;
								}
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
									{
										//r_leaf_flag[edge->node] = true;

										continue;
									}
								}
								if (temp_step <= MAX_STEP)
								{
									if ((!with_leaf) && (regard_same_label_same_level))
									{
										//if (r_descendants_to_root[edge->node] == -1)
										{
										//	r_descendants_to_root[edge->node] = r_descendants_to_root[iter1->node];
										}

										//r_depth[edge->node] = r_depth[iter1->node] + 1;
										if (r_visited_nodes.find(edge->node) == r_visited_nodes.end())
										{
											r_descendants_count[edge->node] += 1;
											//r_descendants.push_back(edge->node);
											r_visited_nodes.insert(edge->node);
										}
										else {
											r_descendants_count[edge->node] += 1;
										}
									}
									else if ((!with_leaf) && (!regard_same_label_same_level))
									{
										//if (r_descendants_to_root[edge->node] == -1)
										{
											//r_descendants_to_root[edge->node] = iter1->node;//descendants_to_root[iter1->node];
										}
										//r_depth[edge->node] = r_depth[iter1->node] + 1;
										if (r_visited_nodes.find(edge->node) == r_visited_nodes.end())
										{
											r_descendants_count[edge->node] += 1;
											//r_descendants.push_back(edge->node);
											r_visited_nodes.insert(edge->node);
										}
										else {
											r_descendants_count[edge->node] += 1;
										}
									}
								}
								NODE_TYPE cur_node = edge->node;
								out_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_out_label(out_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_out = exist_index->second.out_labels.find(out_label.node);
									if (exist_out == exist_index->second.out_labels.end())
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate_reverse = temp_propagate;
				}

				//while ((!cur_propagate_reverse_plusone.empty()))
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate_reverse_plusone.begin(); iter1 != cur_propagate_reverse_plusone.end(); iter1++)
					{
						set<LABEL_TYPE> temp_labels = convert_to_label_set(iter1->labels);
						new_pair.set_values(iter1->node, (iter1->labels));
						//cur_propagate_reverse_plusone.insert(new_pair);
						for (auto temp_label = 0; temp_label < label_num; temp_label++)
						{
							if (temp_labels.find(temp_label) != temp_labels.end())
							{
								continue;
							}
							for (auto edge = vec_adjacency_list_reverse[iter1->node][temp_label].begin(); edge != vec_adjacency_list_reverse[iter1->node][temp_label].end(); edge++)
							{
								if (temp_step <= MAX_STEP)
								{
									if (with_leaf)
									{
										//if (r_descendants_to_root[edge->node] == -1)
										{
										//	r_descendants_to_root[edge->node] = iter1->node;//descendants_to_root[iter1->node];
										}

										//r_depth[edge->node] = r_depth[iter1->node] + 1;
										if (r_visited_nodes.find(edge->node) == r_visited_nodes.end())
										{
											r_descendants_count[edge->node] += 1;
											//r_descendants.push_back(edge->node);
											r_visited_nodes.insert(edge->node);
										}
										else {
											r_descendants_count[edge->node] += 1;
										}

									}
								}
								//descendants_count[descendants_to_root[edge->node]] += 1;
								if (already_indexed.find(edge->node) != already_indexed.end())
								{
									//r_leaf_flag[edge->node] = true;
									continue;
								}
								new_pair.set_values(edge->node, (iter1->labels));
								new_pair_propagate.set_values(edge->node, (iter1->labels));

								new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

								new_pair.add_labels(convert_to_binary_label(edge->label));
								if (ppl_start)
								{
									if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
									{
										//r_leaf_flag[edge->node] = true;
										continue;
									}
								}
								if (temp_step <= MAX_STEP)
								{
									if (!with_leaf)
									{
										//if (r_descendants_to_root[edge->node] == -1)
										{
											//r_descendants_to_root[edge->node] = iter1->node;//descendants_to_root[iter1->node];
										}
										//r_depth[edge->node] = r_depth[iter1->node] + 1;
										if (r_visited_nodes.find(edge->node) == r_visited_nodes.end())
										{
											r_descendants_count[edge->node] += 1;
											//r_descendants.push_back(edge->node);
											r_visited_nodes.insert(edge->node);
										}
										else {
											r_descendants_count[edge->node] += 1;
										}
									}
								}
								NODE_TYPE cur_node = edge->node;
								out_label.set_values(i, new_pair.labels);// store the start node
								auto exist_index = index.find(cur_node);
								if (exist_index == index.end())//first time to insert index for node cur_node
								{
									ppl_LCR_index new_in_out;
									new_in_out.insert_out_label(out_label);
									index.insert(std::make_pair(cur_node, new_in_out));
									temp_propagate.insert(new_pair_propagate);
								}
								else
								{
									auto exist_out = exist_index->second.out_labels.find(out_label.node);
									if (exist_out == exist_index->second.out_labels.end())
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
										continue;
									}
									if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
									{
										exist_index->second.insert_out_label(out_label);
										temp_propagate.insert(new_pair_propagate);
									}
								}
							}
						}
					}
					cur_propagate_reverse = temp_propagate;
					cur_propagate_reverse_plusone.clear();
				}

			}
			already_indexed.insert(i);
			ppl_start = true;
		}
		return true;
	}



	bool construct_naive_2hop_labeling_one_label(NODE_TYPE node_num, vector<double>& node_in_label, vector<double>& node_out_label, vector<vector<label_edge>>* vec_adjacency_list, vector<vector<label_edge>>* vec_adjacency_list_reverse, int label_num)
	{
		auto index_start = chrono::high_resolution_clock::now();
		//sort by node degree
		for (int label = 0; label < label_num; label++)
		{
			vector<hot_degree> hot_points;
			for (NODE_TYPE i = 0; i < node_num; i++)
			{
				NODE_TYPE temp_degree = vec_adjacency_list[i][label].size() + vec_adjacency_list_reverse[i][label].size();
				//if (temp_degree != 0)
				//{
				hot_degree hd1(i, temp_degree);
				hot_points.push_back(hd1);
				//}
			}
			stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());
			node_ranks.resize(node_num);
			NODE_TYPE temp_rank = 0;
			for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
			{
				node_ranks[node_explore->node] = temp_rank++;
			}
			ppl_LCR_pair_no_order src(0);
			set<ppl_LCR_pair_no_order> cur_propagate;
			set<ppl_LCR_pair_no_order> cur_propagate_reverse;
			set<ppl_LCR_pair_no_order> temp_propagate;
			ppl_LCR_pair_no_order new_pair;
			ppl_LCR_pair_no_order new_pair_propagate;
			ppl_LCR_pair in_label;
			//ppl_label_index new_in_out;
			ppl_LCR_pair out_label;
			set<NODE_TYPE> already_indexed;
			bool ppl_start = true;
			uint32_t timeout = 6 * 3600 * 6;//6hours
			int part = 0;

			//for (NODE_TYPE i = 1; i <= node_num; i++)
			//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
			for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
			{
				part++;
				if (part > 10)
				{
					//break;
				}

				auto index_process = chrono::high_resolution_clock::now();
				auto diff = chrono::duration_cast<chrono::milliseconds>(index_process - index_start);
				if (diff.count() / 1e3 >= timeout)
				{
					cout << "time out to construct index" << endl;
					exit(1);
				}
				NODE_TYPE i = node_explore->node;

				src.node = i;
				src.labels = 0;
				//if (true)//i % 1000 == 0)
				//{
				//cout << i << endl;
				//}
				//BFS to construct the index
				cur_propagate.clear();
				cur_propagate_reverse.clear();


				//forward bfs
				cur_propagate.insert(src);
				set<NODE_TYPE> visited_index_nodes;
				while (!cur_propagate.empty())
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate.begin(); iter1 != cur_propagate.end(); iter1++)
					{
						//cout << iter1->node << "\t" << cur_propagate.size() << "\t" << BitCount5(iter1->labels) << endl;
						for (auto edge = vec_adjacency_list[iter1->node][label].begin(); edge != vec_adjacency_list[iter1->node][label].end(); edge++)
						{
							if (edge->node == 73)
							{
								//cout << 73 << endl;
							}
							if (already_indexed.find(edge->node) != already_indexed.end())
							{
								continue;
							}
							//LABEL_TYPE tempL = 1;
							//tempL << (iter1->labels-1);
							new_pair.set_values(edge->node, (iter1->labels));
							new_pair_propagate.set_values(edge->node, (iter1->labels));

							new_pair.add_labels(convert_to_binary_label(edge->label));
							if (ppl_start)
							{
								if (find_distance_ppl(i, edge->node, new_pair.labels) == 1)
								{
									continue;
								}
							}
							new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

							NODE_TYPE cur_node = edge->node;
							in_label.set_values(i, new_pair.labels);// store the start node
							auto exist_index = index.find(cur_node);
							if (exist_index == index.end())//first time to insert index for node cur_node
							{
								ppl_LCR_index new_in_out;
								new_in_out.insert_in_label(in_label);
								index.insert(std::make_pair(cur_node, new_in_out));
								temp_propagate.insert(new_pair_propagate);
							}
							else
							{
								auto exist_in = exist_index->second.in_labels.find(in_label.node);
								if (exist_in == exist_index->second.in_labels.end())
								{
									exist_index->second.insert_in_label(in_label);
									temp_propagate.insert(new_pair_propagate);
									//continue;
								}
								else if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
								{
									exist_index->second.insert_in_label(in_label);
									temp_propagate.insert(new_pair_propagate);
								}
							}


							//NODE_TYPE cur_node = edge->node;
							out_label.set_values(cur_node, new_pair.labels);// store the start node
							exist_index = index.find(i);
							if (exist_index == index.end())//first time to insert index for node cur_node
							{
								ppl_LCR_index new_in_out;
								new_in_out.insert_out_label(out_label);
								index.insert(std::make_pair(i, new_in_out));
								//temp_propagate.insert(new_pair_propagate);
							}
							else
							{
								auto exist_out = exist_index->second.out_labels.find(out_label.node);
								if (exist_out == exist_index->second.out_labels.end())
								{
									exist_index->second.insert_out_label(out_label);
									//temp_propagate.insert(new_pair_propagate);
									//continue;
								}
								else if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
								{
									exist_index->second.insert_out_label(out_label);
									//temp_propagate.insert(new_pair_propagate);
								}
							}

						}
					}
					cur_propagate = temp_propagate;
				}
				//when to stop 
				//reverse bfs
				cur_propagate_reverse.insert(src);
				while (!cur_propagate_reverse.empty())
				{
					temp_propagate.clear();
					for (auto iter1 = cur_propagate_reverse.begin(); iter1 != cur_propagate_reverse.end(); iter1++)
					{
						for (auto edge = vec_adjacency_list_reverse[iter1->node][label].begin(); edge != vec_adjacency_list_reverse[iter1->node][label].end(); edge++)
						{

							if (already_indexed.find(edge->node) != already_indexed.end())
							{
								continue;
							}
							new_pair.set_values(edge->node, (iter1->labels));
							new_pair_propagate.set_values(edge->node, (iter1->labels));

							new_pair_propagate.add_labels(convert_to_binary_label(edge->label));

							new_pair.add_labels(convert_to_binary_label(edge->label));
							if (ppl_start)
							{
								if (find_distance_ppl(edge->node, i, new_pair.labels) == 1)
								{
									continue;
								}
							}



							NODE_TYPE cur_node = edge->node;
							out_label.set_values(i, new_pair.labels);// store the start node
							auto exist_index = index.find(cur_node);
							if (exist_index == index.end())//first time to insert index for node cur_node
							{
								ppl_LCR_index new_in_out;
								new_in_out.insert_out_label(out_label);
								index.insert(std::make_pair(cur_node, new_in_out));
								temp_propagate.insert(new_pair_propagate);
							}
							else
							{
								auto exist_out = exist_index->second.out_labels.find(out_label.node);
								if (exist_out == exist_index->second.out_labels.end())
								{
									exist_index->second.insert_out_label(out_label);
									temp_propagate.insert(new_pair_propagate);
									//continue;
								}
								else if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
								{
									exist_index->second.insert_out_label(out_label);
									temp_propagate.insert(new_pair_propagate);
								}
							}


							//NODE_TYPE cur_node = edge->node;
							in_label.set_values(cur_node, new_pair.labels);// store the start node
							exist_index = index.find(i);
							if (exist_index == index.end())//first time to insert index for node cur_node
							{
								ppl_LCR_index new_in_out;
								new_in_out.insert_in_label(in_label);
								index.insert(std::make_pair(i, new_in_out));
								//temp_propagate.insert(new_pair_propagate);
							}
							else
							{
								auto exist_in = exist_index->second.in_labels.find(in_label.node);
								if (exist_in == exist_index->second.in_labels.end())
								{
									exist_index->second.insert_in_label(in_label);
									//temp_propagate.insert(new_pair_propagate);
									//continue;
								}
								else if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
								{
									exist_index->second.insert_in_label(in_label);
									//temp_propagate.insert(new_pair_propagate);
								}
							}
						}
					}
					cur_propagate_reverse = temp_propagate;
				}
				already_indexed.insert(i);
				ppl_start = true;
			}
		}
		return true;
	}



	/*uint32_t find_mindis_with_labels_constraint(set<ppl_LCR_pair>& pairs, set<LABEL_TYPE>& labels)
	{
		//int result = INF;
		for (auto pair : pairs)
		{
			if (A_is_subset_of_B(pair.labels, labels))
			{
				return 1;//the set ppl_pair is sorted by dis firstly
			}
		}
		return INF;
	}*/

	bool construct_Iin_Iout()
	{
		//test construct I in and out
		//travesal all the index
		for (auto iter = index.begin(); iter != index.end(); iter++)
		{
			for (auto node_inlabel = iter->second.in_labels.begin(); node_inlabel != iter->second.in_labels.end(); node_inlabel++)
			{
				for (auto label = node_inlabel->second.begin(); label != node_inlabel->second.end(); label++)
				{
					auto exist_I_in = I_in.find(node_inlabel->first);
					if (exist_I_in == I_in.end())
					{
						ppl_LCR_pair temp;
						set<ppl_LCR_pair> temp_set;
						temp.node = iter->first;
						temp.labels = label->labels;
						temp_set.insert(temp);
						I_in.insert(std::make_pair(node_inlabel->first, temp_set));
					}
					else {
						ppl_LCR_pair temp;
						temp.node = iter->first;
						temp.labels = label->labels;
						exist_I_in->second.insert(temp);
					}
				}
			}
			for (auto node_outlabel = iter->second.out_labels.begin(); node_outlabel != iter->second.out_labels.end(); node_outlabel++)
			{
				for (auto label = node_outlabel->second.begin(); label != node_outlabel->second.end(); label++)
				{
					auto exist_I_out = I_out.find(node_outlabel->first);
					if (exist_I_out == I_out.end())
					{
						ppl_LCR_pair temp;
						set<ppl_LCR_pair> temp_set;
						temp.node = iter->first;
						temp.labels = label->labels;
						temp_set.insert(temp);
						I_out.insert(std::make_pair(node_outlabel->first, temp_set));
					}
					else {
						ppl_LCR_pair temp;
						temp.node = iter->first;
						temp.labels = label->labels;
						exist_I_out->second.insert(temp);
					}
				}
			}
		}
		return true;
	}

	bool add_edges_update_index(NODE_TYPE src, NODE_TYPE dst, LABEL_TYPE label, vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num)
	{
		for (auto iter = adjacency_list[src].begin(); iter != adjacency_list[src].end(); iter++)
		{
			if (iter->node == dst && iter->label == label)
			{
				cout << src << "\t" << dst << "\t" << label << "\t is alreadly in adjacency list" << endl;
				return false;
			}

		}
		label_edge tempout,tempin;
		tempout.label = label;
		tempout.node = dst;
		tempout.weight = 1;
		tempin.label = label;
		tempin.node = src;
		tempin.weight = 1;
		adjacency_list[src].push_back(tempout);
		adjacency_list_reverse[dst].push_back(tempin);

		LABEL_TYPE binary_label = convert_to_binary_label(label);
		set<ppl_LCR_pair_by_node_rank> C_in;
		set<ppl_LCR_pair_by_node_rank> C_out;
		ppl_LCR_pair_by_node_rank temp_in;
		ppl_LCR_pair_by_node_rank temp_out;
		temp_in.set_values(src, binary_label);
		C_in.insert(temp_in);
		temp_out.set_values(dst, binary_label);
		C_out.insert(temp_out);
		auto exist_in = index.find(src);
		auto exist_out = index.find(dst);
		auto I_src = I_out.find(src);
		auto I_dst = I_in.find(dst);
		NODE_TYPE pre_node = INF;
		if (exist_in != index.end())
		{
			for (auto iter = exist_in->second.in_labels.begin(); iter != exist_in->second.in_labels.end(); iter++)
			{
				for (auto label = iter->second.begin(); label != iter->second.end(); label++)
				{
					temp_in.set_values(label->node, label->labels);
					C_in.insert(temp_in);
					if (temp_in.node == pre_node)
					{
						continue;
					}
					pre_node = temp_in.node;
					auto I_temp_out = I_out.find(temp_in.node);
					if (I_temp_out != I_out.end())
					{
						for (auto temp = I_temp_out->second.begin(); temp != I_temp_out->second.end(); temp++)
						{
							temp_in.set_values(temp->node, temp->labels);
							C_in.insert(temp_in);
						}
					}
				}
			}
		}
		pre_node = INF;
		if (exist_out != index.end())
		{
			for (auto iter = exist_out->second.out_labels.begin(); iter != exist_out->second.out_labels.end(); iter++)
			{
				for (auto label = iter->second.begin(); label != iter->second.end(); label++)
				{
					temp_out.set_values(label->node, label->labels);
					C_out.insert(temp_out);
					if (temp_out.node == pre_node)
					{
						continue;
					}
					pre_node = temp_out.node;
					auto I_temp_in = I_in.find(temp_out.node);
					if (I_temp_in != I_in.end())
					{
						for (auto temp = I_temp_in->second.begin(); temp != I_temp_in->second.end(); temp++)
						{
							temp_out.set_values(temp->node, temp->labels);
							C_out.insert(temp_out);
						}
					}
				}
			}
		}
		if (I_src != I_out.end())
		{
			for (auto iter = I_src->second.begin(); iter != I_src->second.end(); iter++)
			{
				temp_in.set_values(iter->node, iter->labels);
				C_in.insert(temp_in);
			}
		}
		if (I_dst != I_in.end())
		{
			for (auto iter = I_dst->second.begin(); iter != I_dst->second.end(); iter++)
			{
				temp_out.set_values(iter->node, iter->labels);
				C_out.insert(temp_out);
			}
		}
		auto iter_in = C_in.begin();
		auto iter_out = C_out.begin();
		NODE_TYPE max_rank = max(node_ranks[src], node_ranks[dst]);
		while(iter_in != C_in.end() && iter_out != C_out.end())
		{
			if (node_ranks[iter_in->node] > max_rank && node_ranks[iter_out->node] > max_rank)
			{
				break;
			}
			if (node_ranks[iter_in->node] < node_ranks[iter_out->node])
			{
				auto iter_temp = iter_out;
				while (iter_temp != C_out.end())
				{
					if (insert_index_in_tuple(iter_temp->node, iter_in->node, iter_temp->labels | binary_label | iter_in->labels))
					{
						insert_I_in(iter_in->node, iter_temp->node, iter_temp->labels | binary_label | iter_in->labels);
					}
					iter_temp++;
				}
				iter_in++;
			}
			else
			{
				auto iter_temp = iter_in;
				while (iter_temp != C_in.end())
				{
					if (insert_index_out_tuple(iter_temp->node, iter_out->node, iter_temp->labels | binary_label | iter_out->labels))
					{
						insert_I_out(iter_out->node, iter_temp->node, iter_temp->labels | binary_label | iter_out->labels);
					}
					iter_temp++;
				}
				iter_out++;
			}
		}


		/*if (node_ranks[src] > node_ranks[dst])
		{
			//if (!find_distance_ppl(src, dst, binary_label))
			//{// src cannot reach dst with binary_label, then insert dst into L_out
				insert_index_out_tuple(src, dst, binary_label);

			//}
			//
		}
		else {// src < dst
			//if (!find_distance_ppl(src, dst, binary_label))
			//{// src cannot reach dst with binary_label, then insert dst into L_out
				insert_index_in_tuple(dst, src, binary_label);
			//}
		}*/
		return true;
	}

	bool delete_edges_update_index(NODE_TYPE src, NODE_TYPE dst, LABEL_TYPE label, vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num)
	{
		bool delete_edge = false;
		for (auto iter = adjacency_list[src].begin(); iter != adjacency_list[src].end(); iter++)
		{
			if (iter->node == dst && iter->label == label)
			{
				delete_edge = true;
				iter = adjacency_list[src].erase(iter);
				break;
			}

		}
		if (delete_edge)
		{
			for (auto iter = adjacency_list_reverse[dst].begin(); iter != adjacency_list_reverse[dst].end(); iter++)
			{
				if (iter->node == src && iter->label == label)
				{
					iter = adjacency_list_reverse[dst].erase(iter);
					break;
				}

			}
		}
		if (!delete_edge)
		{
			cout << src << "\t" << dst << "\t" << label << "\t is not in adjacency list" << endl;
			return false;
		}
		return true;
	}


	uint32_t answer_LCR_naive_2hop(NODE_TYPE src, NODE_TYPE dst, LABEL_TYPE labels)
	{
		if (src == dst)
		{
			return 1;
		}
		uint32_t result = INF;
		auto index_dst = index.find(dst);
		auto index_src = index.find(src);
		if (index_dst == index.end() && index_src == index.end())//no index for this query
		{
			return INF;
		}
		else
		{
			//forward BFS
			set<NODE_TYPE> visited_nodes;
			visited_nodes.insert(src);
			set<NODE_TYPE> cur_propograte;
			set<NODE_TYPE> temp_propograte;
			cur_propograte.insert(src);
			while (!cur_propograte.empty())
			{
				temp_propograte.clear();
				for (auto iter1 = cur_propograte.begin(); iter1 != cur_propograte.end(); iter1++)
				{
					if (find_distance_ppl(*iter1, dst, labels) == 1)
					{
						return 1;
					}
					auto index_forward = index.find(*iter1);
					if (index_forward == index.end())
					{
						continue;
					}
					for (auto iter2 = index_forward->second.out_labels.begin(); iter2 != index_forward->second.out_labels.end(); iter2++)
					{
						if (visited_nodes.find(iter2->first) != visited_nodes.end())//already visited
						{
							continue;
						}
						if (!dominated_by_one_in_set(labels, iter2->second))
						{
							continue;
						}
						if (iter2->first == dst)
						{
							return 1;
						}
						temp_propograte.insert(iter2->first);
						visited_nodes.insert(iter2->first);
					}
				}
				cur_propograte = temp_propograte;
			}


			//backward BFS
			/*cur_propograte.clear();
			cur_propograte.insert(dst);
			temp_propograte.clear();
			set<NODE_TYPE> r_visited_nodes;
			r_visited_nodes.insert(dst);
			while (!cur_propograte.empty())
			{
				temp_propograte.clear();
				for (auto iter1 = cur_propograte.begin(); iter1 != cur_propograte.end(); iter1++)
				{
					auto index_forward = index.find(*iter1);
					if (index_forward == index.end())
					{
						continue;
					}
					for (auto iter2 = index_forward->second.in_labels.begin(); iter2 != index_forward->second.in_labels.end(); iter2++)
					{
						if (r_visited_nodes.find(iter2->first) != visited_nodes.end())//already visited
						{
							continue;
						}
						if (!dominated_by_one_in_set(labels,iter2->second))
						{
							continue;
						}
						if (iter2->first == src)
						{
							return 1;
						}
						if (visited_nodes.find(iter2->first) != visited_nodes.end())
						{
							return 1;
						}
						temp_propograte.insert(iter2->first);
						visited_nodes.insert(iter2->first);
					}
				}
				cur_propograte = temp_propograte;
			}
			*/
			//}
			//else
			//{
			//}
			//return INF;
		}
		return result;
	}


	uint32_t find_mindis_with_labels_constraint(set<ppl_LCR_pair>& pairs, LABEL_TYPE labels)
	{
		//int result = INF;
		for (auto pair : pairs)
		{
			if (A_is_subset_of_B(pair.labels, labels))
			{
				return 1;//the set ppl_pair is sorted by dis firstly
			}
			if (BitCount5(pair.labels) > BitCount5(labels))
			{
				break;
			}
		}
		return INF;
	}
	long long le_count = 0;


	uint32_t find_distance_ppl(NODE_TYPE src, NODE_TYPE dst, LABEL_TYPE labels)
	{
		le_count++;
		if (le_count % 100000 == 0)
		{
			//cout << le_count << "is the le count" << endl;
		}
		if (src == dst)
		{
			return 1;
		}
		uint32_t result = INF;
		auto index_dst = index.find(dst);
		auto index_src = index.find(src);
		if (index_dst == index.end() && index_src == index.end())//no index for this query
		{
			return INF;
		}
		else
		{
			//if (node_ranks[dst] < node_ranks[src])
			//{
				if (index_dst != index.end())
				{
					auto in_exist = index_dst->second.in_labels.find(src);
					if (in_exist == index_dst->second.in_labels.end())//no index for src dst
					{
						//return INF;
					}
					else {
						for (auto pair : in_exist->second)
						{
							//if (pair.node != src)
							//{
							//	continue;
							//}
							if (A_is_subset_of_B(pair.labels, labels))
							{
								return 1;
							}
							if (BitCount5(pair.labels) > BitCount5(labels))
							{
								break;
							}
						}
					}
				}
			//}
			//else
			//{
				if (index_src != index.end())
				{
					auto out_exist = index_src->second.out_labels.find(dst);
					if (out_exist == index_src->second.out_labels.end())//no index for src dst
					{
						//return INF;
					}
					else {
						for (auto pair : out_exist->second)
						{
							//if (pair.node != dst)
							//{
							//	continue;
							//}
							if (A_is_subset_of_B(pair.labels, labels))
							{
								return 1;
							}
							if (BitCount5(pair.labels) > BitCount5(labels))
							{
								break;
							}
						}
					}
				}
			//}
			if (index_dst == index.end() || index_src == index.end())//no index for this query
			{
				return INF;
			}
			if(index_dst->second.in_labels.size() < index_src->second.out_labels.size())
			{ 
				for (auto iter1 = index_dst->second.in_labels.begin(); iter1 != index_dst->second.in_labels.end(); iter1++)
				{


					uint32_t dis1 = find_mindis_with_labels_constraint(iter1->second, labels);
					if (dis1 == INF)
					{
						continue;
					}
					auto iter2 = index_src->second.out_labels.find(iter1->first);
					if (iter2 == index_src->second.out_labels.end())
					{
						continue;
					}
					uint32_t dis2 = find_mindis_with_labels_constraint(iter2->second, labels);
					if (dis2 == INF)
					{
						continue;
					}
					else {
						return 1;
					}
				}

			}
			else {
				for (auto iter1 = index_src->second.out_labels.begin(); iter1 != index_src->second.out_labels.end(); iter1++)
				{


					uint32_t dis1 = find_mindis_with_labels_constraint(iter1->second, labels);
					if (dis1 == INF)
					{
						continue;
					}
					auto iter2 = index_dst->second.in_labels.find(iter1->first);
					if (iter2 == index_dst->second.in_labels.end())
					{
						continue;
					}
					uint32_t dis2 = find_mindis_with_labels_constraint(iter2->second, labels);
					if (dis2 == INF)
					{
						continue;
					}
					else {
						return 1;
					}
				}
			}
			//return INF;
		}
		return result;
	}
	uint32_t find_distance_single_ppl(NODE_TYPE src, NODE_TYPE dst, LABEL_TYPE labels)
	{
		le_count++;
		if (le_count % 100000 == 0)
		{
			cout << le_count << "is the le count" << endl;
		}
		if (src == dst)
		{
			return 1;
		}
		uint32_t result = INF;
		auto index_dst = index.find(dst);
		auto index_src = index.find(src);
		if (index_dst == index.end() && index_src == index.end())//no index for this query
		{
			return INF;
		}
		else
		{
			//if (node_ranks[dst] < node_ranks[src])
			//{
			if (index_dst != index.end())
			{
				auto in_exist = index_dst->second.in_labels.find(src);
				if (in_exist == index_dst->second.in_labels.end())//no index for src dst
				{
					//return INF;
				}
				else {
					for (auto pair : in_exist->second)
					{
						//if (pair.node != src)
						//{
						//	continue;
						//}
						if (A_is_subset_of_B(pair.labels, labels))
						{
							return 1;
						}
						if (BitCount5(pair.labels) > BitCount5(labels))
						{
							break;
						}
					}
				}
			}
			//}
			//else
			//{
			if (index_src != index.end())
			{
				auto out_exist = index_src->second.out_labels.find(dst);
				if (out_exist == index_src->second.out_labels.end())//no index for src dst
				{
					//return INF;
				}
				else {
					for (auto pair : out_exist->second)
					{
						//if (pair.node != dst)
						//{
						//	continue;
						//}
						if (A_is_subset_of_B(pair.labels, labels))
						{
							return 1;
						}
						if (BitCount5(pair.labels) > BitCount5(labels))
						{
							break;
						}
					}
				}
			}
			//}
			if (index_dst == index.end() || index_src == index.end())//no index for this query
			{
				return INF;
			}
		
			//return INF;
		}
		return result;
	}

};



class pruned_landmark_label
{
public:
	map<NODE_TYPE, ppl_label_index> index;// the value of vertex may be not continuous
	pruned_landmark_label() {};

	bool construct_label_index(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num)
	{
		//sort by node degree
		vector<hot_degree> hot_points;
		for (NODE_TYPE i = 0; i < node_num; i++)
		{
			NODE_TYPE temp_degree = adjacency_list[i].size() + adjacency_list_reverse[i].size();
			if (temp_degree != 0)
			{
				hot_degree hd1(i, temp_degree);
				hot_points.push_back(hd1);
			}
		}
		stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());

		ppl_pair_propagate src(0, 0);
		set<ppl_pair_propagate> cur_propagate;
		set<ppl_pair_propagate> cur_propagate_reverse;
		set<ppl_pair_propagate> temp_propagate;
		ppl_pair new_pair;
		ppl_pair_propagate new_pair_propagate;
		ppl_pair in_label;
		//ppl_label_index new_in_out;
		ppl_pair out_label;
		set<NODE_TYPE> already_indexed;
		for (NODE_TYPE i = 1; i <= node_num; i++)
			//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
			//for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
		{

			//NODE_TYPE i = node_explore->node;
			src.node = i;
			if (i % 10 == 0)
			{
				cout << i << endl;
			}
			//BFS to construct the index
			cur_propagate.clear();
			cur_propagate_reverse.clear();


			//forward bfs
			cur_propagate.insert(src);
			set<NODE_TYPE> visited_index_nodes;
			while (!cur_propagate.empty())
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate.begin(); iter1 != cur_propagate.end(); iter1++)
				{
					for (auto edge = adjacency_list[iter1->node].begin(); edge != adjacency_list[iter1->node].end(); edge++)
					{
						if (edge->node == 73)
						{
							//cout << 73 << endl;
						}
						if (already_indexed.find(edge->node) != already_indexed.end())
						{
							continue;
						}
						new_pair.set_values(edge->node, iter1->dis, iter1->labels);
						new_pair_propagate.set_values(edge->node, iter1->dis, iter1->labels);
						new_pair.dis += edge->weight;
						new_pair.labels.insert(edge->label);

						new_pair_propagate.dis += edge->weight;
						new_pair_propagate.labels.insert(edge->label);

						NODE_TYPE cur_node = edge->node;
						in_label.set_values(i, new_pair.dis, new_pair.labels);// store the start node
						auto exist_index = index.find(cur_node);
						if (cur_node == 38)
						{
							//cout << 38 << endl;
						}
						if (exist_index == index.end())//first time to insert index for node cur_node
						{
							ppl_label_index new_in_out;
							new_in_out.insert_in_label(in_label);
							index.insert(std::make_pair(cur_node, new_in_out));
							temp_propagate.insert(new_pair_propagate);
						}
						else
						{
							auto exist_in = exist_index->second.in_labels.find(in_label.node);
							if (exist_in == exist_index->second.in_labels.end())
							{
								exist_index->second.insert_in_label(in_label);
								temp_propagate.insert(new_pair_propagate);
								continue;
							}
							if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
							{
								exist_index->second.insert_in_label(in_label);
								temp_propagate.insert(new_pair_propagate);
							}
						}
					}
				}
				cur_propagate = temp_propagate;
			}
			//when to stop 
			//reverse bfs
			cur_propagate_reverse.insert(src);
			while (!cur_propagate_reverse.empty())
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate_reverse.begin(); iter1 != cur_propagate_reverse.end(); iter1++)
				{
					for (auto edge = adjacency_list_reverse[iter1->node].begin(); edge != adjacency_list_reverse[iter1->node].end(); edge++)
					{
						if (already_indexed.find(edge->node) != already_indexed.end())
						{
							continue;
						}
						new_pair.set_values(edge->node, iter1->dis, iter1->labels);
						new_pair_propagate.set_values(edge->node, iter1->dis, iter1->labels);

						new_pair_propagate.dis += edge->weight;//should equal to 1,otherwise, it may cause some errors
						new_pair_propagate.labels.insert(edge->label);

						new_pair.dis += edge->weight;//should equal to 1,otherwise, it may cause some errors
						new_pair.labels.insert(edge->label);
						NODE_TYPE cur_node = edge->node;
						out_label.set_values(i, new_pair.dis, new_pair.labels);// store the start node
						auto exist_index = index.find(cur_node);
						if (exist_index == index.end())//first time to insert index for node cur_node
						{
							ppl_label_index new_in_out;
							new_in_out.insert_out_label(out_label);
							index.insert(std::make_pair(cur_node, new_in_out));
							temp_propagate.insert(new_pair_propagate);
						}
						else
						{
							auto exist_out = exist_index->second.out_labels.find(out_label.node);
							if (exist_out == exist_index->second.out_labels.end())
							{
								exist_index->second.insert_out_label(out_label);
								temp_propagate.insert(new_pair_propagate);
								continue;
							}
							if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
							{
								exist_index->second.insert_out_label(out_label);
								temp_propagate.insert(new_pair_propagate);
							}
						}
					}
				}
				cur_propagate_reverse = temp_propagate;
			}
			already_indexed.insert(i);
		}
		return true;
	}
	uint32_t find_mindis_with_labels_constraint(set<ppl_pair>& pairs, set<LABEL_TYPE>& labels)
	{
		//int result = INF;
		for (auto pair : pairs)
		{
			//if(pair.node != )
			if (A_is_subset_of_B(pair.labels, labels))
			{
				return pair.dis;//the set ppl_pair is sorted by dis firstly
			}
		}
		return INF;
	}
	uint32_t find_distance_ppl(NODE_TYPE src, NODE_TYPE dst, set<LABEL_TYPE>& labels)
	{
		if (src == dst)
		{
			return 0;
		}
		uint32_t result = INF;
		auto index_dst = index.find(dst);
		auto index_src = index.find(src);
		if (index_dst == index.end() || index_src == index.end())//no index for this query
		{
			return INF;
		}
		else
		{
			auto in_exist = index_dst->second.in_labels.find(src);
			if (in_exist == index_dst->second.in_labels.end())//no index for src dst
			{
				//return INF;
			}
			else {
				for (auto pair : in_exist->second)
				{
					if (pair.node != src)
					{
						continue;
					}
					if (A_is_subset_of_B(pair.labels, labels))
					{
						if (pair.dis < result) {
							result = pair.dis;
						}
					}
				}
			}

			auto out_exist = index_src->second.out_labels.find(dst);
			if (out_exist == index_src->second.out_labels.end())//no index for src dst
			{
				//return INF;
			}
			else {
				for (auto pair : out_exist->second)
				{
					if (pair.node != dst)
					{
						continue;
					}
					if (A_is_subset_of_B(pair.labels, labels))
					{
						if (pair.dis < result) {
							result = pair.dis;
						}
					}
				}
			}




			for (auto iter1 = index_dst->second.in_labels.begin(); iter1 != index_dst->second.in_labels.end(); iter1++)
			{
				auto iter2 = index_src->second.out_labels.find(iter1->first);
				if (iter2 == index_src->second.out_labels.end())
				{
					continue;
				}
				uint32_t dis1 = find_mindis_with_labels_constraint(iter1->second, labels);
				uint32_t dis2 = find_mindis_with_labels_constraint(iter2->second, labels);
				if (dis1 == INF || dis2 == INF)
				{
					continue;
				}
				if (dis1 + dis2 < result)
				{
					result = dis1 + dis2;
				}

			}
			//return INF;
		}
		return result;
	}
};

class full_landmark_index
{
public:
	unordered_map<NODE_TYPE, ppl_label_index> index;// the value of vertex may be not continuous
	full_landmark_index() {};

	bool construct_label_index(vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, NODE_TYPE node_num)
	{
		//sort by node degree
		vector<hot_degree> hot_points;
		for (NODE_TYPE i = 0; i < node_num; i++)
		{
			NODE_TYPE temp_degree = adjacency_list[i].size() + adjacency_list_reverse[i].size();
			if (temp_degree != 0)
			{
				hot_degree hd1(i, temp_degree);
				hot_points.push_back(hd1);
			}
		}
		stable_sort(hot_points.begin(), hot_points.end(), less<hot_degree>());

		ppl_pair_propagate src(0, 0);
		set<ppl_pair_propagate> cur_propagate;
		set<ppl_pair_propagate> cur_propagate_reverse;
		set<ppl_pair_propagate> temp_propagate;
		ppl_pair new_pair;
		ppl_pair_propagate new_pair_propagate;
		ppl_pair in_label;
		//ppl_label_index new_in_out;
		ppl_pair out_label;
		set<NODE_TYPE> already_indexed;
		//for (NODE_TYPE i = 1; i <= node_num; i++)
		//for (auto node_explore = hot_points.rbegin(); node_explore != hot_points.rend(); node_explore++)
		for (auto node_explore = hot_points.begin(); node_explore != hot_points.end(); node_explore++)
		{

			NODE_TYPE i = node_explore->node;
			src.node = i;
			if (i % 10 == 0)
			{
				cout << i << endl;
			}
			//BFS to construct the index
			cur_propagate.clear();
			cur_propagate_reverse.clear();


			//forward bfs
			cur_propagate.insert(src);
			while (!cur_propagate.empty())
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate.begin(); iter1 != cur_propagate.end(); iter1++)
				{
					for (auto edge = adjacency_list[iter1->node].begin(); edge != adjacency_list[iter1->node].end(); edge++)
					{
						if (edge->node == 73)
						{
							//cout << 73 << endl;
						}
						new_pair.set_values(edge->node, iter1->dis, iter1->labels);
						new_pair_propagate.set_values(edge->node, iter1->dis, iter1->labels);
						new_pair.dis += edge->weight;
						new_pair.labels.insert(edge->label);

						new_pair_propagate.dis += edge->weight;
						new_pair_propagate.labels.insert(edge->label);

						NODE_TYPE cur_node = edge->node;
						in_label.set_values(i, new_pair.dis, new_pair.labels);// store the start node
						auto exist_index = index.find(cur_node);
						if (cur_node == 38)
						{
							//cout << 38 << endl;
						}
						if (exist_index == index.end())//first time to insert index for node cur_node
						{
							ppl_label_index new_in_out;
							new_in_out.insert_in_label(in_label);
							index.insert(std::make_pair(cur_node, new_in_out));
							temp_propagate.insert(new_pair_propagate);
						}
						else
						{
							auto exist_in = exist_index->second.in_labels.find(in_label.node);
							if (exist_in == exist_index->second.in_labels.end())
							{
								exist_index->second.insert_in_label(in_label);
								temp_propagate.insert(new_pair_propagate);
								continue;
							}
							if (!in_label.dominated_by_one_in_set(exist_in->second))//explore conditions: not dominate by any one in in_labels
							{
								exist_index->second.insert_in_label(in_label);
								temp_propagate.insert(new_pair_propagate);
							}
						}
					}
				}
				cur_propagate = temp_propagate;
			}
			//when to stop 
			//reverse bfs
			cur_propagate_reverse.insert(src);
			while (!cur_propagate_reverse.empty())
			{
				temp_propagate.clear();
				for (auto iter1 = cur_propagate_reverse.begin(); iter1 != cur_propagate_reverse.end(); iter1++)
				{
					for (auto edge = adjacency_list_reverse[iter1->node].begin(); edge != adjacency_list_reverse[iter1->node].end(); edge++)
					{
						new_pair.set_values(edge->node, iter1->dis, iter1->labels);
						new_pair_propagate.set_values(edge->node, iter1->dis, iter1->labels);

						new_pair_propagate.dis += edge->weight;//should equal to 1,otherwise, it may cause some errors
						new_pair_propagate.labels.insert(edge->label);

						new_pair.dis += edge->weight;//should equal to 1,otherwise, it may cause some errors
						new_pair.labels.insert(edge->label);
						NODE_TYPE cur_node = edge->node;
						out_label.set_values(i, new_pair.dis, new_pair.labels);// store the start node
						auto exist_index = index.find(cur_node);
						if (exist_index == index.end())//first time to insert index for node cur_node
						{
							ppl_label_index new_in_out;
							new_in_out.insert_out_label(out_label);
							index.insert(std::make_pair(cur_node, new_in_out));
							temp_propagate.insert(new_pair_propagate);
						}
						else
						{
							auto exist_out = exist_index->second.out_labels.find(out_label.node);
							if (exist_out == exist_index->second.out_labels.end())
							{
								exist_index->second.insert_out_label(out_label);
								temp_propagate.insert(new_pair_propagate);
								continue;
							}
							if (!out_label.dominated_by_one_in_set(exist_out->second))//explore conditions: not dominate by any one in in_labels
							{
								exist_index->second.insert_out_label(out_label);
								temp_propagate.insert(new_pair_propagate);
							}
						}
					}
				}
				cur_propagate_reverse = temp_propagate;
			}
			already_indexed.insert(i);
		}
		return true;
	}
	uint32_t find_mindis_with_labels_constraint(set<ppl_pair>& pairs, set<LABEL_TYPE>& labels)
	{
		//int result = INF;
		for (auto pair : pairs)
		{
			if (A_is_subset_of_B(pair.labels, labels))
			{
				return pair.dis;//the set ppl_pair is sorted by dis firstly
			}
		}
		return INF;
	}
	uint32_t find_distance_ppl(NODE_TYPE src, NODE_TYPE dst, set<LABEL_TYPE>& labels)
	{
		if (src == dst)
		{
			return 0;
		}
		uint32_t result = INF;
		auto index_dst = index.find(dst);
		auto index_src = index.find(src);
		if (index_dst == index.end() || index_src == index.end())//no index for this query
		{
			return INF;
		}
		else
		{
			auto in_exist = index_dst->second.in_labels.find(src);
			if (in_exist == index_dst->second.in_labels.end())//no index for src dst
			{
				//return INF;
			}
			else {
				for (auto pair : in_exist->second)
				{
					if (pair.node != src)
					{
						continue;
					}
					if (A_is_subset_of_B(pair.labels, labels))
					{
						if (pair.dis < result) {
							result = pair.dis;
						}
					}
				}
			}
			for (auto iter1 = index_dst->second.in_labels.begin(); iter1 != index_dst->second.in_labels.end(); iter1++)
			{
				auto iter2 = index_src->second.out_labels.find(iter1->first);
				if (iter2 == index_src->second.out_labels.end())
				{
					continue;
				}
				uint32_t dis1 = find_mindis_with_labels_constraint(iter1->second, labels);
				uint32_t dis2 = find_mindis_with_labels_constraint(iter2->second, labels);
				if (dis1 == INF || dis2 == INF)
				{
					continue;
				}
				if (dis1 + dis2 < result)
				{
					result = dis1 + dis2;
				}

			}
			//return INF;
		}
		return result;
	}
};



struct cmp_int_pair {
	bool operator()(pair<uint32_t, uint32_t> a, pair<uint32_t, uint32_t> b) {
		if (a.first == b.first)	return a.second>b.second;
		return a.first>b.first;
	}
};

void load_label_graph(string filename, long node_num, vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, vector<double>& node_in_labels, vector<double>& node_out_labels, vector<vector<label_edge>>* vec_adjacency_list, vector<vector<label_edge>>* vec_adjacency_list_reverse, int label_num, vector<double>& label_ranks)
{
	for (int i = 0; i < node_num; i++)
	{
		vec_adjacency_list[i].resize(label_num + 1);
		vec_adjacency_list_reverse[i].resize(label_num + 1);
	}
	vector<set<LABEL_TYPE>> node_inset_labels;
	vector<set<LABEL_TYPE>> node_outset_labels;
	node_inset_labels.resize(node_num + 1);
	node_outset_labels.resize(node_num + 1);
	node_in_labels.resize(node_num + 1);
	node_out_labels.resize(node_num + 1);

	label_ranks.resize(label_num);

	for (int i = 0; i < label_ranks.size(); i++)
	{
		label_ranks[i] = 0;
	}
	ifstream input(filename);
	if (!input.is_open())
	{
		cerr << "Input file cannot be opened!" << endl;
		return;
		//return index;
	}
	int label;
	NODE_TYPE src, dst;// , label;
	DIS_TYPE weight;
	unordered_map<uint32_t, unordered_set<uint32_t> > other_hosts_map;
	map<std::pair<NODE_TYPE, NODE_TYPE>, bool > remove_duplicate;
	string str;
	//for (int i = 1; i <= 9; i++)
	//{
		//getline(input, str);
	//}
	weight = 1;
	while (input >> src >> dst >>  label)
	{
		//label = 0;
		//label++;
		if (weight > 1)
		{
			cout << src << "\t" << dst << "\t" << weight << endl;
		}
		auto iter = remove_duplicate.find(std::make_pair(src, dst));
		if (iter == remove_duplicate.end())//remove duplicate edges
		{
			remove_duplicate.insert(std::make_pair(std::make_pair(src, dst), true));
			label_edge temp;
			label_edge temp_reverse;
			label_ranks[label] ++;
			temp.label = label;
			temp.node = dst;
			temp.weight = weight;
			temp_reverse.label = label;
			temp_reverse.node = src;
			temp_reverse.weight = weight;
			//if (false)//label == 7)
			//{
			//	adjacency_list[src].insert(adjacency_list[src].begin(),temp);
			//	adjacency_list_reverse[dst].insert(adjacency_list_reverse[dst].begin(),temp_reverse);
			//}
			//else
			//{
			adjacency_list[src].push_back(temp);
			adjacency_list_reverse[dst].push_back(temp_reverse);
			vec_adjacency_list[src][label].push_back(temp);
			vec_adjacency_list_reverse[dst][label].push_back(temp_reverse);

			node_inset_labels[dst].insert(label);
			//node_inset_labels[src].insert(label);
			node_outset_labels[src].insert(label);
			//}
		}
	
	}
	//for (int i = 0; i < node_num; i++)
	//{
	//	node_in_labels[i] = 0;
	//	node_out_labels[i] = 0;
	//	for (auto iter2 = node_inset_labels[i].begin(); iter2 != node_inset_labels[i].end(); iter2++)
	//	{
	//		node_in_labels[i] += label_ranks[*iter2]/(node_num*1.0);
	//	}
	//	for (auto iter2 = node_outset_labels[i].begin(); iter2 != node_outset_labels[i].end(); iter2++)
	//	{
	//		node_out_labels[i] += label_ranks[*iter2]/(node_num*1.0);
	//	}
	//}
	double total = 0;
	for (int i = 0; i < label_ranks.size(); i++)
	{
		total += label_ranks[i];
	}

	for (int i = 0; i < label_ranks.size(); i++)
	{
		label_ranks[i] = label_ranks[i] / (total);
		cout << "label" << i << "\t" << label_ranks[i] << endl;
	}
	cout << "done" << endl;
}

void load_label_graph_get_node_edge_num(string filename, uint32_t& node_num, uint32_t & edge_num)
{
	node_num = 0;
	edge_num = 0;
	label_ranks.resize(16);

	for (int i = 0; i < label_ranks.size(); i++)
	{
		label_ranks[i] = 0;
	}
	ifstream input(filename);
	if (!input.is_open())
	{
		cerr << "Input file cannot be opened!" << endl;
		return;
		//return index;
	}
	int label;
	NODE_TYPE src, dst;// , label;
	DIS_TYPE weight;
	unordered_map<uint32_t, unordered_set<uint32_t> > other_hosts_map;
	map<std::pair<NODE_TYPE, NODE_TYPE>, bool > remove_duplicate;
	string str;
	//for (int i = 1; i <= 9; i++)
	//{
	//getline(input, str);
	//}
	weight = 1;
	while (input >> src >> dst >> label)
	{
		//label = 0;
		//label++;
		if (weight > 1)
		{
			cout << src << "\t" << dst << "\t" << weight << endl;
		}
		auto iter = remove_duplicate.find(std::make_pair(src, dst));
		if (iter == remove_duplicate.end())//remove duplicate edges
		{
			edge_num++;
			remove_duplicate.insert(std::make_pair(std::make_pair(src, dst), true));
			if (src > node_num) node_num = src;
			if (dst > node_num) node_num = dst;
			//if (false)//label == 7)
			//{
			//	adjacency_list[src].insert(adjacency_list[src].begin(),temp);
			//	adjacency_list_reverse[dst].insert(adjacency_list_reverse[dst].begin(),temp_reverse);
			//}
			//else
			//{
			//adjacency_list[src].push_back(temp);
			//adjacency_list_reverse[dst].push_back(temp_reverse);
			//}
		}
	}
}

//void load_label_graph(string filename, long node_num, vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, bool dynamic_bv)
//{
//
//	vector<label_edge>* adjacency_list_temp = new 
//	vector<label_edge>* adjacency_list_reverse
//	label_ranks.resize(10000);
//
//	for (int i = 0; i < label_ranks.size(); i++)
//	{
//		label_ranks[i] = 0;
//	}
//	ifstream input(filename);
//	if (!input.is_open())
//	{
//		cerr << "Input file cannot be opened!" << endl;
//		return;
//		//return index;
//	}
//	int label;
//	NODE_TYPE src, dst;// , label;
//	DIS_TYPE weight;
//	unordered_map<uint32_t, unordered_set<uint32_t> > other_hosts_map;
//	map<std::pair<NODE_TYPE, NODE_TYPE>, bool > remove_duplicate;
//	string str;
//	//for (int i = 1; i <= 9; i++)
//	//{
//	//getline(input, str);
//	//}
//	weight = 1;
//	while (input >> src >> dst >> label)
//	{
//		//label = 0;
//		//label++;
//		if (weight > 1)
//		{
//			cout << src << "\t" << dst << "\t" << weight << endl;
//		}
//		auto iter = remove_duplicate.find(std::make_pair(src, dst));
//		if (iter == remove_duplicate.end())//remove duplicate edges
//		{
//			remove_duplicate.insert(std::make_pair(std::make_pair(src, dst), true));
//			label_edge temp;
//			label_edge temp_reverse;
//			label_ranks[label] ++;
//			temp.label = label;
//			temp.node = dst;
//			temp.weight = weight;
//			temp_reverse.label = label;
//			temp_reverse.node = src;
//			temp_reverse.weight = weight;
//			//if (false)//label == 7)
//			//{
//			//	adjacency_list[src].insert(adjacency_list[src].begin(),temp);
//			//	adjacency_list_reverse[dst].insert(adjacency_list_reverse[dst].begin(),temp_reverse);
//			//}
//			//else
//			//{
//			adjacency_list[src].push_back(temp);
//			adjacency_list_reverse[dst].push_back(temp_reverse);
//			//}
//		}
//	}
//	for (int i = 0; i < label_ranks.size(); i++)
//	{
//		cout << "label" << i << "\t" << label_ranks[i] << endl;
//	}
//
//}

bool compare_label_ranks(const pair<LABEL_TYPE, int>&i, const pair<LABEL_TYPE, int>&j)
{
	return i.second > j.second;
}

void load_label_graph(string filename, long node_num, vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse)
{

	vector<LABEL_TYPE> label_ranks_temp;

	label_ranks.resize(10000);
	label_ranks_temp.resize(10000);
	for (int i = 0; i < label_ranks_temp.size(); i++)
	{
		label_ranks_temp[i] = 0;
	}
	ifstream input(filename);
	if (!input.is_open())
	{
		cerr << "Input file cannot be opened!" << endl;
		return;
		//return index;
	}
	int label;
	NODE_TYPE src, dst;// , label;
	DIS_TYPE weight;
	unordered_map<uint32_t, unordered_set<uint32_t> > other_hosts_map;
	map<std::pair<NODE_TYPE, NODE_TYPE>, bool > remove_duplicate;
	string str;
	//for (int i = 1; i <= 9; i++)
	//{
	//getline(input, str);
	//}
	weight = 1;
	while (input >> src >> dst >> label)
	{
		//label = 0;
		//label++;
		if (weight > 1)
		{
			cout << src << "\t" << dst << "\t" << weight << endl;
		}
		auto iter = remove_duplicate.find(std::make_pair(src, dst));
		if (iter == remove_duplicate.end())//remove duplicate edges
		{
			remove_duplicate.insert(std::make_pair(std::make_pair(src, dst), true));
			label_edge temp;
			label_edge temp_reverse;
			label_ranks_temp[label] ++;
			temp.label = label;
			temp.node = dst;
			temp.weight = weight;
			temp_reverse.label = label;
			temp_reverse.node = src;
			temp_reverse.weight = weight;
			//if (false)//label == 7)
			//{
			//	adjacency_list[src].insert(adjacency_list[src].begin(),temp);
			//	adjacency_list_reverse[dst].insert(adjacency_list_reverse[dst].begin(),temp_reverse);
			//}
			//else
			//{
			adjacency_list[src].push_back(temp);
			adjacency_list_reverse[dst].push_back(temp_reverse);
			//}
		}
	}
	for (int i = 0; i < label_ranks_temp.size(); i++)
	{
		if(label_ranks_temp[i])
		cout << "label" << i << "\t" << label_ranks_temp[i] << endl;
	}
	vector<pair<LABEL_TYPE, int>> temp_ranks;
	for (int i = 0; i < label_ranks_temp.size(); i++)
	{
		if (label_ranks_temp[i])
			temp_ranks.push_back(make_pair(i,label_ranks_temp[i]));
	}
	sort(temp_ranks.begin(), temp_ranks.end(), compare_label_ranks);
	for (int i = 0; i < temp_ranks.size(); i++)
	{
		if (temp_ranks[i].first)
			cout << "label" << i << "\t" << temp_ranks[i].first << endl;
	}
	for (int i = 0; i < temp_ranks.size(); i++)
	{
		label_ranks[temp_ranks[i].first] = i+1;
	}
}



int test_dfs_with_label(NODE_TYPE src, NODE_TYPE dst, set<LABEL_TYPE> labels, int node_num, string filename, vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse)
{
	//long node_num = 100;
	//load the graph file
	//string filename = "youtube_subset.txt_small";

	//query by using the dijkstra algorithm
	unordered_map<NODE_TYPE, NODE_TYPE> preVertex;
	unordered_map<uint32_t, uint32_t> distances; //node,distance currently using a map because ID is not contiguous
	distances[src] = 0;
	//priority_queue<pair<uint32_t, uint32_t>, vector<pair<uint32_t, uint32_t> >, greater<pair<uint32_t, uint32_t> > > dj_q;
	priority_queue<pair<uint32_t, uint32_t>, vector<pair<uint32_t, uint32_t> >, cmp_int_pair > dj_q;//distance and node id

	dj_q.emplace(0, src);
	while (!dj_q.empty())
	{
		auto v = dj_q.top();
		dj_q.pop();
		auto it = distances.find(v.second);
		if (it != distances.end() && v.first == it->second) // ignore redundant entries in PQ
		{

			// loop over the outgoing edges
			for (auto edge = adjacency_list[v.second].begin(); edge != adjacency_list[v.second].end(); edge++)
			{
				if (labels.find(edge->label) == labels.end()) //invalid labe
				{
					continue;
				}
				uint32_t new_weight = v.first + edge->weight;
				auto preUpdate = preVertex.find(edge->node);
				if (preUpdate == preVertex.end())
				{//first time to insert
					preVertex.insert(std::make_pair(edge->node, v.second));
				}
				else {
					preUpdate->second = edge->node;
				}
				auto it = distances.find(edge->node);
				if (it == distances.end() || it->second > new_weight)
				{
					distances[edge->node] = new_weight;
					dj_q.emplace(new_weight, edge->node);
				}
			}
		}
	}
	//output the result path
	auto res = distances.find(dst);
	if (res == distances.end())
	{
		cout << src << " cannot reach " << dst << endl;
		return INF;
	}
	else {
		cout << "distance : " << res->second << endl;
	}
	if (res->second == INF)
		return INF;
	return 1;
	//return res->second;
}


int test_edp_by_queryset_dynamic(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries)
{
	auto found = input.rfind('/');
	string result;
	if (found != std::string::npos)
	{
		string temp(input.begin() + found + 1, input.end());
		result = temp;
	}
	else {
		result = input;
	}
	ofstream al1, al2, runtime_file;
	al1.open(result + "_BFS_result");
	al2.open(result + "_2hop_result");
	runtime_file.open(result + "_runtime");
	runtime_file << "src" << " \t " << "dst" << "\t" << "bfs ms" << "\t" << "2hop ms" << endl;
	double bfs_total_runtime_true = 0;
	double bfs_total_runtime_false = 0;
	double twohop_total_runtime_true = 0;
	double twohop_total_runtime_false = 0;

	//uint32_t num_of_labels = 8;// atoi(argv[2]);
	uint32_t num_of_vertices = node_num;// 2000;// atoi(argv[3]);100000 for twitter
										//uint32_t num_of_queries = 1000;
										//uint32_t querset_num = 3;

										//uint32_t node_num = num_of_vertices;
	vector<label_edge>* adjacency_list = new vector<label_edge>[num_of_vertices + 1];
	vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[num_of_vertices + 1];


	cout << "----Stage 1: initialization----" << endl;
	//string input(argv[1]);
	//string input("youtube_subset.txt");
	//string input("Wiki-Vote.txt_randint");
	//string input("twitter_combined.txtreoder_randint");
	//string input("V10kD5L8exp.edge");
	//string input("advogato.edge");
	load_label_graph(input, num_of_vertices, adjacency_list, adjacency_list_reverse);
	auto index_ppl_start = chrono::high_resolution_clock::now();


	//choose which index to construct
	LCR_index ppl_index;//
	LCR_index ppl_between;					//end of construction


											//ppl_index.construct_label_index_priority_queue(adjacency_list, adjacency_list_reverse, num_of_vertices);

	ppl_index.construct_label_index(adjacency_list, adjacency_list_reverse, num_of_vertices);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	auto index_ppl_end = chrono::high_resolution_clock::now();
	cout << "Created index ppl" << endl;
	//cout << sizeof(int) << " size for int " << endl;
	cout << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	runtime_file << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	auto index_edp_start = chrono::high_resolution_clock::now();
	//auto index = RunAlgorithmOne(input, num_of_labels);
	auto index_edp_end = chrono::high_resolution_clock::now();
	cout << "Created index edp" << endl;



	auto diff_edp = chrono::duration_cast<chrono::milliseconds>(index_edp_end - index_edp_start);
	auto diff_ppl = chrono::duration_cast<chrono::milliseconds>(index_ppl_end - index_ppl_start);
	cout << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;

	runtime_file << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;



	cout << "----Stage 2: query processing----" << endl;

	unordered_set<LABEL_TYPE> labels;
	set<LABEL_TYPE> temp_labels;
	uint32_t cost2;
	uint32_t cost;
	for (uint32_t iter = 0; iter < querset_num; ++iter)
	{
		string query_true = input + to_string(iter) + ".true";
		string query_false = input + to_string(iter) + ".false";
		ifstream file_true(query_true);
		ifstream file_false(query_false);
		if (!file_true.is_open())
		{
			cerr << "true query file cannot be opened!" << endl;
			return -1;
			//return index;
		}
		LABEL_TYPE label;
		NODE_TYPE src, dst;// , label;
		while (file_true >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			//for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_true += diff.count() / 1e3;
			twohop_total_runtime_true += diff2.count() / 1e3;
			runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}

		while (file_false >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_false += diff.count() / 1e3;
			twohop_total_runtime_false += diff2.count() / 1e3;
			runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost which is wrong" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}

	}
	runtime_file << "bfs average true: false\t" << bfs_total_runtime_true / (querset_num*num_of_queries) << "\t" << bfs_total_runtime_false / (querset_num*num_of_queries) << "\t two hop average true:false\t" << twohop_total_runtime_true / (querset_num*num_of_queries) << "\t" << twohop_total_runtime_false / (querset_num*num_of_queries) << endl;
	al1.close();
	al2.close();
	runtime_file.close();


	return 0;
}

int test_edp_by_queryset_large_label(string input, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries)
{
	bool dynamic_bv = false;
	uint32_t node_num = 0;
	uint32_t edge_num = 0;
	auto found = input.rfind('/');
	string result;
	if (found != std::string::npos)
	{
		string temp(input.begin() + found + 1, input.end());
		result = temp;
	}
	else {
		result = input;
	}
	//result += "_mininal_";
	ofstream al1, al2, runtime_file;
	//al1.open(result + "_BFS_result");
	al2.open(result + "_2hop_result");
	runtime_file.open(result + "_runtime");
	runtime_file << "src" << " \t " << "dst" << "\t" << "bfs ms" << "\t" << "2hop ms" << endl;
	double bfs_total_runtime_true = 0;
	double bfs_total_runtime_false = 0;
	double twohop_total_runtime_true = 0;
	double twohop_total_runtime_false = 0;
	node_num = 0;
	load_label_graph_get_node_edge_num(input, node_num, edge_num);
	//uint32_t num_of_labels = 8;// atoi(argv[2]);
	uint32_t num_of_vertices = node_num;// 2000;// atoi(argv[3]);100000 for twitter
										//uint32_t num_of_queries = 1000;
										//uint32_t querset_num = 3;

										//uint32_t node_num = num_of_vertices;
	vector<label_edge>* adjacency_list = new vector<label_edge>[num_of_vertices + 1];
	vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[num_of_vertices + 1];


	cout << "----Stage 1: initialization----" << endl;
	//string input(argv[1]);
	//string input("youtube_subset.txt");
	//string input("Wiki-Vote.txt_randint");
	//string input("twitter_combined.txtreoder_randint");
	//string input("V10kD5L8exp.edge");
	//string input("advogato.edge");

	load_label_graph(input, num_of_vertices, adjacency_list, adjacency_list_reverse);
	//change the label to label ranks in adjacency_list
	if (dynamic_bv)
	{
		for (int i = 0; i < num_of_vertices; i++)
		{
			for (auto iter = adjacency_list[i].begin(); iter != adjacency_list[i].end(); iter++)
			{
				iter->label = label_ranks[iter->label];
			}
			for (auto iter = adjacency_list_reverse[i].begin(); iter != adjacency_list_reverse[i].end(); iter++)
			{
				iter->label = label_ranks[iter->label];
			}
		}
	}
	auto index_ppl_start = chrono::high_resolution_clock::now();


	//choose which index to construct
	LCR_index ppl_index;//
	LCR_index ppl_between;					//end of construction


											//ppl_index.construct_label_index_priority_queue(adjacency_list, adjacency_list_reverse, num_of_vertices);


	ppl_index.init_node_ranks(node_num);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	//ppl_index.construct_label_index_definedorder(adjacency_list, adjacency_list_reverse, num_of_vertices,node_in_labels,node_out_labels);
	ppl_index.construct_label_index(adjacency_list, adjacency_list_reverse, num_of_vertices);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	auto index_ppl_end = chrono::high_resolution_clock::now();
	cout << "Created index ppl" << endl;
	//cout << sizeof(int) << " size for int " << endl;
	cout << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	runtime_file << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	auto index_edp_start = chrono::high_resolution_clock::now();
	//auto index = RunAlgorithmOne(input, num_of_labels);
	auto index_edp_end = chrono::high_resolution_clock::now();
	cout << "Created index edp" << endl;



	auto diff_edp = chrono::duration_cast<chrono::milliseconds>(index_edp_end - index_edp_start);
	auto diff_ppl = chrono::duration_cast<chrono::milliseconds>(index_ppl_end - index_ppl_start);
	cout << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;

	runtime_file << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;



	cout << "----Stage 2: query processing----" << endl;

	unordered_set<LABEL_TYPE> labels;
	set<LABEL_TYPE> temp_labels;
	uint32_t cost2;
	uint32_t cost = -1;
	for (uint32_t iter = 0; iter < querset_num; ++iter)
	{
		double thop_runtime_true = 0;
		double thop_runtime_false = 0;
		string query_true = input + to_string(iter) + ".true";
		string query_false = input + to_string(iter) + ".false";
		ifstream file_true(query_true);
		ifstream file_false(query_false);
		if (!file_true.is_open())
		{
			cerr << "true query file cannot be opened!" << endl;
			return -1;
			//return index;
		}
		LABEL_TYPE label2, label;
		NODE_TYPE src, dst;// , label;
		while (file_true >> src >> dst >> label2)
		{
			set<LABEL_TYPE> label_set;
			//label = 0;
			if (dynamic_bv)
			{
				set<LABEL_TYPE> label_set1 = convert_to_label_set(label2);
				for (auto iter = label_set1.begin(); iter != label_set1.end(); iter++)
				{
					label_set.insert(label_ranks[*iter]);
				}
				label = label_set_convert_to_binary_label(label_set);
			}
			else {
				label_set = convert_to_label_set(label2);
				label = label2;

			}
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_true += diff.count() / 1e3;
			thop_runtime_true += diff2.count() / 1e3;
			twohop_total_runtime_true += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_true << "\t average time \t" << thop_runtime_true / num_of_queries << "ms" << endl;
		while (file_false >> src >> dst >> label2)
		{
			set<LABEL_TYPE> label_set;
			//label = 0;
			if (dynamic_bv)
			{
				set<LABEL_TYPE> label_set1 = convert_to_label_set(label2);
				for (auto iter = label_set1.begin(); iter != label_set1.end(); iter++)
				{
					label_set.insert(label_ranks[*iter]);
				}
				label = label_set_convert_to_binary_label(label_set);
			}
			else {
				label_set = convert_to_label_set(label2);
				label = label2;

			}
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_false += diff.count() / 1e3;
			thop_runtime_false += diff2.count() / 1e3;
			twohop_total_runtime_false += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost which is wrong" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_false << "\t average time \t" << thop_runtime_false / num_of_queries << "ms" << endl;
	}
	runtime_file << "bfs average true: false\t" << bfs_total_runtime_true / (querset_num*num_of_queries) << "\t" << bfs_total_runtime_false / (querset_num*num_of_queries) << "\t two hop average true:false\t" << twohop_total_runtime_true / (querset_num*num_of_queries) << "\t" << twohop_total_runtime_false / (querset_num*num_of_queries) << endl;
	al1.close();
	al2.close();
	runtime_file.close();


	return 0;
}




int test_edp_by_queryset(string input, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries)
{
	bool dynamic_bv = false;
	uint32_t node_num = 0;
	uint32_t edge_num = 0;
	auto found = input.rfind('/');
	string result;
	if (found != std::string::npos)
	{
		string temp(input.begin() + found + 1, input.end());
		result = temp;
	}
	else {
		result = input;
	}
	//result += "_mininal_";
	ofstream al1, al2, runtime_file;
	//al1.open(result + "_BFS_result");
	al2.open(result + "_2hop_result");
	runtime_file.open(result + "_runtime");
	runtime_file << "src" << " \t " << "dst" << "\t" << "bfs ms" << "\t" << "2hop ms" << endl;
	double bfs_total_runtime_true = 0;
	double bfs_total_runtime_false = 0;
	double twohop_total_runtime_true = 0;
	double twohop_total_runtime_false = 0;
	node_num = 0;
	load_label_graph_get_node_edge_num(input, node_num, edge_num);
	//uint32_t num_of_labels = 8;// atoi(argv[2]);
	uint32_t num_of_vertices = node_num;// 2000;// atoi(argv[3]);100000 for twitter
										//uint32_t num_of_queries = 1000;
										//uint32_t querset_num = 3;

										//uint32_t node_num = num_of_vertices;
	vector<label_edge>* adjacency_list = new vector<label_edge>[num_of_vertices + 1];
	vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[num_of_vertices + 1];


	cout << "----Stage 1: initialization----" << endl;
	//string input(argv[1]);
	//string input("youtube_subset.txt");
	//string input("Wiki-Vote.txt_randint");
	//string input("twitter_combined.txtreoder_randint");
	//string input("V10kD5L8exp.edge");
	//string input("advogato.edge");

	load_label_graph(input, num_of_vertices, adjacency_list, adjacency_list_reverse);
	//change the label to label ranks in adjacency_list
	if (dynamic_bv)
	{
		for (int i = 0; i < num_of_vertices; i++)
		{
			for (auto iter = adjacency_list[i].begin(); iter != adjacency_list[i].end(); iter++)
			{
				iter->label = label_ranks[iter->label];
			}
			for (auto iter = adjacency_list_reverse[i].begin(); iter != adjacency_list_reverse[i].end(); iter++)
			{
				iter->label = label_ranks[iter->label];
			}
		}
	}
	auto index_ppl_start = chrono::high_resolution_clock::now();


	//choose which index to construct
	LCR_index ppl_index;//
	LCR_index ppl_between;					//end of construction


											//ppl_index.construct_label_index_priority_queue(adjacency_list, adjacency_list_reverse, num_of_vertices);


	ppl_index.init_node_ranks(node_num);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	//ppl_index.construct_label_index_definedorder(adjacency_list, adjacency_list_reverse, num_of_vertices,node_in_labels,node_out_labels);
	ppl_index.construct_label_index(adjacency_list, adjacency_list_reverse, num_of_vertices);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	auto index_ppl_end = chrono::high_resolution_clock::now();
	cout << "Created index ppl" << endl;
	//cout << sizeof(int) << " size for int " << endl;
	cout << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	runtime_file << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	auto index_edp_start = chrono::high_resolution_clock::now();
	//auto index = RunAlgorithmOne(input, num_of_labels);
	auto index_edp_end = chrono::high_resolution_clock::now();
	cout << "Created index edp" << endl;



	auto diff_edp = chrono::duration_cast<chrono::milliseconds>(index_edp_end - index_edp_start);
	auto diff_ppl = chrono::duration_cast<chrono::milliseconds>(index_ppl_end - index_ppl_start);
	cout << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;

	runtime_file << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;



	cout << "----Stage 2: query processing----" << endl;

	unordered_set<LABEL_TYPE> labels;
	set<LABEL_TYPE> temp_labels;
	uint32_t cost2;
	uint32_t cost = -1;
	for (uint32_t iter = 0; iter < querset_num; ++iter)
	{
		double thop_runtime_true = 0;
		double thop_runtime_false = 0;
		string query_true = input + to_string(iter) + ".true";
		string query_false = input + to_string(iter) + ".false";
		ifstream file_true(query_true);
		ifstream file_false(query_false);
		if (!file_true.is_open())
		{
			cerr << "true query file cannot be opened!" << endl;
			return -1;
			//return index;
		}
		LABEL_TYPE label2,label;
		NODE_TYPE src, dst;// , label;
		while (file_true >> src >> dst >> label2)
		{
			set<LABEL_TYPE> label_set;
			//label = 0;
			if (dynamic_bv)
			{
				set<LABEL_TYPE> label_set1 = convert_to_label_set(label2);
				for (auto iter = label_set1.begin(); iter != label_set1.end(); iter++)
				{
					label_set.insert(label_ranks[*iter]);
				}
				label = label_set_convert_to_binary_label(label_set);
			}
			else {
				label_set = convert_to_label_set(label2);
				label = label2;

			}
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_true += diff.count() / 1e3;
			thop_runtime_true += diff2.count() / 1e3;
			twohop_total_runtime_true += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_true << "\t average time \t" << thop_runtime_true / num_of_queries << "ms" << endl;
		while (file_false >> src >> dst >> label2)
		{
			set<LABEL_TYPE> label_set;
			//label = 0;
			if (dynamic_bv)
			{
				set<LABEL_TYPE> label_set1 = convert_to_label_set(label2);
				for (auto iter = label_set1.begin(); iter != label_set1.end(); iter++)
				{
					label_set.insert(label_ranks[*iter]);
				}
				label = label_set_convert_to_binary_label(label_set);
			}
			else {
				label_set = convert_to_label_set(label2);
				label = label2;

			}
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_false += diff.count() / 1e3;
			thop_runtime_false += diff2.count() / 1e3;
			twohop_total_runtime_false += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost which is wrong" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_false << "\t average time \t" << thop_runtime_false / num_of_queries << "ms" << endl;
	}
	runtime_file << "bfs average true: false\t" << bfs_total_runtime_true / (querset_num*num_of_queries) << "\t" << bfs_total_runtime_false / (querset_num*num_of_queries) << "\t two hop average true:false\t" << twohop_total_runtime_true / (querset_num*num_of_queries) << "\t" << twohop_total_runtime_false / (querset_num*num_of_queries) << endl;
	al1.close();
	al2.close();
	runtime_file.close();


	return 0;
}

int test_edp_by_queryset_minimal_label_set(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries)
{
	auto found = input.rfind('/');
	string result;
	if (found != std::string::npos)
	{
		string temp(input.begin() + found + 1, input.end());
		result = temp;
	}
	else {
		result = input;
	}
	result += "_mininal_";
	ofstream al1, al2, runtime_file;
	//al1.open(result + "_BFS_result");
	al2.open(result + "_2hop_result");
	runtime_file.open(result + "_runtime");
	runtime_file << "src" << " \t " << "dst" << "\t" << "bfs ms" << "\t" << "2hop ms" << endl;
	double bfs_total_runtime_true = 0;
	double bfs_total_runtime_false = 0;
	double twohop_total_runtime_true = 0;
	double twohop_total_runtime_false = 0;

	//uint32_t num_of_labels = 8;// atoi(argv[2]);
	uint32_t num_of_vertices = node_num;// 2000;// atoi(argv[3]);100000 for twitter
										//uint32_t num_of_queries = 1000;
										//uint32_t querset_num = 3;

										//uint32_t node_num = num_of_vertices;
	vector<label_edge>* adjacency_list = new vector<label_edge>[num_of_vertices + 1];
	vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[num_of_vertices + 1];


	cout << "----Stage 1: initialization----" << endl;
	//string input(argv[1]);
	//string input("youtube_subset.txt");
	//string input("Wiki-Vote.txt_randint");
	//string input("twitter_combined.txtreoder_randint");
	//string input("V10kD5L8exp.edge");
	//string input("advogato.edge");

	vector<double> node_in_labels;
	vector<double> node_out_labels;
	vector<vector<label_edge>>* vec_adjacency_list = new vector<vector<label_edge>>[num_of_vertices];
	vector<vector<label_edge>>* vec_adjacency_list_reverse = new vector<vector<label_edge>>[num_of_vertices];
	WGraph_order wgraph;
	//WEIGHTED_FLAG = true;
	//DIRECTED_FLAG = true;
	//wgraph.load_graph(input);
	vector<double> label_weight;
	label_weight.resize(num_of_labels);
	load_label_graph(input, num_of_vertices, adjacency_list, adjacency_list_reverse, node_in_labels, node_out_labels, vec_adjacency_list, vec_adjacency_list_reverse, num_of_labels,label_weight);
	auto index_ppl_start = chrono::high_resolution_clock::now();


	//choose which index to construct
	LCR_index ppl_index;//
	LCR_index ppl_between;					//end of construction


											//ppl_index.construct_label_index_priority_queue(adjacency_list, adjacency_list_reverse, num_of_vertices);


	ppl_index.init_node_ranks(node_num);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	//ppl_index.construct_label_index_definedorder(adjacency_list, adjacency_list_reverse, num_of_vertices,node_in_labels,node_out_labels);
	ppl_index.construct_label_index_minimal_index(adjacency_list, adjacency_list_reverse, num_of_vertices, node_in_labels, node_out_labels, vec_adjacency_list, vec_adjacency_list_reverse, num_of_labels);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	auto index_ppl_end = chrono::high_resolution_clock::now();
	cout << "Created index ppl" << endl;
	//cout << sizeof(int) << " size for int " << endl;
	cout << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	runtime_file << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	auto index_edp_start = chrono::high_resolution_clock::now();
	//auto index = RunAlgorithmOne(input, num_of_labels);
	auto index_edp_end = chrono::high_resolution_clock::now();
	cout << "Created index edp" << endl;



	auto diff_edp = chrono::duration_cast<chrono::milliseconds>(index_edp_end - index_edp_start);
	auto diff_ppl = chrono::duration_cast<chrono::milliseconds>(index_ppl_end - index_ppl_start);
	cout << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;

	runtime_file << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;



	cout << "----Stage 2: query processing----" << endl;

	unordered_set<LABEL_TYPE> labels;
	set<LABEL_TYPE> temp_labels;
	uint32_t cost2;
	uint32_t cost = -1;
	for (uint32_t iter = 0; iter < querset_num; ++iter)
	{
		double thop_runtime_true = 0;
		double thop_runtime_false = 0;
		string query_true = input + to_string(iter) + ".true";
		string query_false = input + to_string(iter) + ".false";
		ifstream file_true(query_true);
		ifstream file_false(query_false);
		if (!file_true.is_open())
		{
			cerr << "true query file cannot be opened!" << endl;
			return -1;
			//return index;
		}
		LABEL_TYPE label;
		NODE_TYPE src, dst;// , label;
		while (file_true >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_true += diff.count() / 1e3;
			thop_runtime_true += diff2.count() / 1e3;
			twohop_total_runtime_true += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_true << "\t average time \t" << thop_runtime_true/num_of_queries << "ms" << endl;
		while (file_false >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_false += diff.count() / 1e3;
			thop_runtime_false += diff2.count() / 1e3;
			twohop_total_runtime_false += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost which is wrong" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_false << "\t average time \t" << thop_runtime_false / num_of_queries << "ms" << endl;
	}
	runtime_file << "bfs average true: false\t" << bfs_total_runtime_true / (querset_num*num_of_queries) << "\t" << bfs_total_runtime_false / (querset_num*num_of_queries) << "\t two hop average true:false\t" << twohop_total_runtime_true / (querset_num*num_of_queries) << "\t" << twohop_total_runtime_false / (querset_num*num_of_queries) << endl;
	al1.close();
	al2.close();
	runtime_file.close();


	return 0;
}



int test_edp_by_queryset_minimal_label_set_weight_label(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries)
{
	auto found = input.rfind('/');
	string result;
	if (found != std::string::npos)
	{
		string temp(input.begin() + found + 1, input.end());
		result = temp;
	}
	else {
		result = input;
	}
	result += "_mininal_weight_label_";
	ofstream al1, al2, runtime_file;
	//al1.open(result + "_BFS_result");
	al2.open(result + "_2hop_result");
	runtime_file.open(result + "_runtime");
	runtime_file << "src" << " \t " << "dst" << "\t" << "bfs ms" << "\t" << "2hop ms" << endl;
	double bfs_total_runtime_true = 0;
	double bfs_total_runtime_false = 0;
	double twohop_total_runtime_true = 0;
	double twohop_total_runtime_false = 0;

	//uint32_t num_of_labels = 8;// atoi(argv[2]);
	uint32_t num_of_vertices = node_num;// 2000;// atoi(argv[3]);100000 for twitter
										//uint32_t num_of_queries = 1000;
										//uint32_t querset_num = 3;

										//uint32_t node_num = num_of_vertices;
	vector<label_edge>* adjacency_list = new vector<label_edge>[num_of_vertices + 1];
	vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[num_of_vertices + 1];


	cout << "----Stage 1: initialization----" << endl;
	//string input(argv[1]);
	//string input("youtube_subset.txt");
	//string input("Wiki-Vote.txt_randint");
	//string input("twitter_combined.txtreoder_randint");
	//string input("V10kD5L8exp.edge");
	//string input("advogato.edge");

	vector<double> node_in_labels;
	vector<double> node_out_labels;
	vector<vector<label_edge>>* vec_adjacency_list = new vector<vector<label_edge>>[num_of_vertices];
	vector<vector<label_edge>>* vec_adjacency_list_reverse = new vector<vector<label_edge>>[num_of_vertices];
	WGraph_order wgraph;
	//WEIGHTED_FLAG = true;
	//DIRECTED_FLAG = true;
	//wgraph.load_graph(input);
	vector<double> label_weight;
	label_weight.resize(num_of_labels);
	load_label_graph(input, num_of_vertices, adjacency_list, adjacency_list_reverse, node_in_labels, node_out_labels, vec_adjacency_list, vec_adjacency_list_reverse, num_of_labels, label_weight);
	auto index_ppl_start = chrono::high_resolution_clock::now();


	//choose which index to construct
	LCR_index ppl_index;//
	LCR_index ppl_between;					//end of construction


											//ppl_index.construct_label_index_priority_queue(adjacency_list, adjacency_list_reverse, num_of_vertices);


	ppl_index.init_node_ranks(node_num);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	//ppl_index.construct_label_index_definedorder(adjacency_list, adjacency_list_reverse, num_of_vertices,node_in_labels,node_out_labels);
	ppl_index.construct_label_index_minimal_index_weighted_label(adjacency_list, adjacency_list_reverse, num_of_vertices, node_in_labels, node_out_labels, vec_adjacency_list, vec_adjacency_list_reverse, num_of_labels,label_weight);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	auto index_ppl_end = chrono::high_resolution_clock::now();
	cout << "Created index ppl" << endl;
	//cout << sizeof(int) << " size for int " << endl;
	cout << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	runtime_file << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	auto index_edp_start = chrono::high_resolution_clock::now();
	//auto index = RunAlgorithmOne(input, num_of_labels);
	auto index_edp_end = chrono::high_resolution_clock::now();
	cout << "Created index edp" << endl;



	auto diff_edp = chrono::duration_cast<chrono::milliseconds>(index_edp_end - index_edp_start);
	auto diff_ppl = chrono::duration_cast<chrono::milliseconds>(index_ppl_end - index_ppl_start);
	cout << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;

	runtime_file << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;



	cout << "----Stage 2: query processing----" << endl;

	unordered_set<LABEL_TYPE> labels;
	set<LABEL_TYPE> temp_labels;
	uint32_t cost2;
	uint32_t cost = -1;
	for (uint32_t iter = 0; iter < querset_num; ++iter)
	{
		double thop_runtime_true = 0;
		double thop_runtime_false = 0;
		string query_true = input + to_string(iter) + ".true";
		string query_false = input + to_string(iter) + ".false";
		ifstream file_true(query_true);
		ifstream file_false(query_false);
		if (!file_true.is_open())
		{
			cerr << "true query file cannot be opened!" << endl;
			return -1;
			//return index;
		}
		LABEL_TYPE label;
		NODE_TYPE src, dst;// , label;
		while (file_true >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_true += diff.count() / 1e3;
			thop_runtime_true += diff2.count() / 1e3;
			twohop_total_runtime_true += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_true << "\t average time \t" << thop_runtime_true / num_of_queries << "ms" << endl;
		while (file_false >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_false += diff.count() / 1e3;
			thop_runtime_false += diff2.count() / 1e3;
			twohop_total_runtime_false += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost which is wrong" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_false << "\t average time \t" << thop_runtime_false / num_of_queries << "ms" << endl;
	}
	runtime_file << "bfs average true: false\t" << bfs_total_runtime_true / (querset_num*num_of_queries) << "\t" << bfs_total_runtime_false / (querset_num*num_of_queries) << "\t two hop average true:false\t" << twohop_total_runtime_true / (querset_num*num_of_queries) << "\t" << twohop_total_runtime_false / (querset_num*num_of_queries) << endl;
	al1.close();
	al2.close();
	runtime_file.close();


	return 0;
}

int test_edp_by_queryset_minimal_label_set_advanced_node_order(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries)
{
	auto found = input.rfind('/');
	string result;
	if (found != std::string::npos)
	{
		string temp(input.begin() + found + 1, input.end());
		result = temp;
	}
	else {
		result = input;
	}
	result += "_mininal_advanced_order_";
	ofstream al1, al2, runtime_file;
	//al1.open(result + "_BFS_result");
	al2.open(result + "_2hop_result");
	runtime_file.open(result + "_runtime");
	runtime_file << "src" << " \t " << "dst" << "\t" << "bfs ms" << "\t" << "2hop ms" << endl;
	double bfs_total_runtime_true = 0;
	double bfs_total_runtime_false = 0;
	double twohop_total_runtime_true = 0;
	double twohop_total_runtime_false = 0;

	//uint32_t num_of_labels = 8;// atoi(argv[2]);
	uint32_t num_of_vertices = node_num;// 2000;// atoi(argv[3]);100000 for twitter
										//uint32_t num_of_queries = 1000;
										//uint32_t querset_num = 3;

										//uint32_t node_num = num_of_vertices;
	vector<label_edge>* adjacency_list = new vector<label_edge>[num_of_vertices + 1];
	vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[num_of_vertices + 1];


	cout << "----Stage 1: initialization----" << endl;
	//string input(argv[1]);
	//string input("youtube_subset.txt");
	//string input("Wiki-Vote.txt_randint");
	//string input("twitter_combined.txtreoder_randint");
	//string input("V10kD5L8exp.edge");
	//string input("advogato.edge");

	vector<double> node_in_labels;
	vector<double> node_out_labels;
	vector<vector<label_edge>>* vec_adjacency_list = new vector<vector<label_edge>>[num_of_vertices];
	vector<vector<label_edge>>* vec_adjacency_list_reverse = new vector<vector<label_edge>>[num_of_vertices];
	Graph_order graph;
	//WEIGHTED_FLAG = true;
//	DIRECTED_FLAG = true;
	char* p = (char*)input.data();
	graph.load_graph(p);
	vector<double> label_weight;
	load_label_graph(input, num_of_vertices, adjacency_list, adjacency_list_reverse, node_in_labels, node_out_labels, vec_adjacency_list, vec_adjacency_list_reverse, num_of_labels,label_weight);
	auto index_ppl_start = chrono::high_resolution_clock::now();


	//choose which index to construct
	LCR_index ppl_index;//
	LCR_index ppl_between;					//end of construction


											//ppl_index.construct_label_index_priority_queue(adjacency_list, adjacency_list_reverse, num_of_vertices);


	ppl_index.init_node_ranks(node_num);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	//ppl_index.construct_label_index_definedorder(adjacency_list, adjacency_list_reverse, num_of_vertices,node_in_labels,node_out_labels);
	ppl_index.construct_label_index_minimal_index_advanced_node_order(adjacency_list, adjacency_list_reverse, num_of_vertices, node_in_labels, node_out_labels, vec_adjacency_list, vec_adjacency_list_reverse, num_of_labels,graph);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	auto index_ppl_end = chrono::high_resolution_clock::now();
	cout << "Created index ppl" << endl;
	//cout << sizeof(int) << " size for int " << endl;
	cout << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	runtime_file << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	auto index_edp_start = chrono::high_resolution_clock::now();
	//auto index = RunAlgorithmOne(input, num_of_labels);
	auto index_edp_end = chrono::high_resolution_clock::now();
	cout << "Created index edp" << endl;



	auto diff_edp = chrono::duration_cast<chrono::milliseconds>(index_edp_end - index_edp_start);
	auto diff_ppl = chrono::duration_cast<chrono::milliseconds>(index_ppl_end - index_ppl_start);
	cout << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;

	runtime_file << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;



	cout << "----Stage 2: query processing----" << endl;

	unordered_set<LABEL_TYPE> labels;
	set<LABEL_TYPE> temp_labels;
	uint32_t cost2;
	uint32_t cost = -1;
	for (uint32_t iter = 0; iter < querset_num; ++iter)
	{
		double thop_runtime_true = 0;
		double thop_runtime_false = 0;
		string query_true = input + to_string(iter) + ".true";
		string query_false = input + to_string(iter) + ".false";
		ifstream file_true(query_true);
		ifstream file_false(query_false);
		if (!file_true.is_open())
		{
			cerr << "true query file cannot be opened!" << endl;
			return -1;
			//return index;
		}
		LABEL_TYPE label;
		NODE_TYPE src, dst;// , label;
		while (file_true >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_true += diff.count() / 1e3;
			thop_runtime_true += diff2.count() / 1e3;
			twohop_total_runtime_true += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_true << "\t average time \t" << thop_runtime_true / num_of_queries << "ms" << endl;
		while (file_false >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_false += diff.count() / 1e3;
			thop_runtime_false += diff2.count() / 1e3;
			twohop_total_runtime_false += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost which is wrong" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_false << "\t average time \t" << thop_runtime_false / num_of_queries << "ms" << endl;
	}
	runtime_file << "bfs average true: false\t" << bfs_total_runtime_true / (querset_num*num_of_queries) << "\t" << bfs_total_runtime_false / (querset_num*num_of_queries) << "\t two hop average true:false\t" << twohop_total_runtime_true / (querset_num*num_of_queries) << "\t" << twohop_total_runtime_false / (querset_num*num_of_queries) << endl;
	al1.close();
	al2.close();
	runtime_file.close();


	return 0;
}

int compare_node_order(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries)
{
	auto found = input.rfind('/');
	string result;
	if (found != std::string::npos)
	{
		string temp(input.begin() + found + 1, input.end());
		result = temp;
	}
	else {
		result = input;
	}
	ofstream index_file;
	index_file.open(result + "_index_size_time");
	

	uint32_t num_of_vertices = node_num;// 2000;// atoi(argv[3]);100000 for twitter
	vector<label_edge>* adjacency_list = new vector<label_edge>[num_of_vertices + 1];
	vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[num_of_vertices + 1];


	cout << "----Stage 1: initialization----" << endl;
	//string input(argv[1]);
	//string input("youtube_subset.txt");
	//string input("Wiki-Vote.txt_randint");
	//string input("twitter_combined.txtreoder_randint");
	//string input("V10kD5L8exp.edge");
	//string input("advogato.edge");
	load_label_graph(input, num_of_vertices, adjacency_list, adjacency_list_reverse);
	auto index_ppl_start = chrono::high_resolution_clock::now();



	//choose which index to construct
	LCR_index ppl_index;//
						//end of construction

	ppl_index.construct_label_index(adjacency_list, adjacency_list_reverse, num_of_vertices);
	auto index_ppl_end = chrono::high_resolution_clock::now();
	cout << "Created index ppl" << endl;

	auto index_edp_start = chrono::high_resolution_clock::now();
	//auto index = RunAlgorithmOne(input, num_of_labels);
	auto index_edp_end = chrono::high_resolution_clock::now();
	cout << "Created index edp" << endl;



	auto diff_edp = chrono::duration_cast<chrono::milliseconds>(index_edp_end - index_edp_start);
	auto diff_ppl = chrono::duration_cast<chrono::milliseconds>(index_ppl_end - index_ppl_start);
	cout << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;

	index_file <<" ppl index:\t" << diff_ppl.count() << "\t index size:\t" << ppl_index.getIndexSizeInBytesM(node_num,adjacency_list) << endl;


	
	index_file.close();
	//system("pause");
	return 0;
}


int test_edp_by_queryset_minimal_label_set_significant_path(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries)
{
	auto found = input.rfind('/');
	string result;
	if (found != std::string::npos)
	{
		string temp(input.begin() + found + 1, input.end());
		result = temp;
	}
	else {
		result = input;
	}
	result += "_mininal_significant_path_regardsame_";
	ofstream al1, al2, runtime_file;
	//al1.open(result + "_BFS_result");
	al2.open(result + "_2hop_result");
	runtime_file.open(result + "_runtime");
	runtime_file << "src" << " \t " << "dst" << "\t" << "bfs ms" << "\t" << "2hop ms" << endl;
	double bfs_total_runtime_true = 0;
	double bfs_total_runtime_false = 0;
	double twohop_total_runtime_true = 0;
	double twohop_total_runtime_false = 0;

	//uint32_t num_of_labels = 8;// atoi(argv[2]);
	uint32_t num_of_vertices = node_num;// 2000;// atoi(argv[3]);100000 for twitter
										//uint32_t num_of_queries = 1000;
										//uint32_t querset_num = 3;

										//uint32_t node_num = num_of_vertices;
	vector<label_edge>* adjacency_list = new vector<label_edge>[num_of_vertices + 1];
	vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[num_of_vertices + 1];


	cout << "----Stage 1: initialization----" << endl;
	//string input(argv[1]);
	//string input("youtube_subset.txt");
	//string input("Wiki-Vote.txt_randint");
	//string input("twitter_combined.txtreoder_randint");
	//string input("V10kD5L8exp.edge");
	//string input("advogato.edge");

	vector<double> node_in_labels;
	vector<double> node_out_labels;
	vector<vector<label_edge>>* vec_adjacency_list = new vector<vector<label_edge>>[num_of_vertices];
	vector<vector<label_edge>>* vec_adjacency_list_reverse = new vector<vector<label_edge>>[num_of_vertices];
	WGraph_order wgraph;
	//WEIGHTED_FLAG = true;
	//DIRECTED_FLAG = true;
	//wgraph.load_graph(input);
	vector<double> label_weight;
	label_weight.resize(num_of_labels);
	load_label_graph(input, num_of_vertices, adjacency_list, adjacency_list_reverse, node_in_labels, node_out_labels, vec_adjacency_list, vec_adjacency_list_reverse, num_of_labels, label_weight);
	auto index_ppl_start = chrono::high_resolution_clock::now();


	//choose which index to construct
	LCR_index ppl_index;//
	LCR_index ppl_between;					//end of construction


											//ppl_index.construct_label_index_priority_queue(adjacency_list, adjacency_list_reverse, num_of_vertices);


	ppl_index.init_node_ranks(node_num);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	//ppl_index.construct_label_index_definedorder(adjacency_list, adjacency_list_reverse, num_of_vertices,node_in_labels,node_out_labels);
	ppl_index.construct_label_index_minimal_index_significant_path_order(adjacency_list, adjacency_list_reverse, num_of_vertices, node_in_labels, node_out_labels, vec_adjacency_list, vec_adjacency_list_reverse, num_of_labels,wgraph);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	auto index_ppl_end = chrono::high_resolution_clock::now();
	cout << "Created index ppl" << endl;
	//cout << sizeof(int) << " size for int " << endl;
	cout << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	runtime_file << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	auto index_edp_start = chrono::high_resolution_clock::now();
	//auto index = RunAlgorithmOne(input, num_of_labels);
	auto index_edp_end = chrono::high_resolution_clock::now();
	cout << "Created index edp" << endl;



	auto diff_edp = chrono::duration_cast<chrono::milliseconds>(index_edp_end - index_edp_start);
	auto diff_ppl = chrono::duration_cast<chrono::milliseconds>(index_ppl_end - index_ppl_start);
	cout << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;

	runtime_file << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;



	cout << "----Stage 2: query processing----" << endl;

	unordered_set<LABEL_TYPE> labels;
	set<LABEL_TYPE> temp_labels;
	uint32_t cost2;
	uint32_t cost = -1;
	for (uint32_t iter = 0; iter < querset_num; ++iter)
	{
		double thop_runtime_true = 0;
		double thop_runtime_false = 0;
		string query_true = input + to_string(iter) + ".true";
		string query_false = input + to_string(iter) + ".false";
		ifstream file_true(query_true);
		ifstream file_false(query_false);
		if (!file_true.is_open())
		{
			cerr << "true query file cannot be opened!" << endl;
			return -1;
			//return index;
		}
		LABEL_TYPE label;
		NODE_TYPE src, dst;// , label;
		while (file_true >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_true += diff.count() / 1e3;
			thop_runtime_true += diff2.count() / 1e3;
			twohop_total_runtime_true += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_true << "\t average time \t" << thop_runtime_true / num_of_queries << "ms" << endl;
		while (file_false >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.find_distance_ppl(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2) / 5.0;
			bfs_total_runtime_false += diff.count() / 1e3;
			thop_runtime_false += diff2.count() / 1e3;
			twohop_total_runtime_false += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost which is wrong" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_false << "\t average time \t" << thop_runtime_false / num_of_queries << "ms" << endl;
	}
	runtime_file << "bfs average true: false\t" << bfs_total_runtime_true / (querset_num*num_of_queries) << "\t" << bfs_total_runtime_false / (querset_num*num_of_queries) << "\t two hop average true:false\t" << twohop_total_runtime_true / (querset_num*num_of_queries) << "\t" << twohop_total_runtime_false / (querset_num*num_of_queries) << endl;
	al1.close();
	al2.close();
	runtime_file.close();


	return 0;
}



int test_naive_2hop_labeling(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries)
{
	auto found = input.rfind('/');
	string result;
	if (found != std::string::npos)
	{
		string temp(input.begin() + found + 1, input.end());
		result = temp;
	}
	else {
		result = input;
	}
	result += "_mininal_naive_2hop_";
	ofstream al1, al2, runtime_file;
	//al1.open(result + "_BFS_result");
	al2.open(result + "_2hop_result");
	runtime_file.open(result + "_runtime");
	runtime_file << "src" << " \t " << "dst" << "\t" << "bfs ms" << "\t" << "2hop ms" << endl;
	double bfs_total_runtime_true = 0;
	double bfs_total_runtime_false = 0;
	double twohop_total_runtime_true = 0;
	double twohop_total_runtime_false = 0;

	//uint32_t num_of_labels = 8;// atoi(argv[2]);
	uint32_t num_of_vertices = node_num;// 2000;// atoi(argv[3]);100000 for twitter
										//uint32_t num_of_queries = 1000;
										//uint32_t querset_num = 3;

										//uint32_t node_num = num_of_vertices;
	vector<label_edge>* adjacency_list = new vector<label_edge>[num_of_vertices + 1];
	vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[num_of_vertices + 1];


	cout << "----Stage 1: initialization----" << endl;
	//string input(argv[1]);
	//string input("youtube_subset.txt");
	//string input("Wiki-Vote.txt_randint");
	//string input("twitter_combined.txtreoder_randint");
	//string input("V10kD5L8exp.edge");
	//string input("advogato.edge");

	vector<double> node_in_labels;
	vector<double> node_out_labels;
	vector<vector<label_edge>>* vec_adjacency_list = new vector<vector<label_edge>>[num_of_vertices];
	vector<vector<label_edge>>* vec_adjacency_list_reverse = new vector<vector<label_edge>>[num_of_vertices];
	WGraph_order wgraph;
	//WEIGHTED_FLAG = true;
	//DIRECTED_FLAG = true;
	//wgraph.load_graph(input);
	vector<double> label_weight;
	label_weight.resize(num_of_labels);
	load_label_graph(input, num_of_vertices, adjacency_list, adjacency_list_reverse, node_in_labels, node_out_labels, vec_adjacency_list, vec_adjacency_list_reverse, num_of_labels, label_weight);
	auto index_ppl_start = chrono::high_resolution_clock::now();


	//choose which index to construct
	LCR_index ppl_index;//
	LCR_index ppl_between;					//end of construction


											//ppl_index.construct_label_index_priority_queue(adjacency_list, adjacency_list_reverse, num_of_vertices);


	ppl_index.init_node_ranks(node_num);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	//ppl_index.construct_label_index_definedorder(adjacency_list, adjacency_list_reverse, num_of_vertices,node_in_labels,node_out_labels);
	ppl_index.construct_naive_2hop_labeling_one_label(num_of_vertices, node_in_labels, node_out_labels, vec_adjacency_list, vec_adjacency_list_reverse, num_of_labels);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);

	auto index_ppl_end = chrono::high_resolution_clock::now();
	cout << "Created index ppl" << endl;
	//cout << sizeof(int) << " size for int " << endl;
	cout << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	runtime_file << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	auto index_edp_start = chrono::high_resolution_clock::now();
	//auto index = RunAlgorithmOne(input, num_of_labels);
	auto index_edp_end = chrono::high_resolution_clock::now();
	cout << "Created index edp" << endl;



	auto diff_edp = chrono::duration_cast<chrono::milliseconds>(index_edp_end - index_edp_start);
	auto diff_ppl = chrono::duration_cast<chrono::milliseconds>(index_ppl_end - index_ppl_start);
	cout << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;

	runtime_file << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;



	cout << "----Stage 2: query processing----" << endl;

	unordered_set<LABEL_TYPE> labels;
	set<LABEL_TYPE> temp_labels;
	uint32_t cost2;
	uint32_t cost = -1;
	for (uint32_t iter = 0; iter < querset_num; ++iter)
	{
		double thop_runtime_true = 0;
		double thop_runtime_false = 0;
		string query_true = input + to_string(iter) + ".true";
		string query_false = input + to_string(iter) + ".false";
		ifstream file_true(query_true);
		ifstream file_false(query_false);
		if (!file_true.is_open())
		{
			cerr << "true query file cannot be opened!" << endl;
			return -1;
			//return index;
		}
		LABEL_TYPE label;
		NODE_TYPE src, dst;// , label;
		while (file_true >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			//for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.answer_LCR_naive_2hop(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2);// / 5.0;
			bfs_total_runtime_true += diff.count() / 1e3;
			thop_runtime_true += diff2.count() / 1e3;
			twohop_total_runtime_true += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost which is wrong" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_true << "\t average time \t" << thop_runtime_true / num_of_queries << "ms" << endl;
		while (file_false >> src >> dst >> label)
		{
			set<LABEL_TYPE> label_set = convert_to_label_set(label);
			cout << "src: " << src << ", dst: " << dst << endl;

			auto t1 = chrono::high_resolution_clock::now();
			//cost = test_dfs_with_label(src, dst, label_set, node_num, input, adjacency_list, adjacency_list_reverse);
			//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
			temp_labels.clear();
			auto t2 = chrono::high_resolution_clock::now();
			//for (int k = 0; k < 5; k++)
			{
				cost2 = ppl_index.answer_LCR_naive_2hop(src, dst, label);
			}
			//uint32_t cost2 = 0;
			//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
			auto t3 = chrono::high_resolution_clock::now();

			if (cost == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//cout << l << " ";
				//cout << endl;
			}

			if (cost2 == INF)
				cout << "Cannot find a route" << endl;
			else
			{
				cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
				//for (auto&& l : labels)
				//	cout << l << " ";
				//cout << endl;
			}

			auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
			auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2);// / 5.0;
			bfs_total_runtime_false += diff.count() / 1e3;
			thop_runtime_false += diff2.count() / 1e3;
			twohop_total_runtime_false += diff2.count() / 1e3;
			//runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
			if (cost != INF)
			{
				al1 << src << "\t" << dst << "\t" << cost << "\t cost which is wrong" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << cost << "\t cost \t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;
			}
			else
			{
				al1 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

				//al1 << src << "\t" << dst << "\t";
				//al1 << "INF" << "\t cost\t";
				//for (auto&& l : labels)
				//	al1 << l << ",";
				//al1 << endl;

			}
			if (cost2 != INF)
			{
				al2 << src << "\t" << dst << "\t" << cost2 << "\t cost which is wrong" << endl;
			}
			else
			{
				al2 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

			}

			cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
			cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

			cout << "========================================" << endl;
		}
		runtime_file << query_false << "\t average time \t" << thop_runtime_false / num_of_queries << "ms" << endl;
	}
	runtime_file << "bfs average true: false\t" << bfs_total_runtime_true / (querset_num*num_of_queries) << "\t" << bfs_total_runtime_false / (querset_num*num_of_queries) << "\t two hop average true:false\t" << twohop_total_runtime_true / (querset_num*num_of_queries) << "\t" << twohop_total_runtime_false / (querset_num*num_of_queries) << endl;
	al1.close();
	al2.close();
	runtime_file.close();


	return 0;
}


int test_edp()
{
	ofstream al1, al2, runtime_file,edge_insertion,error;
	al1.open("EDP_result");
	al2.open("ours_result");
	error.open("different");
	runtime_file.open("runtime");
	edge_insertion.open("edge_insertion_time");
	runtime_file << "src" << " \t " << "dst" << "\t" << "edp ms" << "\t" << "ours ms" << endl;

	//if (argc != 4)
	//{
	//	cout << "Usage: ./edp /path/to/graph num_of_labels num_of_vertices" << endl;
	//	exit(-1);
	//}
	uint32_t num_of_labels = 8;// atoi(argv[2]);
	uint32_t num_of_vertices = 384414;// 2000;// atoi(argv[3]);100000 for twitter
	uint32_t num_of_queries = 100000;

	uint32_t node_num = num_of_vertices;
	vector<label_edge>* adjacency_list = new vector<label_edge>[num_of_vertices + 1];
	vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[num_of_vertices + 1];


	cout << "----Stage 1: initialization----" << endl;
	//string input(argv[1]);
	string input("citeseerL8exp.edge");
	//string input("youtube_subset.txt");
	//string input("Wiki-Vote.txt_randint");
	//string input("twitter_combined.txtreoder_randint");
	//string input("V10kD5L8exp.edge");
	//string input("twitterL8exp.edge");

	vector<double> node_in_labels;
	vector<double> node_out_labels;
	vector<vector<label_edge>>* vec_adjacency_list = new vector<vector<label_edge>>[num_of_vertices];
	vector<vector<label_edge>>* vec_adjacency_list_reverse = new vector<vector<label_edge>>[num_of_vertices];
	vector<double> label_weight;
	load_label_graph(input, num_of_vertices, adjacency_list, adjacency_list_reverse, node_in_labels,node_out_labels,vec_adjacency_list,vec_adjacency_list_reverse,num_of_labels,label_weight);
	auto index_ppl_start = chrono::high_resolution_clock::now();

	//vector<label_edge>* adjacency_list = new vector<label_edge>[node_num + 1];
	//vector<label_edge>* adjacency_list_reverse = new vector<label_edge>[node_num + 1];
	//load_label_graph(input, node_num, adjacency_list, adjacency_list_reverse);


	//choose which index to construct
	LCR_index ppl_index;//
						//end of construction
	ppl_index.init_node_ranks(node_num);
	//ppl_index.construct_label_index_by_betweeness(adjacency_list, adjacency_list_reverse, num_of_vertices);
	
	//ppl_index.construct_label_index_definedorder(adjacency_list, adjacency_list_reverse, num_of_vertices,node_in_labels,node_out_labels);
	ppl_index.construct_label_index_minimal_index(adjacency_list, adjacency_list_reverse, num_of_vertices, node_in_labels, node_out_labels,vec_adjacency_list,vec_adjacency_list_reverse,num_of_labels);

	//ppl_index.construct_Iin_Iout();
	//ppl_index.init_node_ranks(node_num);
	auto index_ppl_end = chrono::high_resolution_clock::now();
	cout << "Created index ppl" << endl;

	auto index_edp_start = chrono::high_resolution_clock::now();
	//auto index = RunAlgorithmOne(input, num_of_labels);
	auto index_edp_end = chrono::high_resolution_clock::now();
	cout << "Created index edp" << endl;



	auto diff_edp = chrono::duration_cast<chrono::milliseconds>(index_edp_end - index_edp_start);
	auto diff_ppl = chrono::duration_cast<chrono::milliseconds>(index_ppl_end - index_ppl_start);
	cout << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;

	runtime_file << "edp index:\t" << diff_edp.count() << "\t: ppl index:\t" << diff_ppl.count() << endl;
	cout << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;
	runtime_file << ppl_index.getIndexSizeInBytesM(node_num, adjacency_list) / 1000000.0 << " MB " << endl;


	cout << "----Stage 2: query processing----" << endl;
	RandomGenerator rng;
	rng.seed(random_device()());
	uniform_int_distribution<uint32_t> label_dist(0, num_of_labels);
	uniform_int_distribution<uint32_t> vertex_dist(0, num_of_vertices/10);

	set<LABEL_TYPE> labels;
	set<LABEL_TYPE> temp_labels;

	for (uint32_t iter = 1; iter <= num_of_queries; ++iter)
	{
		// generate query labels
		labels.clear();
		//unordered_set<uint32_t> labels_32;

		while (labels.size() < num_of_labels / 2)
		{
			labels.insert(label_dist(rng));
			//labels_32.insert(label_dist(rng));

		}
		//#ifndef NDEBUG
		for (LABEL_TYPE label : labels)
			cout << "label: " << label << endl;
		//#endif

		// run query
		cout << "query num: " << iter << endl;
		/*uint32_t src;
		do {
		src = vertex_dist(rng);
		} while (index.GetMinPr(src, labels) == INF);*/
		uint32_t src = vertex_dist(rng);
		uint32_t dst = vertex_dist(rng);

		//test 58,73,(3,5)  1
		//src = 74;
		//dst = 100;
		//labels.clear();
		//labels.insert(0);
		//labels.insert(4);

		//test 58,73,(3,5)  1
		/*src = 1;
		dst = 6;
		labels.clear();
		labels.insert(1);
		labels.insert(2);
		*/
		cout << "src: " << src << ", dst: " << dst << endl;

		auto t1 = chrono::high_resolution_clock::now();
		uint32_t cost = test_dfs_with_label(src, dst, labels, node_num, input, adjacency_list, adjacency_list_reverse);
		//uint32_t cost = RunAlgorithmTwo(index, src, dst, labels);
		temp_labels.clear();
		//set<uint32_t> temp_labels_32;
		LABEL_TYPE binary_label = 0;
		for (auto label : labels)
		{
			temp_labels.insert(label);
			binary_label += convert_to_binary_label(label);
			//temp_labels_32.insert(label);
		}
		auto t2 = chrono::high_resolution_clock::now();
		uint32_t cost2;
		for (int k = 0; k < 5; k++)//over 5 runs
		{
			cost2 = ppl_index.find_distance_ppl(src, dst, binary_label);
		}
		//uint32_t cost2 = 0;
		//uint32_t cost2 = test_dfs_with_label(src, dst, labels);
		auto t3 = chrono::high_resolution_clock::now();
		LABEL_TYPE temp_insert;
		for (int w = 0; w < 0; w++)
		{
			NODE_TYPE temp_src = vertex_dist(rng);
			NODE_TYPE temp_dst = vertex_dist(rng);
			temp_insert = label_dist(rng);
			ppl_index.add_edges_update_index(temp_src, temp_dst, temp_insert, adjacency_list, adjacency_list_reverse, node_num);
		}
		cout << "end of update" << endl;
		/*ppl_index.add_edges_update_index(1, 5, 1, adjacency_list, adjacency_list_reverse, node_num);
		ppl_index.add_edges_update_index(5, 2, 2, adjacency_list, adjacency_list_reverse, node_num);
		ppl_index.add_edges_update_index(3, 6, 1, adjacency_list, adjacency_list_reverse, node_num);
		ppl_index.add_edges_update_index(4, 3, 2, adjacency_list, adjacency_list_reverse, node_num);
		ppl_index.add_edges_update_index(2, 4, 1, adjacency_list, adjacency_list_reverse, node_num);*/
		
		
		auto t4 = chrono::high_resolution_clock::now();
		auto edge_insertion_time = chrono::duration_cast<chrono::milliseconds>(t4 - t3);
		edge_insertion << src << "\t" << dst << "\t" << temp_insert << "\t" << edge_insertion_time.count() << "ms" << endl;
		cout << "insertion time for " << src << "\t" << dst << "\t" << temp_insert << "\t" << edge_insertion_time.count() << "ms" << endl;


		if (cost == INF)
			cout << "Cannot find a route" << endl;
		else
		{
			cout << "al1 Finished, cost is " << cost << " from " << src << " to " << dst << " with labels ";
			//for (auto&& l : labels)
			//cout << l << " ";
			//cout << endl;
		}

		if (cost2 == INF)
			cout << "Cannot find a route" << endl;
		else
		{
			cout << "al2 Finished, cost is " << cost2 << " from " << src << " to " << dst << " with labels ";
			//for (auto&& l : labels)
			//	cout << l << " ";
			//cout << endl;
		}



		uint32_t total_entries = 0;
		/*for (uint32_t l = 0; l < num_of_labels; ++l)
		total_entries += index.GetPartition(l).GetCostSize();*/
		cout << "Now there are " << total_entries << " entries in index" << endl;
		cout << iter << " " << total_entries << endl;

		auto diff = chrono::duration_cast<chrono::microseconds>(t2 - t1);
		auto diff2 = chrono::duration_cast<chrono::microseconds>(t3 - t2)/5.0;
		runtime_file << src << " \t " << dst << "\t" << diff.count() / 1e3 << "\tms for dfs\t" << diff2.count() / 1e3 << "\tms for 2hop" << endl;
		if (cost != cost2)
		{
			error << src << "\t" << dst << "\t";
			for (auto&& l : labels)
				error << l << ",";
			error << endl;
			error << "al1\t" << cost << "\tal2\t" << cost2 << endl;
		}
		if (cost != INF)
		{
			al1 << src << "\t" << dst << "\t" << cost << "\t cost" << endl;

			//al1 << src << "\t" << dst << "\t";
			//al1  << cost << "\t cost \t";
			//for (auto&& l : labels)
			//	al1 << l << ",";
			//al1 << endl;
		}
		else
		{
			al1 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

			//al1 << src << "\t" << dst << "\t";
			//al1 << "INF" << "\t cost\t";
			//for (auto&& l : labels)
			//	al1 << l << ",";
			//al1 << endl;

		}
		if (cost2 != INF)
		{
			al2 << src << "\t" << dst << "\t" << cost2 << "\t cost" << endl;
		}
		else
		{
			al2 << src << "\t" << dst << "\t" << "INF" << "\t cost" << endl;

		}

		cout << "Time taken to run the query: " << diff.count() / 1e3 << "ms" << endl;
		cout << "Time taken by pure Dijkstra algorithm to run the query: " << diff2.count() / 1e3 << "ms" << endl;

		cout << "========================================" << endl;
	}
	al1.close();
	al2.close();
	error.close();
	runtime_file.close();
	edge_insertion.close();
	//system("pause");
	return 0;
}