import os
import random
filename = "youtube_subset.txt"
maxX = 150
maxY = 150
file = open(filename,"r")
lines = file.readlines()
i = 0
print "start new one"
file.close()
file = open(filename,"r")
filew = open(filename+"_small","w")
lines = file.readlines()
wt =""
for line in lines:
    line = line.strip("\n")
    nodes = line.split(" ")
    x = int(nodes[0])
    y = int(nodes[1])
    weight = nodes[2]
    label = nodes[3]
    if x > maxX or y > maxY:
        continue
    filew.write(str(x) + " " + str(y) + " " + str(weight) + " "+ str(label)+ "\n")
filew.close()
file.close()
#os.system('pause')
