#pragma once
#ifndef COMPARE_ALGORITHMS_H_
#define COMPARE_ALGORITHMS_H_
#include <stdint.h>
#include <algorithm>
#include <time.h>  
#include <stdlib.h> 
//#include "coverage_ordering.h"
//#ifndef GRAPH_H
#include "graph_order.h"
//#include <gmp.h>
//#endif // !

//#include "graph_search.h"
//#define NodeID uint32_t
#define NODE_TYPE int32_t
#define DIS_TYPE int32_t
#define LABEL_TYPE int32_t
#define INF_WEIGHT INT_MAX
#define MAX_STEP 0

struct label_edge {
	LABEL_TYPE label;
	NODE_TYPE node;
	DIS_TYPE weight;
};
#include <string>
#include <set>
#include <unordered_set>
//#include "algorithms.h"
using namespace std;
LABEL_TYPE label_set_convert_to_binary_label(set<LABEL_TYPE> temp);
LABEL_TYPE convert_to_binary_label(LABEL_TYPE temp);
set<LABEL_TYPE> convert_to_label_set(LABEL_TYPE temp);
int test_edp();
int test_edp_by_queryset(string input, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries);
void load_label_graph(string filename, long node_num, vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse);
int test_dfs_with_label(NODE_TYPE src, NODE_TYPE dst, set<LABEL_TYPE> labels, int node_num, string filename, vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse);
bool A_is_subset_of_B(set<LABEL_TYPE>& A, set<LABEL_TYPE>& B);
bool A_is_subset_of_B(LABEL_TYPE A, LABEL_TYPE B);
LABEL_TYPE convert_to_binary_label(LABEL_TYPE temp);
unsigned long getGraphSizeInBytes_node(int node_num, vector<label_edge>* adjacency_list, NODE_TYPE v);
void load_label_graph(string filename, long node_num, vector<label_edge>* adjacency_list, vector<label_edge>* adjacency_list_reverse, vector<NODE_TYPE>& node_in_labels, vector<NODE_TYPE>& node_out_labels, vector<vector<label_edge>>* vec_adjacency_list, vector<vector<label_edge>>* vec_adjacency_list_reverse, int label_num);
set<LABEL_TYPE> convert_to_label_set(LABEL_TYPE temp);
void load_label_graph_get_node_edge_num(string filename, uint32_t& node_num, uint32_t & edge_num);
int test_edp_by_queryset_minimal_label_set_weight_label(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries);
int compare_node_order(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries);
unsigned long getGraphSizeInBytes(int node_num, vector<label_edge>* adjacency_list);
int test_edp_by_queryset_minimal_label_set(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries);
int test_edp_by_queryset_minimal_label_set_advanced_node_order(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries);
int test_edp_by_queryset_minimal_label_set_significant_path(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries);
int test_naive_2hop_labeling(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries);
int test_edp_by_queryset_minimal_label_set_large_labels(string input, uint32_t node_num, uint32_t num_of_labels, uint32_t querset_num, uint32_t num_of_queries);
//bool dominated_by_one_in_set(LABEL_TYPE labels, set<ppl_LCR_pair>& cmp_labels);
#endif